#!/usr/bin/env python3
"""Telegram-бот графиков работы бассейна (интерфейс на польском).

Сотрудники присылают диспозицию на следующий месяц (дни и смены, когда могут работать,
или «готов в любые»). Бот сразу раскладывает пожелания в черновик графика с учётом ставки
каждого (полная, 3/4, 1/2, 1/4), показывает, где людей не хватает и где лишние, директор
переносит людей в рамках их диспозиции и публикует график. После публикации сотрудники
видят свои смены и могут попроситься на доп. смену туда, где не хватает людей.

Работает через long polling, внешние зависимости: только openpyxl.
Всё общение с Telegram собрано в разделе «Telegram», чтобы потом заменить его на WhatsApp.
"""
import calendar
import datetime as dt
import difflib
import hashlib
import hmac
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import openpyxl
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

BASE = os.path.dirname(os.path.abspath(__file__))
STATE_FILE = os.path.join(BASE, "state.json")
VERSION = "2026-11-19f"    # дата версии кода — видна в заявках, чтобы понимать, на какой версии ошибка
SCHEMA_VERSION = 2         # версия формата state.json; новые версии кода обновляют старые данные на месте

MONTHS = ["styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec", "lipiec",
          "sierpień", "wrzesień", "październik", "listopad", "grudzień"]
MONTHS_LOC = ["styczniu", "lutym", "marcu", "kwietniu", "maju", "czerwcu", "lipcu",
              "sierpniu", "wrześniu", "październiku", "listopadzie", "grudniu"]
DAYS = ["Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd"]
DAYS_XLS = ["pon", "wt", "śr", "czw", "pt", "so", "nie"]

# Смены как в таблице бассейна. covers — какие половины дня закрывает смена.
PERIODS = ["rano", "popołudnie"]
ETATS = {"1": ("pełny etat", 1.0), "3/4": ("3/4 etatu", 0.75), "1/2": ("1/2 etatu", 0.5),
         "1/4": ("1/4 etatu", 0.25), "0": ("bez etatu (umowa zlecenie)", None)}

# разбор диспозиции текстом (польский, можно без диакритики)
DAY_PREFIXES = [("pon", 0), ("pn", 0), ("wt", 1), ("śr", 2), ("sr", 2), ("czw", 3), ("cz", 3),
                ("pią", 4), ("pia", 4), ("pt", 4), ("sob", 5), ("sb", 5), ("niedz", 6), ("nd", 6)]
DAY_GROUPS = {"robocze": range(5), "powszednie": range(5), "weekend": range(5, 7), "weekendy": range(5, 7),
              "weekendów": range(5, 7), "weekendow": range(5, 7), "weekendami": range(5, 7)}
ALL_DAYS = {"każdy", "kazdy", "codziennie", "wszystkie", "dowolne", "dowolny", "zawsze"}
WORDS_R1 = {"rano", "ranna", "ranne", "rankiem", "poranna", "poranne", "r1"}
WORDS_R2 = {"popołudnie", "popoludnie", "popołudniu", "popoludniu", "popołudniowa", "popoludniowa",
            "popołudniowe", "popoludniowe", "wieczór", "wieczor", "wieczorem", "r2"}
WORDS_R3 = {"cały", "caly", "całe", "cale", "całą", "cala", "całodniowa", "calodniowa", "r3"}
WORDS_ANY = {"dowolna", "dowolną", "każda", "każdą", "kazda", "kazdą", "obie", "wszystkie"}

HELP_EMP = (
    "Raz w miesiącu bot przyśle tabelę dni na kolejny miesiąc. Zaznacz, kiedy możesz pracować: "
    "R1 — rano, R2 — popołudnie, R3 — cały dzień. Kliknięcie w datę zaznacza lub odznacza cały dzień. "
    "Jeśli możesz w dowolne dni — przycisk «🟢 Mogę w dowolne dni». Na końcu — «✅ Gotowe».\n\n"
    "Możesz też odpisać tekstem, np.:\n"
    "1-10 rano, 15 20 popołudnie, 25 cały dzień\n"
    "dni robocze popołudnie, weekendy cały dzień\n"
    "mogę w dowolne dni\n\n"
    "📋 Mój grafik — Twoje zmiany po opublikowaniu grafiku.\n"
    "🙋 Dodatkowe zmiany — zmiany, na których brakuje ludzi; możesz się zgłosić, kierownik zatwierdzi.\n"
    "🌴 Urlop — wybierz daty od–do i wyślij wniosek; po zatwierdzeniu dni urlopu są w grafiku oznaczone jako U."
)
HELP_DIR = (
    "Jak ułożyć grafik:\n"
    "1. 📨 Zbierz dyspozycje — bot roześle pracownikom tabelę na kolejny miesiąc.\n"
    "2. 👀 Kto odpowiedział — kto już przysłał, przypomnienie pozostałym.\n"
    "3. 🧩 Ułóż grafik — bot rozłoży życzenia na zmiany z uwzględnieniem etatów i pokaże, "
    "gdzie brakuje ludzi (⚠️), a gdzie jest nadwyżka (➕). Przyśle plik Excel.\n"
    "4. ✏️ Edytuj grafik — dzień po dniu: przenieś osobę na inną zmianę lub inny dzień "
    "w ramach jej dyspozycji, dodaj, usuń.\n"
    "5. 📤 Opublikuj — pracownicy dostaną «grafik gotowy» i swoje zmiany.\n"
    "6. 🙋 Prośby — kto zgłasza się na dodatkowe zmiany; po akceptacji osoba pojawia się w grafiku.\n\n"
    "👥 Pracownicy — etaty, link dla nowych pracowników, usuwanie."
)


# ---------- настройки ----------

def load_env():
    path = os.path.join(BASE, ".env")
    env = {}
    if os.path.exists(path):
        with open(path, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    env.update({k: v for k, v in os.environ.items() if k == "BOT_TOKEN"})
    return env


def parse_time(s, default):
    pattern = r"^\s*(\d{1,2})[:.](\d{2})\s*[-–]\s*(\d{1,2})[:.](\d{2})\s*$"
    m = re.match(pattern, s or "") or re.match(pattern, default)
    h1, m1, h2, m2 = (int(x) for x in m.groups())
    hours = (h2 * 60 + m2 - h1 * 60 - m1) / 60
    return f"{h1:02d}:{m1:02d}–{h2:02d}:{m2:02d}", hours if hours > 0 else hours + 24


def int_env(key, default):
    try:
        return int(ENV.get(key, "") or default)
    except ValueError:
        return default


ENV = load_env()
TOKEN = ENV.get("BOT_TOKEN", "")
API = f"https://api.telegram.org/bot{TOKEN}/"
class ShiftTable(dict):
    """R1/R2/R3 плюс смены с произвольным временем из графика для кадр: «R4@10:00-14:00» — дополнение часов до нормы
    (как в файле бассейна, на обсаду не считается), «R3@10:00-16:00» — R3 из импортированного файла (6 ч, не наш R3)."""

    def __missing__(self, code):
        label, _, when = str(code).partition("@")
        times = re.findall(r"(\d{1,2}):(\d{2})", when)
        if len(times) < 2:
            raise KeyError(code)
        (h1, m1), (h2, m2) = [(int(a), int(b)) for a, b in times[:2]]
        hours = ((h2 + m2 / 60) - (h1 + m1 / 60)) % 24
        base = dict.get(self, label)
        # R4 до 8 ч — дополнение часов, на обсаду не считается; длинная R4 из файла (09:00–20:00) закрывает обе половины дня
        covers = base["covers"] if base else ("rano", "popołudnie") if hours > 8 else ()
        return {"name": "dopełnienie" if label == "R4" and hours <= 8 else "skrócona" if hours < 8 else "wydłużona", "covers": covers,
                "time": f"{h1:02d}:{m1:02d}-{h2:02d}:{m2:02d}", "hours": hours}


SHIFTS = ShiftTable()
for _code, _name, _covers, _key, _default in (
        ("R1", "rano", ("rano",), "TIME_MORNING", "06:00-14:00"),
        ("R2", "popołudnie", ("popołudnie",), "TIME_EVENING", "14:00-22:00"),
        ("R3", "cały dzień", ("rano", "popołudnie"), "TIME_FULL", "06:00-22:00")):
    _time, _hours = parse_time(ENV.get(_key), _default)
    SHIFTS[_code] = {"name": _name, "covers": _covers, "time": _time, "hours": _hours}
CODES = list(SHIFTS)
NEED = {"rano": int_env("NEED_MORNING", 3), "popołudnie": int_env("NEED_EVENING", 3)}
MAX_PER_SHIFT = int_env("MAX_PER_SHIFT", 4)   # больше этого на смене — «nadwyżka», бот предлагает перенос
NEED_WEEKEND = {"rano": int_env("NEED_WEEKEND_MORNING", NEED["rano"]),
                "popołudnie": int_env("NEED_WEEKEND_EVENING", NEED["popołudnie"])}
MONTH_HOURS = int_env("MONTH_HOURS", 0)   # 0 — считать норму по польскому календарю
SCHEDULE_DIR = os.path.expanduser(ENV.get("SCHEDULE_DIR", "") or os.path.join(BASE, "grafiki"))
AUTO_FILL_DAY = int_env("AUTO_FILL_DAY", 25)   # в этот день не ответившим ставится «любые дни и смены»
TEST_DEADLINE_SEC = 150   # в тестовом сборе «термин» наступает через 2,5 минуты
WEB_PORT = int_env("WEB_PORT", 8770)   # редактор графика в браузере, только на этом компьютере
CLOSED_ON_HOLIDAYS = int_env("CLOSED_ON_HOLIDAYS", 1)   # в праздники бассейн закрыт (можно открыть день вручную)
STAFFING = []      # [{"from": "YYYY-MM", "rano", "pop", "max"}] — тот же список, что state["staffing"]
DAY_NEED = {}      # {ym: {"день": минимум}} — исключения на день; тот же словарь, что state["day_need"]
EMPS = {}          # тот же словарь, что state["employees"]: дата ухода нужна там, где нет state
BLOOD_CARRY = {}   # {ym: {uid: [1]}} — второй день сдачи крови, перешедший на следующий месяц; тот же словарь, что state["blood_carry"]
VACATIONS = []     # заявки на urlop: тот же список, что state["vacations"]
CLOSED_DAYS = {}   # {ym: {"closed": [дни], "open": [дни]}} — ручные правки; тот же словарь, что state["closed_days"]
LOCK = threading.RLock()               # бот и редактор работают с одним state из разных потоков


def backup_state(reason):
    """Копия state.json в backups/ (храним 20 последних): при каждом запуске и перед обновлением формата."""
    if not os.path.exists(STATE_FILE):
        return
    d = os.path.join(os.path.dirname(STATE_FILE), "backups")
    os.makedirs(d, exist_ok=True)
    shutil.copy(STATE_FILE, os.path.join(d, f"state-{time.strftime('%Y%m%d-%H%M%S')}-{reason}.json"))
    for old in sorted(f for f in os.listdir(d) if f.startswith("state-"))[:-20]:
        os.remove(os.path.join(d, old))


def _migrate_1_to_2(st):
    # версия 2: заявки в поддержку, имена директоров, история графиков
    for k, v in (("tickets", []), ("next_ticket", 1), ("ticket_msgs", {}), ("admin_names", {}), ("history", {})):
        st.setdefault(k, v)


MIGRATIONS = {1: _migrate_1_to_2}   # из версии N в N+1; данные только дополняются, ничего не удаляется


def load_state():
    global CLOSED_DAYS, BLOOD_CARRY, EMPS, STAFFING, DAY_NEED, VACATIONS
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            st = json.load(f)
    except (OSError, ValueError):
        st = {}
    schema = st.get("schema", 1)
    if st and schema < SCHEMA_VERSION:
        backup_state(f"przed-migracja-v{schema}")
        while schema < SCHEMA_VERSION:
            MIGRATIONS[schema](st)
            schema += 1
    st["schema"] = SCHEMA_VERSION
    CLOSED_DAYS = st.setdefault("closed_days", {})
    BLOOD_CARRY = st.setdefault("blood_carry", {})
    VACATIONS = st.setdefault("vacations", [])
    EMPS = st["employees"]
    STAFFING = st.setdefault("staffing", [])
    if not STAFFING:   # значения из .env становятся первой записью настройки
        STAFFING.append({"from": "2000-01", "rano": NEED["rano"], "pop": NEED["popołudnie"], "max": MAX_PER_SHIFT})
    DAY_NEED = st.setdefault("day_need", {})
    for k, v in (("offset", 0), ("admins", []), ("employees", {}), ("months", {}), ("cur", None),
                 ("wiz", {}), ("next_req", 1)):
        st.setdefault(k, v)
    for m in st["months"].values():
        if "started" not in m:   # сборы, начатые до появления авто-диспозиции, автоматически не трогаем
            m["started"], m["auto_applied"] = None, True
    return st


def save_state(state):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STATE_FILE)


def admin_ids(state):
    ids = {str(x) for x in re.findall(r"\d+", ENV.get("ADMIN_IDS", ""))}
    return ids | {str(x) for x in state["admins"]}


def log(msg):
    print(time.strftime("%Y-%m-%d %H:%M:%S"), msg, flush=True)


# ---------- Telegram ----------

def tg(method, **params):
    data = urllib.parse.urlencode(
        {k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in params.items()}
    ).encode()
    with urllib.request.urlopen(API + method, data=data, timeout=70) as r:
        return json.loads(r.read().decode())


def send(chat_id, text, markup=None, force=False):
    if ROLES["mode"] == "test" and str(chat_id) in ROLES["real"] and not force:
        log(f"Tryb testowy: nie wysyłam do prawdziwego pracownika {chat_id}")
        return False
    if str(chat_id) == DEMO_UID and DEMO_CHAT[0]:   # демо: сообщения «сотруднику» приходят директору
        chat_id, text = DEMO_CHAT[0], f"🧪 DEMO jako {DEMO_NAME}:\n{text}"
        markup = DEMO_KB if markup is EMP_KB else markup
    elif str(chat_id) in ROLES["admins"] and markup in (EMP_KB, DIR_KB):
        # директор, который сам тоже сотрудник: кнопки директора + свои кнопки сотрудника
        markup = dir_kb_for(str(chat_id))
    elif str(chat_id).startswith(("test", "man")):   # тестовые и добавленные вручную: без Telegram
        return True
    params = {"chat_id": chat_id, "text": text}
    if markup:
        params["reply_markup"] = markup
    try:
        tg("sendMessage", **params)
        return True
    except Exception as e:  # noqa: BLE001
        log(f"sendMessage {chat_id} failed: {e}")
        return False


def edit(chat_id, message_id, text, markup=None):
    if str(chat_id) == DEMO_UID and DEMO_CHAT[0]:
        chat_id, text = DEMO_CHAT[0], f"🧪 DEMO jako {DEMO_NAME}:\n{text}"
    elif str(chat_id).startswith(("test", "man")):
        return
    try:
        tg("editMessageText", chat_id=chat_id, message_id=message_id, text=text,
           reply_markup=markup or {"inline_keyboard": []})
    except urllib.error.HTTPError as e:
        if "not modified" not in e.read().decode(errors="ignore"):
            log(f"editMessageText failed: {e}")
    except Exception as e:  # noqa: BLE001
        log(f"editMessageText failed: {e}")


def send_document(chat_id, path, caption="",
                  ctype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"):
    boundary = uuid.uuid4().hex
    parts = [f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
             for k, v in (("chat_id", str(chat_id)), ("caption", caption))]
    with open(path, "rb") as f:
        content = f.read()
    parts.append(
        (f'--{boundary}\r\nContent-Disposition: form-data; name="document"; '
         f'filename="{os.path.basename(path)}"\r\n'
         f"Content-Type: {ctype}\r\n\r\n").encode()
        + content + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(API + "sendDocument", data=b"".join(parts),
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(req, timeout=70) as r:
            r.read()
    except Exception as e:  # noqa: BLE001
        detail = e.read().decode(errors="ignore") if isinstance(e, urllib.error.HTTPError) else ""
        log(f"sendDocument failed: {e} {detail}")
        send(chat_id, f"Nie udało się wysłać pliku, leży tutaj: {path}")


def bot_username():
    try:
        return tg("getMe")["result"]["username"]
    except Exception:  # noqa: BLE001
        return ""


def ikb(rows):
    return {"inline_keyboard": rows}


def btn(text, data):
    return {"text": text, "callback_data": data}


B_AVAIL, B_MINE, B_EXTRA, B_HELP = "🗓 Moja dyspozycja", "📋 Mój grafik", "🙋 Dodatkowe zmiany", "❓ Pomoc"
B_COLLECT, B_WHO, B_BUILD, B_EDIT = "📨 Zbierz dyspozycje", "👀 Kto odpowiedział", "🧩 Ułóż grafik", "✏️ Edytuj grafik"
B_PUB, B_REQS, B_STAFF, B_WEB = "📤 Opublikuj", "🙋 Prośby", "👥 Pracownicy", "🖥 Edytor"
B_DEMO, B_DEMO_NEXT, B_DEMO_END = "👤 Demo: widok pracownika", "▶ Dalej (demo)", "⏹ Zakończ demo"
B_TEST, B_LAUNCH = "🧪 Test", "🚀 Uruchom bota (tryb pracy)"
EMP_KB = {"keyboard": [[B_AVAIL, B_MINE], [B_EXTRA, "🌴 Urlop"], [B_HELP]], "resize_keyboard": True}
DIR_ROWS = [[B_COLLECT, B_WHO], [B_BUILD, B_EDIT], [B_PUB, B_REQS], [B_STAFF, B_WEB, B_HELP]]
# в тестовом режиме у директора есть ряд «🧪 Test / 🚀 Start»; после запуска он исчезает (set_mode меняет этот же dict)
DIR_KB = {"keyboard": DIR_ROWS + [[B_TEST], [B_LAUNCH]], "resize_keyboard": True}
DEMO_KB = {"keyboard": [[B_AVAIL, B_MINE], [B_EXTRA, "🌴 Urlop"], [B_HELP], [B_DEMO_NEXT, B_DEMO_END]], "resize_keyboard": True}
ALL_BUTTONS = {B_AVAIL, B_MINE, B_EXTRA, B_HELP, B_COLLECT, B_WHO, B_BUILD, B_EDIT, B_PUB, B_REQS, B_STAFF, B_WEB,
               B_DEMO, B_DEMO_NEXT, B_DEMO_END, B_TEST, B_LAUNCH, "🌴 Urlop"}
DEMO_UID, DEMO_NAME = "testdemo", "Demo Pracownik (test)"
ROLES = {"admins": set(), "emp_admins": set(), "real": set(), "mode": "prod"}   # кэш для send(): refresh_roles()


def refresh_roles(state):
    ROLES["admins"] = set(admin_ids(state))
    ROLES["emp_admins"] = {u for u in ROLES["admins"] if state["employees"].get(u, {}).get("status") == "active"}
    # настоящие сотрудники (не тестовые и не директора): в тестовом режиме им ничего не шлём, кроме регистрации
    ROLES["real"] = {u for u, e in state["employees"].items()
                     if e.get("status") == "active" and not u.startswith("test") and u not in ROLES["admins"]}
    ROLES["mode"] = state.get("mode", "prod")


def dir_kb_for(uid):
    if uid in ROLES["emp_admins"]:
        return {"keyboard": DIR_KB["keyboard"] + [[B_AVAIL, B_MINE, B_EXTRA, "🌴 Urlop"]], "resize_keyboard": True}
    return DIR_KB
DEMO_CHAT = [None]   # чат директора, который сейчас смотрит демо


# ---------- месяц и норма часов ----------

def easter(y):
    a, b, c = y % 19, y // 100, y % 100
    d, e = divmod(b, 4)
    g = (8 * b + 13) // 25
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    month, day = divmod(h + l_ - 7 * m + 114, 31)
    return dt.date(y, month, day + 1)


def holidays_pl(y):
    e = easter(y)
    fixed = [(1, 1), (1, 6), (5, 1), (5, 3), (8, 15), (11, 1), (11, 11), (12, 25), (12, 26)]
    if y >= 2025:
        fixed.append((12, 24))   # Wigilia — выходной с 2025 года
    days = {dt.date(y, m, d) for m, d in fixed}
    return days | {e, e + dt.timedelta(days=1), e + dt.timedelta(days=49), e + dt.timedelta(days=60)}


def month_norm(state, ym):
    """Норма часов на полную ставку в этом месяце: ручная правка директора или по календарю."""
    return (state.get("norms") or {}).get(ym) or MONTH_HOURS or calendar_norm(ym)


def norm_info(state, ym):
    """Для «Kadry»: норма месяца и из чего она получилась."""
    y, m = ym_parts(ym)
    hol = sorted(h for h in holidays_pl(y) if h.month == m)
    n, auto, cur = len(hol), MONTH_HOURS or calendar_norm(ym), month_norm(state, ym)
    word = "święto" if n == 1 else "święta" if 2 <= n <= 4 else "świąt"
    hol_txt = ", ".join(f"{h.day}.{h.month} {DAYS[h.weekday()].lower()}" for h in hol)
    text = f"Wymiar: {month_title(ym)} = {cur} h" + (f" ({n} {word}: {hol_txt})" if n else " (bez świąt)")
    if cur != auto:
        text += f". Ustawione ręcznie, z kalendarza {auto} h"
    return {"hours": cur, "auto": auto, "manual": cur != auto, "text": text}


def set_norm(state, ym, hours):
    if hours in (None, ""):
        (state.get("norms") or {}).pop(ym, None)
    else:
        hours = int(hours)
        if not 8 <= hours <= 300:
            return "Wymiar musi być między 8 a 300 h."
        state.setdefault("norms", {})[ym] = hours
    save_state(state)
    return None


def calendar_norm(ym, last=None):
    """8 ч × рабочие дни (пн–пт), минус 8 ч за праздник в субботу (Kodeks pracy, art. 130). last — считать до этого дня."""
    y, m = ym_parts(ym)
    hol = holidays_pl(y)
    hours = 0
    for d in range(1, (last or calendar.monthrange(y, m)[1]) + 1):
        day = dt.date(y, m, d)
        if day.weekday() < 5 and day not in hol:
            hours += 8
        elif day.weekday() == 5 and day in hol:
            hours -= 8
    return hours


def ym_parts(ym):
    y, m = ym.split("-")
    return int(y), int(m)


def next_ym(today):
    y, m = today.year + (today.month == 12), today.month % 12 + 1
    return f"{y}-{m:02d}"


def tag(ym):
    return ym.replace("-", "")[2:]


def month_title(ym):
    y, m = ym_parts(ym)
    return f"{MONTHS[m - 1]} {y}"


def ndays(ym):
    return calendar.monthrange(*ym_parts(ym))[1]


def date_of(ym, d):
    y, m = ym_parts(ym)
    return dt.date(y, m, d)


def dlabel(ym, d):
    return f"{DAYS[date_of(ym, d).weekday()]} {d:02d}.{ym_parts(ym)[1]:02d}"


def is_closed(ym, d):
    """Бассейн закрыт: смен нет, людей не требуется, день не предлагается в диспозиции и графиках."""
    c = CLOSED_DAYS.get(ym) or {}
    if d in c.get("closed", []):
        return True
    if d in c.get("open", []):
        return False
    return bool(CLOSED_ON_HOLIDAYS) and date_of(ym, d) in holidays_pl(ym_parts(ym)[0])


def need_for(ym, d):
    day = date_of(ym, d)
    if is_closed(ym, d):
        return {p: 0 for p in PERIODS}
    one = (DAY_NEED.get(ym) or {}).get(str(d))
    if one:
        return {p: one for p in PERIODS}
    s_ = staffing_for(ym)
    if s_["from"] == "2000-01" and (day.weekday() >= 5 or day in holidays_pl(day.year)):
        return NEED_WEEKEND   # пока директор не менял настройку, действует .env, в том числе свои значения на выходные
    return {"rano": s_["rano"], "popołudnie": s_["pop"]}


def staffing_for(ym):
    """Настройка обсады, действующая в этом месяце."""
    found = [x for x in STAFFING if x["from"] <= ym]
    return max(found, key=lambda x: x["from"]) if found else {"from": "2000-01", "rano": NEED["rano"], "pop": NEED["popołudnie"], "max": MAX_PER_SHIFT}


def max_for(ym):
    return staffing_for(ym)["max"]


def staffing_set(state, frm, rano, pop, mx):
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(frm)):
        return "Wybierz miesiąc."
    rano, pop, mx = int(rano), int(pop), int(mx)
    if min(rano, pop) < 1 or max(rano, pop) > mx or mx > 30:
        return "Minimum musi być co najmniej 1 i nie większe niż maksimum."
    state["staffing"][:] = [x for x in state["staffing"] if x["from"] != frm]
    state["staffing"].append({"from": frm, "rano": rano, "pop": pop, "max": mx})
    state["staffing"].sort(key=lambda x: x["from"])
    save_state(state)
    log(f"Obsada od {frm}: rano {rano}, popołudnie {pop}, maks. {mx}")
    return None


def staffing_del(state, frm):
    if frm == "2000-01" or not any(x["from"] == frm for x in state["staffing"]):
        return "Tego wpisu nie można usunąć."
    state["staffing"][:] = [x for x in state["staffing"] if x["from"] != frm]
    save_state(state)
    return None


def day_need_set(state, ym, d, n):
    """Исключение на один день; n=None — вернуть обычное значение."""
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(ym)) or not 1 <= d <= ndays(ym):
        return "Nie ma takiego dnia."
    days = state["day_need"].setdefault(ym, {})
    if n in (None, ""):
        days.pop(str(d), None)
    else:
        n = int(n)
        if not 1 <= n <= max_for(ym):
            return f"Minimum tego dnia: od 1 do {max_for(ym)}."
        days[str(d)] = n
    if not days:
        state["day_need"].pop(ym, None)
    save_state(state)
    return None


def weeks(ym):
    """Номера дней месяца, разбитые по неделям с понедельника."""
    res, cur = [], []
    for d in range(1, ndays(ym) + 1):
        cur.append(d)
        if date_of(ym, d).weekday() == 6:
            res.append(cur)
            cur = []
    if cur:
        res.append(cur)
    return res


def new_month(ym):
    return {"ym": ym, "avail": {}, "done": [], "schedule": None, "published": False, "requests": [],
            "started": dt.date.today().isoformat()}


def auto_fill(state, month):
    """Кто не прислал диспозицию — «может в любые дни и смены» с пометкой auto. Сотрудникам не пишем."""
    filled = []
    for u in active_in(state, month["ym"]):
        if u not in month["done"] and not month["avail"].get(u, {}).get("auto"):
            month["avail"][u] = {"all": True, "days": {}, "auto": True}
            filled.append(u)
    return filled


# ---------- ciągłe zbieranie dyspozycji (tryb pracy) ----------
# Рабочий режим, календарь месяца M: с 1-го по AUTO_FILL_DAY-е (25-е, до 23:59) открыт сбор на M+1
# (state["collect"]), сотрудники шлют диспозицию сами. 25-го в 9:00 — напоминание тем, кто не прислал.
# С 26-го 00:00 сбор на M+1 закрыт: не ответившим 🤖 auto, черновик, M+1 — рабочий месяц директора (state["cur"]).
# С 26-го до конца месяца сбор закрыт; 1-го числа открывается следующий (уведомление, если NOTIFY_OPEN=1).
# В тестовом режиме collect = cur, всё как раньше («📨 Zbierz dyspozycje» начинает сбор).

NOTIFY_OPEN = int_env("NOTIFY_OPEN", 1)
REMIND_HOUR = int_env("REMIND_HOUR", 9)


def collect_month(state):
    if state.get("mode") == "prod":
        ym = state.get("collect")
    else:
        ym = state.get("cur")
    return state["months"].get(ym) if ym else None


def deadline_of(ym):
    """Последний день подачи диспозиции на месяц ym (включительно)."""
    py_, pm_ = ym_parts(prev_ym(ym))
    return dt.date(py_, pm_, min(AUTO_FILL_DAY, calendar.monthrange(py_, pm_)[1]))


def open_ym(today):
    """Какой месяц открыт для диспозиций в этот день: 1–25 — следующий, 26–конец — никакой (None)."""
    return next_ym(today) if today.day <= AUTO_FILL_DAY else None


def upcoming_open(today):
    """(месяц, дата), когда откроется следующий сбор — для сообщения «rusza 1.mm»."""
    y, m = ym_parts(next_ym(today))
    first = dt.date(y, m, 1)
    return next_ym(first), first


def month_for_tag(state, t):
    return next((m for ym, m in state["months"].items() if tag(ym) == t), None)


def can_edit_avail(state, month, uid):
    if not month or month["published"]:
        return False
    if uid in month.get("reopen", []):
        return True
    if month.get("collect_closed"):
        return False
    return month is collect_month(state)


def ensure_collect(state, today=None):
    """Рабочий режим: открыть сбор, когда положено (1-го числа), и держать его открытым до срока."""
    if state.get("mode") != "prod":
        return
    today = today or dt.date.today()
    if state.get("collect") in state["months"]:
        return
    if not state.get("collect_init"):
        # переход в рабочий режим: ближайший месяц ещё не собран — держим его открытым до ручного закрытия
        state["collect_init"] = True
        cand = next_ym(today)
        m = state["months"].get(cand)
        if not (m and (m.get("collect_closed") or m["published"])):
            m = state["months"].setdefault(cand, new_month(cand))
            if today > deadline_of(cand):
                m["manual_close"] = True
            state["collect"] = cand
            if not state.get("cur") or state["cur"] not in state["months"]:
                state["cur"] = cand
            save_state(state)
            log(f"Zbieranie dyspozycji otwarte (przejście): {month_title(cand)}")
            return
    ym = open_ym(today)
    m = state["months"].get(ym) if ym else None
    if not ym or (m and (m.get("collect_closed") or m["published"])):
        if state.get("collect") is not None:
            state["collect"] = None
            save_state(state)
        return
    m = state["months"].setdefault(ym, new_month(ym))
    state["collect"] = ym
    if not state.get("cur") or state["cur"] not in state["months"]:
        state["cur"] = ym
    save_state(state)
    log(f"Zbieranie dyspozycji otwarte: {month_title(ym)}")
    if NOTIFY_OPEN:
        for u in active_in(state, ym):
            if u != DEMO_UID:
                send(u, f"📝 Możesz już wysłać dyspozycję na {month_title(ym)} (do {deadline_of(ym):%d.%m}).", EMP_KB)
                ask_avail(state, u, m)


def remind_deadline(state, today=None, hour=None):
    """25-го (с REMIND_HOUR) — один раз напомнить тем, кто ещё не прислал диспозицию."""
    today = today or dt.date.today()
    hour = time.localtime().tm_hour if hour is None else hour
    m = collect_month(state)
    if (state.get("mode") != "prod" or not m or m.get("manual_close") or m.get("reminded")
            or today != deadline_of(m["ym"]) or hour < REMIND_HOUR):
        return
    m["reminded"] = True
    save_state(state)
    wait = [u for u in active_in(state, m["ym"]) if u not in m["done"] and u != DEMO_UID]
    for u in wait:
        send(u, f"⏰ Dziś ostatni dzień na dyspozycję na {month_title(m['ym'])} (do 23:59). Potem bot przyjmie, "
                "że możesz w dowolne dni i zmiany.", EMP_KB)
        ask_avail(state, u, m)
    log(f"Przypomnienie 25.: {len(wait)} osób")


def close_collection(state, month, today=None, by=None):
    """Закрыть сбор на месяц: auto не ответившим, черновик, этот месяц — рабочий, следующий открыт."""
    today = today or dt.date.today()
    ym = month["ym"]
    month["collect_closed"], month["auto_applied"] = True, True
    month.pop("manual_close", None)
    filled = auto_fill(state, month)
    if month["schedule"] is None or filled:
        build_schedule(state, month)
    state["cur"] = ym
    state["collect"] = None
    keep = {state["cur"]}
    for old in sorted(state["months"])[:-4]:
        if old not in keep:
            del state["months"][old]
    save_state(state)
    emps = [u for u in active_in(state, month["ym"]) if u != DEMO_UID]
    done = sum(1 for u in emps if u in month["done"])
    names = ", ".join(ename(state, u) for u in filled)
    log(f"Zbieranie zamknięte: {month_title(ym)} ({'ręcznie' if by else 'termin'}), auto: {names or '—'}")
    nxt, opens = upcoming_open(today) if not open_ym(today) else (open_ym(today), today)
    for a in admin_ids(state):
        send(a, f"🔒 Dyspozycje na {month_title(ym)} zamknięte"
                + (" (ręcznie)" if by else f" (termin {deadline_of(ym):%d.%m} minął)")
                + f": przysłało {done} z {len(emps)}" + (f", 🤖 auto: {names}" if filled else "")
                + f". Szkic grafiku gotowy.\nZbieranie na {month_title(nxt)} rusza {opens:%d.%m}.", DIR_KB)
        web_button(a, "Sprawdź szkic w edytorze:")
    ensure_collect(state, today)   # если закрыли досрочно (1–25), следующий месяц откроется сразу


def check_auto_fill(state, today=None):
    """Тестовый режим: AUTO_FILL_DAY-го числа (до конца дня) — auto не ответившим и черновик.
    Рабочий режим: закрывает сбор на открытый месяц после срока и открывает следующий."""
    today = today or dt.date.today()
    apply_exits(state)
    if state.get("mode") == "prod":
        ensure_collect(state, today)
        m = collect_month(state)
        if m and not m.get("manual_close") and not m.get("collect_closed") and not m["published"] \
                and today > deadline_of(m["ym"]):
            close_collection(state, m, today)
        else:
            remind_deadline(state, today)
        return
    month = cur_month(state)
    if not month or month["published"] or month.get("auto_applied") or month["ym"] != next_ym(today):
        return
    if month.get("test_deadline"):
        # тестовый сбор: «термин» наступает через пару минут после начала, а не 25-го
        if time.time() < month["test_deadline"]:
            return
        when, prefix = "test", f"🧪 Test: symulacja {AUTO_FILL_DAY}. dnia miesiąca.\n"
    else:
        prefix = ""
        deadline = dt.date(today.year, today.month,
                           min(AUTO_FILL_DAY, calendar.monthrange(today.year, today.month)[1]))
        if month.get("started"):
            started = dt.date.fromisoformat(month["started"])
            if started >= deadline:           # сбор начат поздно — даём людям 3 дня
                deadline = started + dt.timedelta(days=3)
        if today <= deadline:                 # 25-е — последний день подачи, срабатываем с 26-го
            return
        when = f"{deadline:%d.%m}"
    month["auto_applied"] = True
    filled = auto_fill(state, month)
    if filled:
        build_schedule(state, month)
    save_state(state)
    names = ", ".join(ename(state, u) for u in filled)
    log(f"Auto-dyspozycja ({when}): {names or 'wszyscy odpowiedzieli'}")
    for a in admin_ids(state):
        if filled:
            send(a, f"{prefix}🤖 Termin dyspozycji minął ({when}). Nie przysłali: {names}. "
                    "Przyjąłem, że mogą w dowolne dni i zmiany (auto), i ułożyłem szkic grafiku od nowa.", DIR_KB)
            web_button(a, "Sprawdź grafik w edytorze:")
        else:
            send(a, f"{prefix}🤖 Termin dyspozycji minął ({when}). Wszyscy przysłali dyspozycje.", DIR_KB)


def cur_month(state):
    return state["months"].get(state["cur"]) if state["cur"] else None


def sh_text(c):
    return f"{c.split('@')[0]} {SHIFTS[c]['name']} {SHIFTS[c]['time']}"


# ---------- сотрудники ----------

def active(state):
    """Работающие сейчас. После последнего рабочего дня человек выпадает сразу, без перезапуска бота."""
    today = dt.date.today().isoformat()
    emps = {u: e for u, e in state["employees"].items()
            if e.get("status") == "active" and not (e.get("exit") and e["exit"] < today)}
    return dict(sorted(emps.items(), key=lambda kv: kv[1]["name"].lower()))


def exit_of(uid):
    return (EMPS.get(uid) or {}).get("exit")


def is_gone(ym, d, uid):
    """День после последнего рабочего дня сотрудника."""
    x = exit_of(uid)
    return bool(x) and date_of(ym, d).isoformat() > x


def active_in(state, ym):
    """Кто ещё работает в этом месяце: без ушедших до его начала."""
    return {u: e for u, e in active(state).items() if not e.get("exit") or e["exit"] >= f"{ym}-01"}


def ename(state, uid):
    e = state["employees"].get(uid)
    if not e and str(uid).startswith("name:"):   # из импортированного графика, ещё не зарегистрирован(а)
        return uid[5:].title()
    return e["name"] if e else "?"


def etat_for(state, uid, ym):
    """Ставка в этом месяце: последняя подходящая запись из etat_periods, иначе исходная. После окончания
    временного периода снова действует то, что было до него."""
    e = state["employees"].get(uid) or {}
    for p in reversed(e.get("etat_periods") or []):
        if p["from"] <= ym and (not p.get("to") or ym <= p["to"]):
            return p["etat"]
    return e.get("etat", "1")


def etat_period_text(p):
    fmt = lambda ym: f"{ym[5:]}.{ym[:4]}"
    return (f"{ETATS[p['etat']][0]}: od {fmt(p['from'])}" + (f" do {fmt(p['to'])} włącznie" if p.get("to") else " na stałe"))


def etat_period_add(state, uid, etat, frm, to=None):
    e = state["employees"].get(uid)
    ok = lambda ym: bool(re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(ym)))
    if not e or etat not in ETATS:
        return "Nie ma takiego pracownika lub etatu."
    if not ok(frm) or (to and not ok(to)):
        return "Wybierz miesiąc."
    if to and to < frm:
        return "Miesiąc końcowy nie może być wcześniejszy niż początkowy."
    e.setdefault("etat_periods", []).append({"from": frm, "to": to or None, "etat": etat})
    save_state(state)
    log(f"Etat: {e['name']}: {etat_period_text(e['etat_periods'][-1])}")
    return None


def etat_period_del(state, uid, i):
    e = state["employees"].get(uid) or {}
    lst = e.get("etat_periods") or []
    if not 0 <= i < len(lst):
        return "Tego wpisu już nie ma."
    lst.pop(i)
    save_state(state)
    return None


def set_donor(state, uid, on):
    e = state["employees"].get(uid)
    if not e:
        return "Nie ma takiego pracownika."
    e["donor"] = bool(on)
    save_state(state)
    log(f"Honorowy dawca: {e['name']} = {'tak' if on else 'nie'}")
    return None


def emp_rename(state, uid, name):
    e = state["employees"].get(uid)
    name = " ".join(str(name or "").split())[:40]
    if not e or len(name) < 2:
        return "Podaj imię i nazwisko."
    e["name"] = name
    save_state(state)
    return None


def target_hours(state, uid, ym):
    frac = ETATS.get(etat_for(state, uid, ym), ETATS["1"])[1]
    x = (state["employees"].get(uid) or {}).get("exit")
    if frac is None or (x and x < f"{ym}-01"):
        return None
    norm = month_norm(state, ym)
    if x and x[:7] == ym:   # месяц ухода: норма только до последнего дня
        norm = norm * max(0, calendar_norm(ym, int(x[8:]))) / (calendar_norm(ym) or 1)
    return round(norm * frac)


def grafik_hours(state, uid, ym):
    """Цель в графике для сотрудников: там смены по 8 ч и без R4, поэтому норма ставки округляется вниз до кратного 8
    (сверх ставки не ставим); остаток дополняет R4 в графике для кадр."""
    t = target_hours(state, uid, ym)
    return None if t is None else t // 8 * 8


def blood_picks(month, uid):
    """Дни, которые сотрудник сам отметил как день сдачи крови."""
    return (month.get("blood") or {}).get(uid) or []


def next_day(ym, d):
    """(месяц, день) следующего дня."""
    x = date_of(ym, d) + dt.timedelta(days=1)
    return f"{x.year}-{x.month:02d}", x.day


def blood_days(month, uid):
    """Оплачиваемые дни освобождения: день сдачи и следующий. Если второй день выпал на закрытый день, он пропадает.
    Каждый такой день свободен и считается как 8 ч."""
    ym = month["ym"]
    res = set((BLOOD_CARRY.get(ym) or {}).get(uid) or [])
    for d in blood_picks(month, uid):
        res.add(d)
        y2, d2 = next_day(ym, d)
        if y2 == ym:
            res.add(d2)
    return sorted(x for x in res if not is_closed(ym, x))


def blood_sync(state, month, uid):
    """Если день сдачи — последний день месяца, второй день уходит в следующий месяц."""
    ym = month["ym"]
    last = ndays(ym)
    nxt = next_day(ym, last)[0]
    carry = BLOOD_CARRY.setdefault(nxt, {})
    if last in blood_picks(month, uid):
        carry[uid] = [1]
    else:
        carry.pop(uid, None)
    if not carry:
        BLOOD_CARRY.pop(nxt, None)


def blood_warning(month, d):
    """Предупреждение: второй день освобождения попал на день, когда бассейн закрыт."""
    y2, d2 = next_day(month["ym"], d)
    if not is_closed(y2, d2):
        return ""
    return (f"⚠️ Drugi dzień zwolnienia ({d2:02d}.{y2[5:]}) przypada na dzień, w którym basen jest zamknięty: "
            "ten dzień przepadnie. Rozważ inny termin.")


def avail_hours(month, uid):
    """Сколько часов максимум можно набрать по диспозиции (None — «любые дни»), включая 8 ч за день сдачи крови."""
    av = month["avail"].get(uid)
    if not av:
        return 8 * len(blood_days(month, uid))
    if av.get("all"):
        return None
    return 8 * len(blood_days(month, uid)) + sum(
        max(SHIFTS[c]["hours"] for c in codes) for d, codes in av.get("days", {}).items()
        if codes and not is_closed(month["ym"], int(d)) and int(d) not in blood_days(month, uid))


def options(month, uid, d):
    """Какие смены человек готов взять в этот день. R3 (cały dzień) значит «весь день свободен»:
    можно поставить и R1, и R2, и R3."""
    av = month["avail"].get(uid)
    if not av or is_closed(month["ym"], d) or d in blood_days(month, uid) or is_gone(month["ym"], d, uid) \
            or vac_on(month["ym"], d, uid):
        return []
    if av.get("all"):
        return list(CODES)
    codes = av.get("days", {}).get(str(d), [])
    return list(CODES) if "R3" in codes else codes


# ---------- диспозиция ----------

class ParseError(ValueError):
    pass


def day_index(word):
    for p, i in DAY_PREFIXES:
        if word.startswith(p):
            return i
    return None


def shift_word(w):
    if w in WORDS_R1:
        return ["R1"]
    if w in WORDS_R2:
        return ["R2"]
    if w in WORDS_R3:
        return ["R3"]
    if w in WORDS_ANY:
        return list(CODES)
    return None


def parse_avail(text, ym):
    """«1-10 rano, 15 20 popołudnie, weekendy cały dzień» → {"all": bool, "days": {"1": ["R1"], ...}}.

    Дни копятся, пока не встретится смена; смена относится ко всем дням перед ней.
    Дни без смены после них — любая смена. Не названные дни — не может.
    """
    t = text.lower().replace("–", "-")
    t = re.sub(r"(\d)\s*-\s*(\d)", r"\1-\2", t)
    t = t.replace("po południu", "popołudniu").replace("po poludniu", "popoludniu")
    words = [w.strip(".-") for w in re.findall(r"[a-ząćęłńóśźż0-9.\-]+", t)]
    words = [w for w in words if w]
    has_specific = any(re.search(r"\d", w) or w in DAY_GROUPS or day_index(w) is not None
                       or w in WORDS_R1 | WORDS_R2 | WORDS_R3 for w in words)
    if not has_specific and any(w in ALL_DAYS | {"wszystko", "dowolnie"} for w in words):
        return {"all": True, "days": {}}
    n = ndays(ym)
    res = {}
    pending, last_was_shift = [], False

    def flush(codes):
        for d in pending:
            cur = res.setdefault(str(d), [])
            res[str(d)] = [c for c in CODES if c in cur or c in codes]

    for w in words:
        days = None
        if re.fullmatch(r"\d{1,2}(\.\d{1,2})?", w):
            days = [int(w.split(".")[0])]
        elif re.fullmatch(r"\d{1,2}-\d{1,2}", w):
            a, b = (int(x) for x in w.split("-"))
            days = list(range(a, b + 1))
        elif w in DAY_GROUPS:
            days = [d for d in range(1, n + 1) if date_of(ym, d).weekday() in DAY_GROUPS[w]]
        elif w in ALL_DAYS and not (w == "wszystkie" and pending):
            days = list(range(1, n + 1))
        elif day_index(w) is not None:
            days = [d for d in range(1, n + 1) if date_of(ym, d).weekday() == day_index(w)]
        if days is not None:
            if last_was_shift:
                pending = []
                last_was_shift = False
            bad = [d for d in days if not 1 <= d <= n]
            if bad:
                raise ParseError(f"w {MONTHS_LOC[ym_parts(ym)[1] - 1]} nie ma {bad[0]} dnia")
            pending += days
        else:
            codes = shift_word(w)
            if codes and pending:
                flush(codes)
                last_was_shift = True
    if pending and not last_was_shift:
        flush(CODES)
    if not res:
        raise ParseError("nie znalazłem w wiadomości żadnych dni")
    return {"all": False, "days": {k: v for k, v in res.items() if v}}


def fmt_blood(month, uid):
    ym, parts = month["ym"], []
    for d in sorted(blood_picks(month, uid)):
        y2, d2 = next_day(ym, d)
        second = f"{d2:02d}.{y2[5:]}" + (" przepada: basen zamknięty" if is_closed(y2, d2) else "")
        parts.append(f"{dlabel(ym, d)} (drugi dzień: {second})")
    return "🩸 Krew: " + ", ".join(parts) if parts else ""


def fmt_avail(month, uid):
    return "\n".join(x for x in (fmt_avail_days(month, uid), fmt_blood(month, uid)) if x)


def fmt_avail_days(month, uid):
    av = month["avail"].get(uid)
    if not av:
        return "brak odpowiedzi" if not blood_days(month, uid) else ""
    if av.get("all"):
        return "dowolne dni i zmiany"
    ym = month["ym"]
    lines = []
    for d in range(1, ndays(ym) + 1):
        codes = av["days"].get(str(d))
        if codes and not is_closed(ym, d) and d not in blood_days(month, uid):
            lines.append(f"{dlabel(ym, d)}: {', '.join(SHIFTS[c]['name'] for c in codes)}")
    return "\n".join(lines) or "żadnego dnia"


def deadline_note(ym):
    left = (deadline_of(ym) - dt.date.today()).days
    if left < 0:
        return ""
    return f" · termin: {deadline_of(ym):%d.%m} (zostało {left} dni)" if left else f" · termin: dziś, {deadline_of(ym):%d.%m}"


def avail_count(state, month, uid):
    """(часы доступности, норма). Дисп. — это доступность: день с R1/R2 или «любой сменой» = 8 ч, только R3 (весь день) = 16 ч;
    дни сдачи крови и urlop считаются как 8 ч. None — «mogę w dowolne dni»."""
    ym = month["ym"]
    av = month["avail"].get(uid) or {}
    norm = target_hours(state, uid, ym)
    if av.get("all") and not av.get("auto"):
        return None, norm
    hours = leave_hours(month, uid)
    for d, codes in ({} if av.get("auto") else av.get("days", {})).items():
        d = int(d)
        if codes and not is_closed(ym, d) and d not in blood_days(month, uid) and not is_gone(ym, d, uid):
            hours += 16 if set(codes) == {"R3"} else 8
    return hours, norm


def avail_line(state, month, uid):
    """«📊 Dostępność: 96 h z 120 h normy (12 zm.) · zostało 24 h (3 zm.)»."""
    hours, norm = avail_count(state, month, uid)
    if hours is None:
        return "📊 Dowolne dni i zmiany: ✅ norma pokryta"
    if norm is None:
        return f"📊 Dostępność: {hours:g} h ({hours / 8:g} zm.)"
    if hours >= norm:
        return f"📊 Dostępność: {hours:g} h z {norm} h normy · ✅ norma pokryta" + (f" (+{hours - norm:g} h ponad)" if hours > norm else "")
    left = norm - hours
    return (f"📊 Dostępność: {hours:g} h z {norm} h normy ({hours / 8:g} zm.) · zostało {left:g} h "
            f"({-(-left // 8):g} zm.)")


def avail_text(month, page, state=None, uid=None):
    ym = month["ym"]
    wk = weeks(ym)[page]
    sh = "; ".join(f"{c} — {s['name']} {s['time']}" for c, s in SHIFTS.items())
    shut = [d for d in wk if is_closed(ym, d)]
    if shut:
        sh += "\n🔒 Basen zamknięty: " + ", ".join(dlabel(ym, d) for d in shut)
    return (f"Dyspozycja na {month_title(ym)}{deadline_note(ym)}. Tydzień {page + 1} z {len(weeks(ym))} "
            f"({wk[0]:02d}–{wk[-1]:02d}).\n{sh}.\n"
            "Zaznacz zmiany, na których możesz pracować. Kliknięcie w datę — cały dzień. "
            "Przewijaj tygodnie strzałkami, na końcu kliknij «✅ Gotowe».\n"
            "Można też tekstem: «1-10 rano, 15 popołudnie» albo «mogę w dowolne dni»."
            + (f"\n\n{avail_line(state, month, uid)}" if state is not None and uid else ""))


def avail_kb(state, month, uid, page):
    ym, t = month["ym"], tag(month["ym"])
    av = month["avail"].get(uid, {})
    if av.get("auto"):   # авто-диспозицию сотруднику не показываем: таблица пустая, пока он не ответит
        av = {}
    rows = []
    donor = bool((state["employees"].get(uid) or {}).get("donor"))
    if donor:
        rows.append([btn("🩸 = oddaję krew: ten dzień i następny wolne", f"dp:{t}:{page}")])
    if av.get("all"):
        rows.append([btn("🟢 Mogę w dowolne dni — odznacz", f"dn:{t}:{page}")])
    for d in weeks(ym)[page]:
        if is_closed(ym, d):
            continue
        on = options(month, uid, d) if av else []
        row = [btn(dlabel(ym, d), f"dd:{t}:{page}:{d}")]
        for c in CODES:
            row.append(btn(("✅" if c in on else "▫️") + c, f"dt:{t}:{page}:{d}:{c}"))
        if donor:
            mark = "✅🩸" if d in blood_picks(month, uid) else "🩸2" if d in blood_days(month, uid) else "▫️🩸"
            row.append(btn(mark, f"db:{t}:{page}:{d}"))
        rows.append(row)
    nav = []
    if page > 0:
        nav.append(btn("◀️ Poprz. tydzień", f"dp:{t}:{page - 1}"))
    if page < len(weeks(ym)) - 1:
        nav.append(btn("Nast. tydzień ▶️", f"dp:{t}:{page + 1}"))
    rows.append(nav)
    if not av.get("all"):
        rows.append([btn("🟢 Mogę w dowolne dni i zmiany", f"da:{t}:{page}")])
    rows.append([btn("Wyczyść tydzień", f"dc:{t}:{page}"), btn("✅ Gotowe", f"dk:{t}")])
    return ikb(rows)


def ask_avail(state, uid, month=None):
    month = month or collect_month(state)
    if not can_edit_avail(state, month, uid):
        if state.get("mode") == "prod":
            nxt, opens = upcoming_open(dt.date.today())
            closed = state["months"].get(state.get("cur") or "")
            note = (f"Dyspozycja na {month_title(closed['ym'])} jest już zamknięta ({deadline_of(closed['ym']):%d.%m}). "
                    if closed and closed.get("collect_closed") else "")
            return send(uid, f"{note}Zbieranie dyspozycji na {month_title(nxt)} rusza {opens:%d.%m}.", EMP_KB)
        return send(uid, "Teraz nie zbieramy dyspozycji. Bot napisze, gdy kierownik zacznie zbierać.", EMP_KB)
    return send(uid, avail_text(month, 0, state, uid), avail_kb(state, month, uid, 0))


def start_collect(state, chat_id):
    if state.get("mode") == "prod":   # w pracy zbieranie trwa cały czas: to tylko podgląd i przypomnienie
        ensure_collect(state)
        who_answered(state, chat_id, "Dyspozycje zbieram cały czas, pracownicy wysyłają je sami («🗓 Moja dyspozycja»).\n\n")
        return
    ym = next_ym(dt.date.today())
    month = state["months"].get(ym)
    show = [[btn("🎬 Scenariusz pokazowy (test)", f"showcase:{tag(ym)}")]] if test_only(state) else []
    if month and not month["published"]:
        who_answered(state, chat_id, "Zbieranie na ten miesiąc już trwa.\n\n")
        send(chat_id, "Zacząć zbieranie od nowa? Obecne dyspozycje i szkic grafiku na ten miesiąc zostaną usunięte, "
                      "pracownicy dostaną tabelę jeszcze raz.",
             ikb([[btn("🔄 Zbierz od nowa", f"recollect:{tag(ym)}"), btn("Nie", "noop")]] + show))
        return
    if month and month["published"]:
        send(chat_id, f"Grafik na {month_title(ym)} jest już opublikowany. Zmiany: «{B_EDIT}».",
             ikb(show) if show else None)
        return
    if not active(state):
        send(chat_id, f"Nie ma jeszcze żadnego pracownika. Kliknij «{B_STAFF}», tam jest link dla pracowników.")
        return
    begin_collect(state, chat_id, ym)


def restart_collect(state, chat_id, msg, t):
    ym = next_ym(dt.date.today())
    month = state["months"].get(ym)
    if tag(ym) != t or not month or month["published"]:
        edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    edit(chat_id, msg["message_id"], f"Zaczynam zbieranie na {month_title(ym)} od nowa.")
    begin_collect(state, chat_id, ym)


def begin_collect(state, chat_id, ym):
    state["months"][ym] = new_month(ym)
    state["cur"] = ym
    for old in sorted(state["months"])[:-3]:
        del state["months"][old]
    save_state(state)
    ok = sum(1 for uid in active_in(state, ym) if ask_avail(state, uid))
    send(chat_id, f"Wysłałem tabelę na {month_title(ym)}: {ok} z {len(active_in(state, ym))} pracowników. "
                  f"Norma na pełny etat: {month_norm(state, ym)} h.\n"
                  f"Napiszę, gdy wszyscy odpowiedzą. Kto już przysłał: «{B_WHO}».", DIR_KB)
    simulate_test_answers(state, chat_id, ym)


def test_only(state):
    """Тестовые сценарии (стирают тестовый месяц) разрешены только в тестовом режиме. Настоящие сотрудники,
    записавшиеся до «🚀 Start», в тестовые месяцы не попадают (им ничего не шлём), поэтому не мешают."""
    if state.get("mode") != "test":
        return False
    return any(u.startswith("test") and u != DEMO_UID for u in active(state))


SHOWCASE_GUIDE = (
    "🎬 Scenariusz pokazowy — co sprawdzić:\n"
    "1. «👀 Kto odpowiedział»: 14 z 15, godziny przy każdym (⚠️ Kasia Lis — za mało do etatu).\n"
    "2. Za ok. 2 min «termin dyspozycji»: Ula Krawczyk dostanie auto 🤖 (dowolne dni).\n"
    "3. «🧩 Ułóż grafik» → «Grafik»: na każdej zmianie 3–4 osoby; weekendy z brakami (czerwone) — kliknij dzień: "
    "«Mogą przyjść» i «z innego dnia».\n"
    "4. Magda Jankowska: ⚪ brak miejsca (jej dni rano mają już 4 osoby). Kasia: «📨 Poproś o dodatkowe godziny».\n"
    "5. Nadwyżka: postaw ręcznie 5. osobę na dowolną zmianę (bot ostrzeże) — pojawi się blok «Nadwyżka» z propozycjami.\n"
    "6. Przenieś kogoś: kliknij jego zmianę → «↔ Przenieś».\n"
    "7. «📤 Wyślij grafik pracownikom»: po chwili Anna i Iza zgłoszą się na dodatkowe zmiany (karty do zatwierdzenia).\n"
    "8. «Kadry» → «Ułóż grafik dla kadr»: Anna, Piotr, Ola, Jan mają wolne 1.11 (3 niedziele w październiku), "
    "Kasia, Marek, Ewa nie mogą R1 1.11 (R2 31.10). «📄 Import do kadr» → Excel.\n"
    "9. «Historia» → październik 2026. «👤 Demo: widok pracownika» — jak to widzi pracownik.")


def start_showcase(state, chat_id, msg, t):
    ym = next_ym(dt.date.today())
    if tag(ym) != t:
        edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    if not test_only(state):
        edit(chat_id, msg["message_id"], "Scenariusz pokazowy działa tylko, gdy w bocie są wyłącznie pracownicy testowi.")
        return
    try:
        import test_data
    except ImportError:
        return
    edit(chat_id, msg["message_id"], f"🎬 Zaczynam scenariusz pokazowy na {month_title(ym)}.")
    state["months"][ym] = month = new_month(ym)
    state["cur"] = ym
    month["showcase"] = True
    for u, e in active(state).items():
        if e["name"].startswith("Kuba Piotrowski"):   # bez etatu, żeby było widać i taki przypadek
            e["etat"] = "0"
        if e["name"].startswith("Ula Krawczyk"):   # auto «dowolne dni» na 1/4, żeby zostało kilka braków
            e["etat"] = "1/4"
    save_state(state)
    names = {u: state["employees"][u]["name"].replace(" (test)", "") for u in active(state) if u != DEMO_UID}
    silent = next((u for u, nm in names.items() if nm == "Ula Krawczyk"), None)
    month["test_silent"] = silent
    month["test_deadline"] = time.time() + TEST_DEADLINE_SEC
    save_state(state)
    send(chat_id, f"Wysłałem tabelę na {month_title(ym)}: {len(names)} pracowników (testowych). Odpowiedzi przyjdą "
                  "w ciągu ok. minuty; Ula Krawczyk nie odpowie.", DIR_KB)

    def run():
        for u, nm in sorted(names.items(), key=lambda x: x[1]):
            time.sleep(2)
            if u == silent:
                continue
            with LOCK:
                m = state["months"].get(ym)
                if not m or m["published"] or state["cur"] != ym or not m.get("showcase"):
                    return
                m["avail"][u] = test_data.showcase_avail(ym, nm) or {"all": True, "days": {}}
                mark_done(state, u)
        with LOCK:
            send(chat_id, SHOWCASE_GUIDE, DIR_KB)
        log("Scenariusz pokazowy: odpowiedzi wysłane")

    threading.Thread(target=run, daemon=True).start()


def showcase_requests(state, ym):
    """После публикации сценария-показа Anna и Iza просят доп. смены там, где не хватает людей."""
    def run():
        time.sleep(6)
        with LOCK:
            month = state["months"].get(ym)
            if not month or not month.get("published"):
                return
            for u in [u for u in active(state) if ename(state, u).split()[0] in ("Anna", "Iza")]:
                for d in range(1, ndays(ym) + 1):
                    bal = balance(month, d)
                    if u in month["schedule"][str(d)] or not any(v < 0 for v in bal.values()):
                        continue
                    c = "R1" if bal["rano"] < 0 else "R2"
                    rid = state["next_req"]
                    state["next_req"] += 1
                    month["requests"].append({"id": rid, "uid": u, "day": d, "code": c, "status": "pending"})
                    what = f"{dlabel(ym, d)}, {sh_text(c)}"
                    for a in admin_ids(state):
                        send(a, f"🙋 {ename(state, u)} zgłasza się na dodatkową zmianę: {what}. "
                                f"Teraz ma {hours_of(month, u):g} h.",
                             ikb([[btn("✅ Zatwierdź", f"xa:{rid}"), btn("❌ Odrzuć", f"xn:{rid}")]]))
                    break
            save_state(state)

    threading.Thread(target=run, daemon=True).start()


def simulate_test_answers(state, chat_id, ym):
    """Тестовые сотрудники «отвечают» по одному раз в несколько секунд случайными диспозициями.
    Один случайный не отвечает вовсе, другой отмечает на одну смену меньше."""
    test_uids = [u for u in active(state) if u.startswith("test") and u != DEMO_UID]
    if len(test_uids) < 2:
        return
    try:
        import random
        import test_data
    except ImportError:
        return
    rnd = random.Random()
    rnd.shuffle(test_uids)
    silent, minus = test_uids[0], test_uids[1]
    state["months"][ym]["test_silent"] = silent
    state["months"][ym]["test_deadline"] = time.time() + TEST_DEADLINE_SEC
    save_state(state)
    log(f"Test: nie odpowie {ename(state, silent)}, o jedną zmianę mniej {ename(state, minus)}")
    send(chat_id, f"🧪 Test: dyspozycje pracowników testowych są losowe. Nie odpowie: {ename(state, silent)}. "
                  f"O jedną zmianę mniej zaznaczy: {ename(state, minus)}. Za ok. {TEST_DEADLINE_SEC // 60} min "
                  f"minie «termin dyspozycji» (jak {AUTO_FILL_DAY}. dnia) i bot sam wstawi auto tym, kto nie odpowiedział.")

    def run():
        for u in test_uids:
            time.sleep(rnd.uniform(2, 6))
            if u == silent:
                continue
            with LOCK:
                month = state["months"].get(ym)
                if not month or month["published"] or u not in active(state) or state["cur"] != ym:
                    continue
                av = test_data.random_avail(ym, state["employees"][u].get("etat", "1"), rnd)
                if u == minus:
                    if av["all"]:
                        av = {"all": False, "days": {str(d): list(CODES) for d in range(1, ndays(ym) + 1)}}
                    del av["days"][rnd.choice(list(av["days"]))]
                month["avail"][u] = av
                mark_done(state, u)
        log("Test: losowe odpowiedzi pracowników testowych wysłane")

    threading.Thread(target=run, daemon=True).start()


def who_answered(state, chat_id, prefix=""):
    month = collect_month(state)
    if not month:
        send(chat_id, f"Zbieranie jeszcze się nie zaczęło. Kliknij «{B_COLLECT}».")
        return
    emps = active_in(state, month["ym"])
    wait = [u for u in emps if u not in month["done"]]
    term = deadline_note(month["ym"]) if state.get("mode") == "prod" else ""
    if month.get("manual_close"):
        term = f" · termin {deadline_of(month['ym']):%d.%m} minął, zbieranie otwarte do ręcznego zamknięcia"
    lines = [f"{prefix}{month_title(month['ym']).capitalize()}{term}. Przysłało {len(emps) - len(wait)} z {len(emps)}."]
    for u, e in emps.items():
        if u in month["done"]:
            lines.append(f"✅ {e['name']}{hours_note(state, month, u)}")
    lines += [f"🤖 {emps[u]['name']} — auto: dowolne dni i zmiany" if month["avail"].get(u, {}).get("auto")
              else f"❌ {emps[u]['name']}" for u in wait]
    rows = [[btn("🔔 Przypomnij tym, którzy nie odpowiedzieli", f"remind:{tag(month['ym'])}")]] if wait else []
    if state.get("mode") == "prod" and not month.get("collect_closed"):
        rows.append([btn(f"🔒 Zamknij zbieranie na {month_title(month['ym'])}", f"closecol:{tag(month['ym'])}")])
    send(chat_id, "\n".join(lines), ikb(rows) if rows else None)


def close_collection_manual(state, chat_id, msg, t):
    month = collect_month(state)
    if state.get("mode") != "prod" or not month or tag(month["ym"]) != t or month.get("collect_closed"):
        edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    edit(chat_id, msg["message_id"], f"Zamykam zbieranie na {month_title(month['ym'])}…")
    close_collection(state, month, by=chat_id)


def remind(state, chat_id):
    month = collect_month(state)
    wait = [u for u in active_in(state, month["ym"]) if u not in month["done"]]
    for u in wait:
        send(u, "Przypomnienie: prześlij proszę dyspozycję na kolejny miesiąc.")
        ask_avail(state, u)
    send(chat_id, f"Przypomniałem: {len(wait)}.")


def avail_callback(state, uid, msg, data):
    p = data.split(":")
    month = month_for_tag(state, p[1])
    if not can_edit_avail(state, month, uid):
        edit(uid, msg["message_id"], "Ta tabela jest już nieaktualna: zbieranie dyspozycji na ten miesiąc jest zamknięte.")
        return
    av = month["avail"].setdefault(uid, {"all": False, "days": {}})
    if av.get("auto"):   # человек отвечает сам — авто-диспозиция заменяется настоящей
        av = month["avail"][uid] = {"all": False, "days": {}}
    kind = p[0]
    page = int(p[2]) if len(p) > 2 and p[2].isdigit() else 0
    if av.get("all") and kind in ("dt", "dd", "dc", "db"):
        # снимаем «любые дни», дальше человек отмечает конкретные дни
        av["all"] = False
        av["days"] = {str(d): list(CODES) for d in range(1, ndays(month["ym"]) + 1)}
    if kind in ("dt", "dd"):   # смена и кровь в один день несовместимы
        blood = month.setdefault("blood", {}).get(uid) or []
        if int(p[3]) in blood:
            blood.remove(int(p[3]))
            blood_sync(state, month, uid)
    if kind == "db":
        d = int(p[3])
        if (state["employees"].get(uid) or {}).get("donor") and not is_closed(month["ym"], d):
            blood = month.setdefault("blood", {}).setdefault(uid, [])
            if d in blood:
                blood.remove(d)
            else:
                blood.append(d)
                warn = blood_warning(month, d)
                if warn:
                    send(uid, warn)
            blood_sync(state, month, uid)
            for x in blood_days(month, uid):   # в эти два дня смен нет
                av["days"].pop(str(x), None)
    elif kind == "dt":
        d, c = p[3], p[4]
        cur = av["days"].get(d, [])
        av["days"][d] = [x for x in CODES if (x in cur) != (x == c)]
    elif kind == "dd":
        d = p[3]
        av["days"][d] = [] if av["days"].get(d) else list(CODES)
    elif kind == "dc":
        for d in weeks(month["ym"])[page]:
            av["days"].pop(str(d), None)
            if d in blood_picks(month, uid):
                month["blood"][uid].remove(d)
                blood_sync(state, month, uid)
    elif kind == "da":
        av["all"], av["days"] = True, {}
    elif kind == "dn":
        av["all"], av["days"] = False, {}
    elif kind == "dk" and len(p) < 3:
        av["days"] = {k: v for k, v in av["days"].items() if v}
        hours, norm = avail_count(state, month, uid)
        if hours is not None and norm and hours < norm:   # мало часов: предупреждаем, но не запрещаем
            save_state(state)
            edit(uid, msg["message_id"], f"⚠️ Zaznaczona dostępność: {hours:g} h z {norm} h normy, brakuje {norm - hours:g} h "
                                         f"({-(-(norm - hours) // 8):g} zm.).\nDodaj dni albo wyślij mimo to.",
                 ikb([[btn("↩️ Wróć do tabeli", f"dp:{p[1]}:0")], [btn("✅ Wyślij mimo to", f"dk:{p[1]}:ok")]]))
            return
        kind = "dk"
    if kind == "dk":
        av["days"] = {k: v for k, v in av["days"].items() if v}
        if uid in month.get("reopen", []):
            month["reopen"].remove(uid)   # повторно открыто только для этой правки
        mark_done(state, uid, month)
        edit(uid, msg["message_id"], f"✅ Zapisano dyspozycję na {month_title(month['ym'])}:\n"
                                     f"{fmt_avail(month, uid)}\n{avail_line(state, month, uid)}\n\nPoprawić: «{B_AVAIL}»"
                                     + (f" (do {deadline_of(month['ym']):%d.%m})." if state.get("mode") == "prod" else "."))
        return
    av["days"] = {k: v for k, v in av["days"].items() if v}
    save_state(state)
    edit(uid, msg["message_id"], avail_text(month, page, state, uid), avail_kb(state, month, uid, page))


def hours_note(state, month, uid):
    """« (maks. 96 z 120 h ⚠️)» — сколько часов даёт диспозиция относительно ставки."""
    cap, t = avail_hours(month, uid), grafik_hours(state, uid, month["ym"])
    if cap is None:
        return " (dowolne dni)"
    if t is None:
        return f" (maks. {cap:g} h)"
    return f" (maks. {cap:g} z {t} h{' ⚠️' if cap < t else ''})"


def mark_done(state, uid, month=None):
    month = month or collect_month(state)
    first = uid not in month["done"]
    if first:
        month["done"].append(uid)
    save_state(state)
    emps = {u: e for u, e in active_in(state, month["ym"]).items() if not u.startswith("man")}   # ręcznie dodani nie odpowiadają
    left = [u for u in emps if u not in month["done"]]
    asked = month.get("asked", {}).get(uid)
    if asked and not asked.get("answered"):
        asked["answered"] = True
        save_state(state)
        cap, t = avail_hours(month, uid), grafik_hours(state, uid, month["ym"])
        what = "dowolne dni" if cap is None else f"maks. {cap:g} h" + (f" przy etacie {t} h" if t else "")
        for a in admin_ids(state):
            send(a, f"📨 {ename(state, uid)} uzupełnił(a) dyspozycję po Twojej prośbie: teraz {what}.")
    for a in admin_ids(state):
        if first and not left:
            send(a, f"Wszyscy ({len(emps)}) przysłali dyspozycje. Można kliknąć «{B_BUILD}».")
        elif first:
            send(a, f"{ename(state, uid)} przysłał(a) dyspozycję. {avail_line(state, month, uid)}. "
                    f"Odpowiedziało {len(emps) - len(left)} z {len(emps)}."
                    + (f"\n{fmt_blood(month, uid)}" if blood_days(month, uid) else ""))
        elif month["schedule"]:
            send(a, f"{ename(state, uid)} zmienił(a) dyspozycję. Szkic grafiku się nie zmienia: "
                    "ułóż go od nowa albo popraw ręcznie.")


def avail_from_text(state, uid, text):
    month = collect_month(state)
    if not can_edit_avail(state, month, uid):
        ask_avail(state, uid)
        return
    m = re.search(r"\bkrew\s+([\d\s,.;i-]+)", text, re.I)
    if m and (state["employees"].get(uid) or {}).get("donor"):
        days = [int(x) for x in re.findall(r"\d+", m.group(1)) if 1 <= int(x) <= ndays(month["ym"])]
        shut = [d for d in days if is_closed(month["ym"], d)]
        if shut:
            send(uid, f"⚠️ Basen jest zamknięty: {', '.join(dlabel(month['ym'], d) for d in shut)}. Tych dni nie zapisałem, wybierz inny termin.")
        blood = month.setdefault("blood", {}).setdefault(uid, [])
        av = month["avail"].setdefault(uid, {"all": False, "days": {}})
        for d in days:
            if d in shut:
                continue
            if d not in blood:
                blood.append(d)
                warn = blood_warning(month, d)
                if warn:
                    send(uid, warn)
        blood_sync(state, month, uid)
        for x in blood_days(month, uid):
            av.get("days", {}).pop(str(x), None)
        text = (text[:m.start()] + " " + text[m.end():]).strip(" ,;")
        if not text:
            save_state(state)
            send(uid, f"Zrozumiałem tak:\n{fmt_avail(month, uid)}\n\nJeśli wszystko się zgadza, kliknij «✅ Gotowe».", avail_kb(state, month, uid, 0))
            return
    try:
        res = parse_avail(text, month["ym"])
    except ParseError as e:
        send(uid, f"Nie rozumiem: {e}.\nPrzykład: 1-10 rano, 15 20 popołudnie, 25 cały dzień\n"
                  "Albo zaznacz przyciskami:", avail_kb(state, month, uid, 0))
        return
    month["avail"][uid] = res
    save_state(state)
    send(uid, f"Zrozumiałem tak:\n{fmt_avail(month, uid)}\n{avail_line(state, month, uid)}\n\nJeśli wszystko się zgadza, kliknij «✅ Gotowe» "
              "albo popraw przyciskami.", avail_kb(state, month, uid, 0))


# ---------- черновик графика ----------

def coverage(month, d):
    cov = {p: 0 for p in PERIODS}
    for c in (month["schedule"] or {}).get(str(d), {}).values():
        for p in SHIFTS[c]["covers"]:
            cov[p] += 1
    return cov


def balance(month, d):
    """Сколько людей не хватает (<0) или лишних (>0) в каждой половине дня."""
    need, cov = need_for(month["ym"], d), coverage(month, d)
    return {p: cov[p] - need[p] for p in PERIODS}


def month_leave(month):
    """Дни отсутствия месяца {день: {uid: код}}: urlop/ZW из файла и сдача крови (KRW)."""
    res = {d: dict(day) for d, day in (month.get("leave") or {}).items()}
    for uid in set(month.get("blood") or {}) | set(BLOOD_CARRY.get(month["ym"]) or {}):
        for d in blood_days(month, uid):
            res.setdefault(str(d), {})[uid] = "KRW"
    for v in VACATIONS:   # zatwierdzony urlop z wniosku: wszystkie dni okresu zablokowane, kod U
        if v.get("status") == "approved":
            for d in vac_days_in(v, month["ym"]):
                if not is_closed(month["ym"], d):
                    res.setdefault(str(d), {}).setdefault(v["uid"], "U")
    return res


def is_workday(ym, d):
    day = date_of(ym, d)
    return day.weekday() < 5 and day not in holidays_pl(day.year)


def vac_days_in(v, ym):
    """Дни заявки на urlop, попадающие в месяц ym."""
    y, m = ym_parts(ym)
    a, b = dt.date.fromisoformat(v["from"]), dt.date.fromisoformat(v["to"])
    first, last = dt.date(y, m, 1), dt.date(y, m, ndays(ym))
    a, b = max(a, first), min(b, last)
    return list(range(a.day, b.day + 1)) if a <= b else []


def vac_on(ym, d, uid):
    return any(v.get("status") == "approved" and v["uid"] == uid and d in vac_days_in(v, ym) for v in VACATIONS)


def leave_h(ym, d, uid, code):
    """Часы дня отсутствия в норму: 8 ч, но urlop из заявки в субботу, воскресенье и праздник — 0 ч
    (wymiar czasu pracy уменьшается только на рабочие дни)."""
    if code == "U" and not is_workday(ym, d) and vac_on(ym, d, uid):
        return 0
    return 8


def leave_hours(month, uid):
    """Urlop/ZW/KRW: 8 ч за день, как в столбце SUMA файла; urlop из заявки — только рабочие дни."""
    return sum(leave_h(month["ym"], int(d), uid, day[uid]) for d, day in month_leave(month).items() if uid in day)


def hours_of(month, uid):
    return sum(SHIFTS[day[uid]]["hours"] for day in (month["schedule"] or {}).values() if uid in day) + leave_hours(month, uid)


def shift_score(month, d, c):
    """+1 за каждую половину дня, где не хватает людей, −0.5 за каждую, где уже хватает."""
    bal = balance(month, d)
    return sum(1 if bal[p] < 0 else -0.5 for p in SHIFTS[c]["covers"])


def build_schedule(state, month):
    """Сначала раскладывает конкретные пожелания в пределах ставки, потом закрывает нехватку
    теми, кто готов в любые дни, и оставшимися пожеланиями."""
    ym = month["ym"]
    emps = {u: e for u, e in active(state).items() if month["avail"].get(u)}
    month["schedule"] = {str(d): {} for d in range(1, ndays(ym) + 1)}
    sched = month["schedule"]
    norm = month_norm(state, ym)
    # дни сдачи крови и отпуск уже считаются в часы
    cap = {u: max(8, (grafik_hours(state, u, ym) or norm) - leave_hours(month, u)) for u in emps}
    used = {u: 0 for u in emps}

    def best(u, d, need_gain):
        if u in sched[str(d)]:
            return None
        best_c = None
        cov = coverage(month, d)
        for c in options(month, u, d):
            if used[u] + SHIFTS[c]["hours"] > cap[u]:
                continue
            if any(cov[p] >= max_for(month["ym"]) for p in SHIFTS[c]["covers"]):   # не больше MAX_PER_SHIFT на смене
                continue
            s = shift_score(month, d, c)
            if need_gain and s <= 0:
                continue
            if best_c is None or s > best_c[0] or (s == best_c[0] and SHIFTS[c]["hours"] < best_c[2]):
                best_c = (s, c, SHIFTS[c]["hours"])
        return best_c

    def place(u, d, c):
        sched[str(d)][u] = c
        used[u] += SHIFTS[c]["hours"]

    # 1. конкретные пожелания: по одному дню за круг каждому, кто дальше всех от своей ставки
    wishers = [u for u in emps if not month["avail"][u].get("all")]
    while True:
        placed = False
        for u in sorted(wishers, key=lambda x: used[x] / cap[x]):
            cands = [(b, d) for d in range(1, ndays(ym) + 1) if (b := best(u, d, False))]
            if cands:
                b, d = max(cands, key=lambda x: (x[0][0], -sum(coverage(month, x[1]).values())))
                place(u, d, b[1])
                placed = True
        if not placed:
            break
    # 2. нехватка: ставим того, у кого больше всего недобор часов
    while True:
        cands = [(b, d, u) for d in range(1, ndays(ym) + 1) for u in emps if (b := best(u, d, True))]
        if not cands:
            break
        b, d, u = max(cands, key=lambda x: (x[0][0], -sum(coverage(month, x[1]).values()), -used[x[2]] / cap[x[2]], -x[0][2]))
        place(u, d, b[1])

    def fullness(d, c):
        cov = coverage(month, d)
        return max(cov[p] for p in SHIFTS[c]["covers"])

    def weekends(u):
        return sum(1 for d, day in sched.items() if u in day and date_of(ym, int(d)).weekday() >= 5)

    # 3. добор до ставки: в самые пустые смены (равномерно 3–4 человека), выходные — тем, у кого их меньше
    while True:
        cands = [(fullness(d, b[1]), date_of(ym, d).weekday() >= 5 and weekends(u), d, u, b[1])
                 for u in emps if used[u] + 8 <= cap[u]
                 for d in range(1, ndays(ym) + 1) if (b := best(u, d, False))]
        if not cands:
            break
        _, _, d, u, c = min(cands, key=lambda x: (x[0], x[1], -(cap[x[3]] - used[x[3]]), x[2]))
        place(u, d, c)

    # 4. обмены: если у человека недобор, а все его дни уже заполнены до MAX_PER_SHIFT, переносим с такой
    #    смены другого сотрудника на его свободный день (по его диспозиции), и ставим первого на освободившееся место
    for _ in range(200):
        improved = False
        for u in sorted(emps, key=lambda x: used[x] - cap[x]):
            if used[u] + 8 > cap[u]:
                continue
            for d in range(1, ndays(ym) + 1):
                if improved or u in sched[str(d)]:
                    continue
                for c in options(month, u, d):
                    if improved or used[u] + SHIFTS[c]["hours"] > cap[u]:
                        continue
                    for v, vc in list(sched[str(d)].items()):
                        if vc != c:
                            continue
                        for d2 in range(1, ndays(ym) + 1):
                            if d2 == d or v in sched[str(d2)] or vc not in options(month, v, d2) \
                                    or fullness(d2, vc) >= max_for(month["ym"]):
                                continue
                            del sched[str(d)][v]
                            sched[str(d2)][v] = vc
                            if fullness(d, c) < max_for(month["ym"]):
                                place(u, d, c)
                                improved = True
                                break
                            del sched[str(d2)][v]   # не помогло — откатываем
                            sched[str(d)][v] = vc
                        if improved:
                            break
            if improved:
                break
        if not improved:
            break

    # 5. ремонт нехватки: у всех часы уже кончились, а где-то меньше минимума. Переносим смену человека с дня, где
    #    людей больше минимума, на день с нехваткой, если он отметил этот день в диспозиции. Часы не меняются.
    for _ in range(400):
        moved = False
        short = [(d, p) for d in range(1, ndays(ym) + 1) for p in PERIODS if balance(month, d)[p] < 0]
        for d, p in short:
            for u in emps:
                if u in sched[str(d)]:
                    continue
                opts = [c for c in options(month, u, d) if p in SHIFTS[c]["covers"]
                        and all(coverage(month, d)[q] < max_for(ym) for q in SHIFTS[c]["covers"])]
                for c in sorted(opts, key=lambda x: (-shift_score(month, d, x), SHIFTS[x]["hours"])):
                    for d2, day2 in sorted(sched.items(), key=lambda kv: -min(balance(month, int(kv[0])).values())):
                        c2 = day2.get(u)
                        if not c2 or SHIFTS[c2]["hours"] < SHIFTS[c]["hours"] or int(d2) == d:
                            continue
                        if any(balance(month, int(d2))[q] < 1 for q in SHIFTS[c2]["covers"]):
                            continue   # там тоже станет меньше минимума
                        del day2[u]
                        used[u] += SHIFTS[c]["hours"] - SHIFTS[c2]["hours"]
                        sched[str(d)][u] = c
                        moved = True
                        break
                    if moved:
                        break
                if moved:
                    break
            if moved:
                break
        if not moved:
            break
    save_state(state)


def no_room(state, month, uid):
    """Недобор часов из-за лимита MAX_PER_SHIFT: по диспозиции часы есть, но все его свободные дни заполнены."""
    t = grafik_hours(state, uid, month["ym"])
    if not t or not month["schedule"] or hours_of(month, uid) >= t:
        return False
    cap = avail_hours(month, uid)
    if cap is not None and cap <= hours_of(month, uid):
        return False   # не хватает самой диспозиции, это другой случай
    for d in range(1, ndays(month["ym"]) + 1):
        if uid in month["schedule"][str(d)]:
            continue
        cov = coverage(month, d)
        if any(all(cov[p] < max_for(month["ym"]) for p in SHIFTS[c]["covers"]) for c in options(month, uid, d)):
            return False
    return True


def over_suggestions(state, month):
    """Смены, где людей больше MAX_PER_SHIFT: кого бот предлагает убрать/перенести и варианты замены."""
    sched = month["schedule"]
    if not sched:
        return []
    ym = month["ym"]
    n = ndays(ym)

    def targets(u, d):
        """Куда по диспозиции можно перенести u со дня d, не перегружая смены. Лучшие первыми."""
        res = []
        for d2 in range(1, n + 1):
            if d2 == d or u in sched[str(d2)]:
                continue
            cov, need = coverage(month, d2), need_for(ym, d2)
            for c in options(month, u, d2):
                if any(cov[p] + 1 > max_for(month["ym"]) for p in SHIFTS[c]["covers"]):
                    continue
                gain = sum(need[p] - cov[p] > 0 for p in SHIFTS[c]["covers"])
                res.append({"type": "move", "d2": d2, "code": c, "fills": gain > 0,
                            "score": (gain, -max(cov[p] for p in SHIFTS[c]["covers"]), c == sched[str(d)][u])})
        res.sort(key=lambda x: x["score"], reverse=True)
        for x in res:
            x.pop("score")
        return res

    out, seen = [], set()
    for d in range(1, n + 1):
        cov = coverage(month, d)
        for p in PERIODS:
            if cov[p] <= max_for(month["ym"]):
                continue
            people = [u for u, c in sched[str(d)].items() if p in SHIFTS[c]["covers"] and (u, d) not in seen]
            options_ = []
            for u in people:
                t = grafik_hours(state, u, ym)
                hrs = hours_of(month, u)
                acts = targets(u, d)[:4]
                # некуда перенести или часов больше ставки — убираем смену (максимум на смене — жёсткое правило)
                if not acts or t is None or hrs - SHIFTS[sched[str(d)][u]]["hours"] >= t:
                    acts.append({"type": "remove"})
                if acts:
                    first = acts[0]
                    rank = (first.get("fills", False), first["type"] == "move", (hrs - t) if t else 0)
                    options_.append((rank, u, acts))
            options_.sort(key=lambda x: x[0], reverse=True)
            item = {"d": d, "period": p, "cov": cov[p], "max": max_for(month["ym"])}
            if options_:
                _, u, acts = options_[0]
                seen.add((u, d))
                item.update({"uid": u, "code": sched[str(d)][u], "action": acts[0], "alts_days": acts[1:],
                             "alts_people": [{"uid": x[1], "action": x[2][0]} for x in options_[1:5]]})
            out.append(item)
    return out


def apply_over_action(state, uid, d, action):
    if action.get("type") == "remove":
        return web_set(state, uid, d, None)
    return web_move(state, uid, d, int(action["d2"]), action.get("code"))


def fix_over_all(state):
    """Применяет предложения бота, пока все смены не станут ≤ MAX_PER_SHIFT (насколько позволяют диспозиции)."""
    month = cur_month(state)
    if not month or not month["schedule"]:
        return "Najpierw ułóż grafik."
    done = 0
    for _ in range(200):
        sug = [s for s in over_suggestions(state, month) if s.get("uid")]
        if not sug or apply_over_action(state, sug[0]["uid"], sug[0]["d"], sug[0]["action"]):
            break
        done += 1
    left = len(over_suggestions(state, month))
    log(f"Nadwyżka: zastosowano {done}, zostało {left}")
    return None if not left else f"Zastosowano {done}. Nie da się poprawić {left} zmian: dyspozycje nie pozwalają."


def gaps(month):
    """[(день, половина, число)]: число < 0 — не хватает, > 0 — лишние."""
    res = []
    for d in range(1, ndays(month["ym"]) + 1):
        for p, v in balance(month, d).items():
            if v:
                res.append((d, p, v))
    return res


def outside(state, month):
    """Люди, поставленные не по своей диспозиции (после ручных правок)."""
    res = []
    for d, day in (month["schedule"] or {}).items():
        for u, c in day.items():
            if c not in options(month, u, int(d)):
                res.append(f"{ename(state, u)}: {dlabel(month['ym'], int(d))} {c}")
    return res


def hours_lines(state, month):
    lines = []
    for u in active(state):
        t = grafik_hours(state, u, month["ym"])
        h = hours_of(month, u)
        if t is None:
            lines.append(f"{ename(state, u)}: {h:g} h (bez etatu)")
        else:
            mark = " ⚠️" if h < t else " ➕" if h > t else ""
            if no_room(state, month, u):
                mark = f" ⚪ brak miejsca (wszystkie jego/jej dni mają już {max_for(month["ym"])} osoby)"
            lines.append(f"{ename(state, u)}: {h:g} z {t} h{mark}")
    return lines


def fmt_summary(state, month):
    ym = month["ym"]
    g = gaps(month)
    short = [f"{d:02d} {p} {v}" for d, p, v in g if v < 0]
    extra = [f"{d:02d} {p} +{v}" for d, p, v in g if v > 0]
    lines = [f"Szkic na {month_title(ym)}. Minimum osób: rano {staffing_for(ym)['rano']}, popołudnie {staffing_for(ym)['pop']}"
             + "."]
    lines.append(f"\n⚠️ Brakuje ({len(short)}): " + (", ".join(short) if short else "nigdzie"))
    lines.append(f"➕ Nadwyżka ({len(extra)}): " + (", ".join(extra) if extra else "nigdzie"))
    wait = [u for u in active_in(state, month["ym"]) if u not in month["done"]]
    auto = [ename(state, u) for u in wait if month["avail"].get(u, {}).get("auto")]
    no = [ename(state, u) for u in wait if not month["avail"].get(u, {}).get("auto")]
    if no:
        lines.append(f"\nNie przysłali dyspozycji, nie ma ich w grafiku: {', '.join(no)}")
    if auto:
        lines.append(f"\n🤖 Bez odpowiedzi, przyjęto dowolne dni i zmiany: {', '.join(auto)}")
    out = outside(state, month)
    if out:
        lines.append("\nPoza dyspozycją: " + "; ".join(out))
    lines.append("\nGodziny (⚠️ mniej niż etat, ➕ więcej):")
    lines += hours_lines(state, month)
    return "\n".join(lines)


def make_schedule(state, chat_id):
    month = cur_month(state)
    if not month:
        send(chat_id, f"Najpierw zbierz dyspozycje: «{B_COLLECT}».")
        return
    if month["schedule"]:
        send(chat_id, "Szkic jest już ułożony. Ułożyć od nowa? Ręczne zmiany przepadną.",
             ikb([[btn("🔄 Ułóż od nowa", f"build:{tag(month['ym'])}"),
                   btn("📄 Pokaż obecny", f"show:{tag(month['ym'])}")]]))
        return
    do_build(state, chat_id)


def do_build(state, chat_id):
    month = cur_month(state)
    build_schedule(state, month)
    send_summary(state, chat_id, month, f"Szkic grafiku. Poprawić: «{B_EDIT}», opublikować: «{B_PUB}».")
    web_button(chat_id, "Poprawić grafik wygodniej można w edytorze:")


def send_summary(state, chat_id, month, caption):
    send(chat_id, fmt_summary(state, month))
    send_document(chat_id, write_xlsx(state, month), caption)


# ---------- правка графика ----------

def notify_change(state, month, uid, text):
    if month["published"] and uid in state["employees"]:
        send(uid, f"Zmiana w grafiku na {month_title(month['ym'])}: {text}", EMP_KB)
        history_save(state, month["ym"], "emp", month["schedule"])


def calendar_kb(month):
    ym, t = month["ym"], tag(month["ym"])
    rows = []
    for wk in weeks(ym):
        row = []
        for d in wk:
            bal = balance(month, d).values()
            mark = "⚠️" if any(v < 0 for v in bal) else "➕" if any(v > 0 for v in bal) else ""
            row.append(btn(f"{mark}{d}", f"ed:{t}:{d}"))
        rows.append(row)
    rows.append([btn("📄 Plik Excel", f"show:{t}")])
    return ikb(rows)


def calendar_text(month):
    return (f"{month_title(month['ym']).capitalize()}. Wybierz dzień.\n"
            "⚠️ — brakuje ludzi, ➕ — nadwyżka.")


def start_edit(state, chat_id):
    month = cur_month(state)
    if not month or not month["schedule"]:
        send(chat_id, f"Najpierw ułóż szkic: «{B_BUILD}».")
        return
    send(chat_id, calendar_text(month), calendar_kb(month))


def day_screen(state, month, d):
    ym, t = month["ym"], tag(month["ym"])
    day = month["schedule"][str(d)]
    bal, need, cov = balance(month, d), need_for(ym, d), coverage(month, d)
    lines = [dlabel(ym, d)]
    for p in PERIODS:
        mark = f" ⚠️ brakuje {-bal[p]}" if bal[p] < 0 else f" ➕ nadwyżka {bal[p]}" if bal[p] > 0 else ""
        people = [ename(state, u) + (" (R3)" if c == "R3" else "") for u, c in day.items() if p in SHIFTS[c]["covers"]]
        lines.append(f"{p.capitalize()} {cov[p]}/{need[p]}{mark}: {', '.join(people) or '—'}")
    free = [f"{ename(state, u)} ({'/'.join(options(month, u, d))})"
            for u in active(state) if u not in day and options(month, u, d)]
    lines.append("\nMogą, ale nie są w grafiku: " + (", ".join(free) if free else "nikt"))
    rows = [[btn(f"{ename(state, u)} — {c.split('@')[0]} {SHIFTS[c]['name']}", f"pe:{t}:{d}:{u}")]
            for u, c in sorted(day.items(), key=lambda kv: (kv[1], ename(state, kv[0]))) if u in state["employees"]]
    rows.append([btn("➕ Dodaj osobę", f"ad:{t}:{d}")])
    nav = []
    if d > 1:
        nav.append(btn(f"◀️ {d - 1}", f"ed:{t}:{d - 1}"))
    nav.append(btn("📅 Kalendarz", f"cal:{t}"))
    if d < ndays(ym):
        nav.append(btn(f"{d + 1} ▶️", f"ed:{t}:{d + 1}"))
    rows.append(nav)
    return "\n".join(lines), ikb(rows)


def person_screen(state, month, d, uid):
    ym, t = month["ym"], tag(month["ym"])
    c = month["schedule"][str(d)].get(uid)
    opts = options(month, uid, d)
    th = grafik_hours(state, uid, ym)
    lines = [f"{ename(state, uid)}, {dlabel(ym, d)}: teraz {c} {SHIFTS[c]['name']}.",
             f"Godziny w miesiącu: {hours_of(month, uid):g}" + (f" z {th}" if th is not None else ""),
             "Dyspozycja na ten dzień: " + (", ".join(f"{x} {SHIFTS[x]['name']}" for x in opts) or "nie zaznaczył(a)")]
    rows = [[btn(f"→ {x} {SHIFTS[x]['name']}", f"mv:{t}:{d}:{uid}:{x}")] for x in opts if x != c]
    rows.append([btn("↔️ Przenieś na inny dzień", f"md:{t}:{d}:{uid}")])
    rows.append([btn("🗑 Usuń ze zmiany", f"rmv:{t}:{d}:{uid}")])
    rows.append([btn("⬅️ Wróć do dnia", f"ed:{t}:{d}")])
    return "\n".join(lines), ikb(rows)


def move_day_screen(state, month, d, uid):
    ym, t = month["ym"], tag(month["ym"])
    rows, row = [], []
    for d2 in range(1, ndays(ym) + 1):
        if d2 == d or uid in month["schedule"][str(d2)] or not options(month, uid, d2):
            continue
        mark = "⚠️" if any(v < 0 for v in balance(month, d2).values()) else ""
        row.append(btn(f"{mark}{d2}", f"mt:{t}:{d}:{uid}:{d2}"))
        if len(row) == 6:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([btn("⬅️ Wróć", f"pe:{t}:{d}:{uid}")])
    text = (f"Na który dzień przenieść {ename(state, uid)} z {d:02d}? Pokazane są dni z dyspozycji, "
            "w których ta osoba jeszcze nie pracuje. ⚠️ — tam brakuje ludzi." if len(rows) > 1
            else f"{ename(state, uid)} nie ma innych wolnych dni w dyspozycji.")
    return text, ikb(rows)


def add_screen(state, month, d):
    ym, t = month["ym"], tag(month["ym"])
    day = month["schedule"][str(d)]
    rows = []
    for u in active(state):
        opts = options(month, u, d)
        if u in day or not opts:
            continue
        th = grafik_hours(state, u, ym)
        h = f"{hours_of(month, u):g}" + (f"/{th}" if th is not None else "") + " h"
        rows.append([btn(f"{ename(state, u)} · {h} · {'/'.join(opts)}", f"au:{t}:{d}:{u}")])
    text = (f"{dlabel(ym, d)}: kogo dodać? Pokazane są osoby, które zaznaczyły ten dzień, i ich godziny."
            if rows else f"{dlabel(ym, d)}: nikt więcej nie zaznaczył tego dnia.")
    rows.append([btn("⬅️ Wróć do dnia", f"ed:{t}:{d}")])
    return text, ikb(rows)


def add_code_screen(state, month, d, uid):
    t = tag(month["ym"])
    rows = [[btn(sh_text(c), f"ac:{t}:{d}:{uid}:{c}")] for c in options(month, uid, d)]
    rows.append([btn("⬅️ Wróć", f"ad:{t}:{d}")])
    return f"{ename(state, uid)}, {dlabel(month['ym'], d)}: która zmiana?", ikb(rows)


def edit_callback(state, chat_id, msg, data):
    month = cur_month(state)
    p = data.split(":")
    if not month or not month["schedule"] or p[1] != tag(month["ym"]):
        edit(chat_id, msg["message_id"], "Ten grafik jest już nieaktualny.")
        return
    kind, ym, mid = p[0], month["ym"], msg["message_id"]
    sched = month["schedule"]
    if kind == "cal":
        edit(chat_id, mid, calendar_text(month), calendar_kb(month))
        return
    d = int(p[2])
    if kind == "ed":
        edit(chat_id, mid, *day_screen(state, month, d))
    elif kind == "pe":
        if p[3] not in sched[str(d)]:
            edit(chat_id, mid, *day_screen(state, month, d))
        else:
            edit(chat_id, mid, *person_screen(state, month, d, p[3]))
    elif kind == "mv":
        uid, c = p[3], p[4]
        sched[str(d)][uid] = c
        save_state(state)
        notify_change(state, month, uid, f"{dlabel(ym, d)} — teraz {sh_text(c)}.")
        edit(chat_id, mid, *day_screen(state, month, d))
    elif kind == "md":
        edit(chat_id, mid, *move_day_screen(state, month, d, p[3]))
    elif kind == "mt":
        uid, d2 = p[3], int(p[4])
        old = sched[str(d)].pop(uid, None)
        opts = options(month, uid, d2)
        c = old if old in opts else max(opts, key=lambda x: shift_score(month, d2, x))
        sched[str(d2)][uid] = c
        save_state(state)
        notify_change(state, month, uid, f"zmiana z {dlabel(ym, d)} przeniesiona na {dlabel(ym, d2)}, {sh_text(c)}.")
        edit(chat_id, mid, *day_screen(state, month, d2))
    elif kind == "rmv":
        uid = p[3]
        sched[str(d)].pop(uid, None)
        save_state(state)
        notify_change(state, month, uid, f"{dlabel(ym, d)} — zmiana usunięta.")
        edit(chat_id, mid, *day_screen(state, month, d))
    elif kind == "ad":
        edit(chat_id, mid, *add_screen(state, month, d))
    elif kind == "au":
        edit(chat_id, mid, *add_code_screen(state, month, d, p[3]))
    elif kind == "ac":
        uid, c = p[3], p[4]
        sched[str(d)][uid] = c
        save_state(state)
        notify_change(state, month, uid, f"dodana zmiana {dlabel(ym, d)}, {sh_text(c)}.")
        edit(chat_id, mid, *day_screen(state, month, d))


# ---------- публикация и доп. смены ----------

def personal(state, month, uid):
    ym = month["ym"]
    lines = []
    for d in range(1, ndays(ym) + 1):
        c = month["schedule"][str(d)].get(uid)
        if c:
            lines.append(f"{dlabel(ym, d)} — {sh_text(c)}")
    if not lines:
        return f"W grafiku na {month_title(ym)} nie masz zmian."
    th = grafik_hours(state, uid, ym)
    total = f"\n\nRazem: zmian {len(lines)}, godzin {hours_of(month, uid):g}" + (f" z {th}." if th else ".")
    return f"Twój grafik na {month_title(ym)}:\n" + "\n".join(lines) + total


def ask_publish(state, chat_id):
    month = cur_month(state)
    if not month or not month["schedule"]:
        send(chat_id, f"Najpierw ułóż szkic: «{B_BUILD}».")
        return
    if month["published"]:
        send(chat_id, "Grafik jest już opublikowany. Pracownicy od razu dostają każdą zmianę.")
        return
    short = sum(1 for *_, v in gaps(month) if v < 0)
    warn = f"⚠️ Wciąż brakuje ludzi na {short} zmianach — pracownicy będą mogli się na nie zgłosić. " \
        if short else ""
    send(chat_id, f"{warn}Opublikować grafik na {month_title(month['ym'])}?",
         ikb([[btn("📤 Tak, opublikuj", f"pub:{tag(month['ym'])}"), btn("Jeszcze nie", "noop")]]))


def publish(state, chat_id):
    month = cur_month(state)
    month["published"] = True
    history_save(state, month["ym"], "emp", month["schedule"])
    if month.get("showcase"):
        showcase_requests(state, month["ym"])
    short = any(v < 0 for *_, v in gaps(month))
    ok = 0
    for u in active(state):
        tail = f"\n\nSą zmiany, na których brakuje ludzi: «{B_EXTRA}»." if short else ""
        ok += send(u, f"📅 Grafik na {month_title(month['ym'])} jest gotowy!\n\n" + personal(state, month, u) + tail,
                   EMP_KB)
    send(chat_id, f"Grafik opublikowany, powiadomienie dostało {ok} z {len(active(state))}.", DIR_KB)
    send_document(chat_id, write_xlsx(state, month), f"Grafik {month_title(month['ym'])}")


def published_month(state):
    done = [m for ym, m in sorted(state["months"].items()) if m["published"]]
    return done[-1] if done else None


def my_schedule(state, uid):
    month = published_month(state)
    if not month:
        send(uid, "Grafik nie jest jeszcze opublikowany.", EMP_KB)
        return
    send(uid, personal(state, month, uid), EMP_KB)
    # ближайшие смены: можно сообщить, что не выйдешь — директор сразу получит кнопку поиска замены
    today = dt.date.today()
    upcoming = [int(d) for d, day in sorted(month["schedule"].items(), key=lambda x: int(x[0]))
                if uid in day and date_of(month["ym"], int(d)) >= today][:6]
    if upcoming:
        send(uid, "Nie możesz przyjść na zmianę? Daj znać kierownikowi:",
             ikb([[btn(f"🤒 Nie mogę przyjść: {dlabel(month['ym'], d)}", f"cant:{d}")] for d in upcoming]))


def extra_shifts(state, uid):
    month = published_month(state)
    if not month:
        send(uid, "Grafik nie jest jeszcze opublikowany.", EMP_KB)
        return
    ym, t = month["ym"], tag(month["ym"])
    mine = {(r["day"], r["code"]) for r in month["requests"] if r["uid"] == uid and r["status"] == "pending"}
    rows = []
    for d in range(1, ndays(ym) + 1):
        if date_of(ym, d) < dt.date.today() or uid in month["schedule"][str(d)]:
            continue
        bal = balance(month, d)
        for c in CODES:
            covers = SHIFTS[c]["covers"]
            if not all(bal[p] < 0 for p in covers) or (d, c) in mine:
                continue
            n = -max(bal[p] for p in covers)
            rows.append([btn(f"{dlabel(ym, d)} {c} {SHIFTS[c]['name']} (brakuje {n})", f"xr:{t}:{d}:{c}")])
    if not rows:
        send(uid, "Teraz wszystkie zmiany są obsadzone." + (" Twoje prośby czekają na kierownika." if mine else ""),
             EMP_KB)
        return
    send(uid, "Tu brakuje ludzi. Kliknij, żeby zgłosić się na zmianę, kierownik zatwierdzi:", ikb(rows[:60]))


def request_extra(state, uid, msg, d, c):
    month = published_month(state)
    ym = month["ym"]
    if uid in month["schedule"][str(d)]:
        edit(uid, msg["message_id"], "Tego dnia już jesteś w grafiku.")
        return
    if is_closed(ym, d):
        edit(uid, msg["message_id"], "Tego dnia basen jest zamknięty.")
        return
    rid = state["next_req"]
    state["next_req"] += 1
    month["requests"].append({"id": rid, "uid": uid, "day": d, "code": c, "status": "pending"})
    save_state(state)
    what = f"{dlabel(ym, d)}, {sh_text(c)}"
    edit(uid, msg["message_id"], f"Prośba wysłana do kierownika: {what}. Bot napisze odpowiedź.")
    th = grafik_hours(state, uid, ym)
    hrs = f"{hours_of(month, uid):g}" + (f" z {th}" if th is not None else "") + " h"
    for a in admin_ids(state):
        send(a, f"🙋 {ename(state, uid)} zgłasza się na dodatkową zmianę: {what}. Teraz ma {hrs}.",
             ikb([[btn("✅ Zatwierdź", f"xa:{rid}"), btn("❌ Odrzuć", f"xn:{rid}")]]))


def find_request(state, rid):
    for m in state["months"].values():
        for r in m["requests"]:
            if r["id"] == rid:
                return m, r
    return None, None


def answer_request(state, chat_id, msg, rid, yes):
    month, r = find_request(state, rid)
    if not r or r["status"] != "pending":
        edit(chat_id, msg["message_id"], "Ta prośba została już rozpatrzona.")
        return
    ym, d, c, uid = month["ym"], r["day"], r["code"], r["uid"]
    what = f"{dlabel(ym, d)}, {sh_text(c)}"
    note = ""
    if yes and uid in month["schedule"][str(d)]:
        yes = False
        note = " (tego dnia ta osoba jest już w grafiku)"
    r["status"] = "approved" if yes else "rejected"
    if yes:
        month["schedule"][str(d)][uid] = c
    save_state(state)
    edit(chat_id, msg["message_id"], f"{'✅ Zatwierdzono' if yes else '❌ Odrzucono'}{note}: {ename(state, uid)}, {what}.")
    send(uid, f"Kierownik {'zatwierdził' if yes else 'odrzucił'} prośbę o dodatkową zmianę: {what}.", EMP_KB)


def list_requests(state, chat_id):
    pend = [(m, r) for m in state["months"].values() for r in m["requests"] if r["status"] == "pending"]
    vac = [v for v in VACATIONS if v["status"] == "pending"]
    for v in vac:
        send(chat_id, vac_admin_text(state, v), vac_admin_kb(v))
    if not pend:
        if not vac:
            send(chat_id, "Brak nowych próśb o dodatkowe zmiany i urlop.")
        return
    for m, r in pend:
        send(chat_id, f"🙋 {ename(state, r['uid'])}: {dlabel(m['ym'], r['day'])}, {sh_text(r['code'])}",
             ikb([[btn("✅ Zatwierdź", f"xa:{r['id']}"), btn("❌ Odrzuć", f"xn:{r['id']}")]]))


# ---------- wnioski urlopowe ----------
# Сотрудник выбирает даты «od–do» (в «Grafik» или текстом в боте) и отправляет заявку. Директор получает
# «✅ Zatwierdź / ❌ Odrzuć». Zatwierdzony urlop: дни помечаются кодом U (цветом в «Grafik» и в Excel),
# в эти дни человека нельзя поставить на смену, уже стоящие смены снимаются; в норму идут 8 ч за каждый
# рабочий день (пн–пт без праздников). Хранится в state["vacations"].

VAC_MAX_DAYS = 60
B_VAC = "🌴 Urlop"


def vac_fmt(iso):
    d = dt.date.fromisoformat(iso)
    return f"{DAYS[d.weekday()]} {d:%d.%m.%Y}"


def vac_period(v):
    return vac_fmt(v["from"]) if v["from"] == v["to"] else f"{vac_fmt(v['from'])} – {vac_fmt(v['to'])}"


def vac_stats(a, b):
    """(дней всего, рабочих дней) в периоде a..b (date)."""
    total = (b - a).days + 1
    work = sum(1 for i in range(total) if (a + dt.timedelta(i)).weekday() < 5
               and (a + dt.timedelta(i)) not in holidays_pl((a + dt.timedelta(i)).year))
    return total, work


def vac_check(state, uid, a, b, skip_id=None):
    """Ошибка или None: даты в порядке, не в прошлом, не дольше VAC_MAX_DAYS, нет пересечения с другой заявкой."""
    today = dt.date.today()
    if b < a:
        return "Data końca jest wcześniejsza niż data początku."
    if a < today:
        return "Urlop nie może zaczynać się w przeszłości."
    if (b - a).days + 1 > VAC_MAX_DAYS:
        return f"Najdłużej {VAC_MAX_DAYS} dni w jednym wniosku."
    for v in VACATIONS:
        if v["uid"] == uid and v["id"] != skip_id and v["status"] in ("pending", "approved") \
                and not (b < dt.date.fromisoformat(v["from"]) or a > dt.date.fromisoformat(v["to"])):
            return f"W tym okresie masz już wniosek ({vac_period(v)}, {VAC_STATUS[v['status']]})."
    return None


VAC_STATUS = {"pending": "⏳ czeka na kierownika", "approved": "✅ zatwierdzony", "rejected": "❌ odrzucony",
              "cancelled": "↩️ wycofany"}


def vac_parse(text):
    """«3-7.12», «3.12-7.12», «28.12.2026-2.01.2027», «15.12» → (date от, date до) или None."""
    t = text.strip().replace(" ", "").replace("–", "-").replace("—", "-").replace("/", ".")
    m = re.fullmatch(r"(\d{1,2})(?:\.(\d{1,2})(?:\.(\d{2,4}))?)?(?:-(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?)?\.?", t)
    if not m:
        return None
    d1, m1, y1, d2, m2, y2 = m.groups()
    if not m1 and not m2:
        return None
    today = dt.date.today()

    def mk(d, mo, y):
        y = int(y) + (2000 if y and len(y) == 2 else 0) if y else today.year
        x = dt.date(y, int(mo), int(d))
        return x
    try:
        if m2:
            b = mk(d2, m2, y2)
            a = mk(d1, m1 or m2, y1 or (str(b.year) if not y1 else None))
            if not y2 and b < today - dt.timedelta(days=1):
                b, a = b.replace(year=b.year + 1), a.replace(year=a.year + 1)
            if a > b and not y1:
                a = a.replace(year=a.year - 1)
        else:
            a = b = mk(d1, m1, y1)
            if not y1 and a < today - dt.timedelta(days=1):
                a = b = a.replace(year=a.year + 1)
    except ValueError:
        return None
    return a, b


def vac_admin_text(state, v):
    a, b = dt.date.fromisoformat(v["from"]), dt.date.fromisoformat(v["to"])
    total, work = vac_stats(a, b)
    taken = sum(vac_stats(dt.date.fromisoformat(x["from"]), dt.date.fromisoformat(x["to"]))[1]
                for x in VACATIONS if x["uid"] == v["uid"] and x["status"] == "approved"
                and x["from"][:4] == v["from"][:4])
    clash = [f"{dlabel(ym, d)}" for ym, d in vac_shift_days(state, v)]
    return (f"🌴 {ename(state, v['uid'])} prosi o urlop: {vac_period(v)}\n"
            f"{total} dni, w tym {work} roboczych ({work * 8} h do normy)."
            + (f"\nZatwierdzony urlop w {v['from'][:4]}: {taken} dni roboczych." if taken else "")
            + (f"\n⚠️ Ma już zmiany w grafiku: {', '.join(clash[:10])}. Po zatwierdzeniu zostaną zdjęte." if clash else "")
            + (f"\nKomentarz: {v['note']}" if v.get("note") else ""))


def vac_admin_kb(v):
    return ikb([[btn("✅ Zatwierdź", f"vac:ok:{v['id']}"), btn("❌ Odrzuć", f"vac:no:{v['id']}")]])


def vac_shift_days(state, v):
    """[(ym, день)] где у человека уже стоит смена (обычный график или для кадр) в дни заявки."""
    res = []
    for ym, m in sorted(state["months"].items()):
        for d in vac_days_in(v, ym):
            if v["uid"] in (m.get("schedule") or {}).get(str(d), {}) or \
                    v["uid"] in ((kadry_of(m).get("sched") or {}).get(str(d), {})):
                res.append((ym, d))
    return res


def vac_create(state, uid, a, b, note=""):
    """Новая заявка на urlop. Возвращает (заявка, ошибка)."""
    err = vac_check(state, uid, a, b)
    if err:
        return None, err
    vid = state.get("next_vac", 1)
    state["next_vac"] = vid + 1
    v = {"id": vid, "uid": uid, "from": a.isoformat(), "to": b.isoformat(), "status": "pending",
         "at": time.strftime("%Y-%m-%d %H:%M"), "note": (note or "")[:300]}
    VACATIONS.append(v)
    save_state(state)
    for adm in admin_ids(state):
        if adm != uid:
            send(adm, vac_admin_text(state, v), vac_admin_kb(v))
    log(f"Wniosek urlopowy: {ename(state, uid)} {v['from']}..{v['to']}")
    return v, None


def vac_find(vid):
    return next((v for v in VACATIONS if v["id"] == vid), None)


def vac_decide(state, admin, vid, ok):
    """Директор принимает или отклоняет заявку. Возвращает (текст для директора, ошибка)."""
    v = vac_find(vid)
    if not v:
        return None, "Nie ma takiego wniosku."
    if v["status"] != "pending":
        return None, f"Ten wniosek jest już rozpatrzony: {VAC_STATUS[v['status']]}."
    v.update(status="approved" if ok else "rejected", by=admin, decided=time.strftime("%Y-%m-%d %H:%M"))
    name, per = ename(state, v["uid"]), vac_period(v)
    if not ok:
        save_state(state)
        send(v["uid"], f"❌ Kierownik nie zatwierdził urlopu: {per}. W razie pytań porozmawiaj z kierownikiem.", EMP_KB)
        log(f"Urlop odrzucony: {name} {per}")
        return f"❌ Odrzucono urlop: {name}, {per}.", None
    removed = []
    for ym, d in vac_shift_days(state, v):
        m = state["months"][ym]
        code = (m.get("schedule") or {}).get(str(d), {}).pop(v["uid"], None)
        (kadry_of(m).get("sched") or {}).get(str(d), {}).pop(v["uid"], None)
        removed.append(dlabel(ym, d) + (f" {code}" if code else ""))
    save_state(state)
    a, b = dt.date.fromisoformat(v["from"]), dt.date.fromisoformat(v["to"])
    total, work = vac_stats(a, b)
    send(v["uid"], f"✅ Urlop zatwierdzony: {per} ({work} dni roboczych). W grafiku te dni są oznaczone jako U."
                   + (f"\nZdjęto Twoje zmiany: {', '.join(removed)}." if removed else ""), EMP_KB)
    log(f"Urlop zatwierdzony: {name} {per}" + (f", zdjęte zmiany: {', '.join(removed)}" if removed else ""))
    over = []
    for ym in sorted(state["months"]):
        m = state["months"][ym]
        th = grafik_hours(state, v["uid"], ym)
        if m.get("schedule") and vac_days_in(v, ym) and th is not None and hours_of(m, v["uid"]) > th:
            over.append(f"{month_title(ym)}: {hours_of(m, v['uid']):g} h z {th} h normy")
    return (f"✅ Zatwierdzono urlop: {name}, {per} ({work} dni roboczych = {work * 8} h do normy)."
            + (f"\n⚠️ Zdjęto zmiany: {', '.join(removed)}. Sprawdź braki w «✏️ Edytuj grafik»." if removed else "")
            + (f"\n⚠️ Z urlopem ma za dużo godzin ({'; '.join(over)}). Warto zdjąć część zmian." if over else "")), None


def vac_cancel(state, uid, vid):
    """Сотрудник отзывает свою заявку, пока директор её не рассмотрел."""
    v = vac_find(vid)
    if not v or v["uid"] != uid:
        return "Nie ma takiego wniosku."
    if v["status"] != "pending":
        return "Wniosek jest już rozpatrzony. Jeśli chcesz coś zmienić, napisz do kierownika."
    v["status"] = "cancelled"
    save_state(state)
    for adm in admin_ids(state):
        if adm != uid:
            send(adm, f"↩️ {ename(state, uid)} wycofał(a) wniosek o urlop: {vac_period(v)}.")
    return None


def vac_list_text(uid):
    mine = [v for v in VACATIONS if v["uid"] == uid and v["status"] != "cancelled"][-8:]
    return "\n".join(f"• {vac_period(v)}: {VAC_STATUS[v['status']]}" for v in mine)


def vac_start(state, uid):
    """Кнопка «🌴 Urlop» в боте: свои заявки и просьба написать даты."""
    state["wiz"][uid] = {"step": "vac"}
    save_state(state)
    mine = vac_list_text(uid)
    pend = [v for v in VACATIONS if v["uid"] == uid and v["status"] == "pending"]
    send(uid, (f"Twoje wnioski:\n{mine}\n\n" if mine else "") +
         "🌴 Napisz daty urlopu, od kiedy do kiedy, np.:\n3.12-7.12\n22-31.12\n28.12-4.01\n\n"
         "Wygodniej: w «Grafik» przycisk «🌴 Wniosek o urlop» z kalendarzem.",
         ikb([[btn(f"↩️ Wycofaj: {vac_period(v)}", f"vac:del:{v['id']}")] for v in pend]
             + [[btn("Anuluj", "vac:stop")]]))


def vac_text(state, uid, text):
    """Ответ сотрудника с датами после «🌴 Urlop»."""
    r = vac_parse(text)
    if not r:
        send(uid, "Nie rozumiem dat. Napisz np. 3.12-7.12 albo 15.12 (jeden dzień).")
        return
    a, b = r
    err = vac_check(state, uid, a, b)
    if err:
        send(uid, "⚠️ " + err)
        return
    total, work = vac_stats(a, b)
    state["wiz"][uid] = {"step": "vacok", "from": a.isoformat(), "to": b.isoformat()}
    save_state(state)
    send(uid, f"🌴 Urlop: {vac_period({'from': a.isoformat(), 'to': b.isoformat()})}\n"
              f"{total} dni, w tym {work} roboczych. Wysłać wniosek do kierownika?",
         ikb([[btn("✅ Wyślij", "vac:send"), btn("Anuluj", "vac:stop")]]))


def vac_callback(state, uid, msg, p, is_admin):
    act = p[1] if len(p) > 1 else ""
    if act in ("ok", "no") and is_admin:
        text, err = vac_decide(state, uid, int(p[2]), act == "ok")
        edit(uid, msg["message_id"], err or text)
    elif act == "send":
        w = state["wiz"].pop(uid, None) or {}
        if w.get("step") != "vacok":
            edit(uid, msg["message_id"], "To jest już nieaktualne.")
            return
        v, err = vac_create(state, uid, dt.date.fromisoformat(w["from"]), dt.date.fromisoformat(w["to"]))
        edit(uid, msg["message_id"], ("⚠️ " + err) if err else
             f"📨 Wniosek o urlop wysłany: {vac_period(v)}. Napiszę, gdy kierownik go rozpatrzy.")
    elif act == "del":
        err = vac_cancel(state, uid, int(p[2]))
        edit(uid, msg["message_id"], err or "↩️ Wniosek wycofany.")
    elif act == "stop":
        state["wiz"].pop(uid, None)
        save_state(state)
        edit(uid, msg["message_id"], "Dobrze, anulowałem.")


def vac_payload(state, uid=None):
    """Заявки для «Grafik»: свои (сотрудник) или ждущие решения (директор)."""
    out = []
    for v in VACATIONS:
        if (uid and v["uid"] != uid) or (not uid and v["status"] != "pending") or v["status"] == "cancelled":
            continue
        a, b = dt.date.fromisoformat(v["from"]), dt.date.fromisoformat(v["to"])
        total, work = vac_stats(a, b)
        out.append({"id": v["id"], "uid": v["uid"], "name": ename(state, v["uid"]), "from": v["from"], "to": v["to"],
                    "period": vac_period(v), "days": total, "work": work, "status": v["status"],
                    "status_text": VAC_STATUS[v["status"]]})
    return out[-12:] if uid else out


# ---------- grafik dla kadr (официальный график по Kodeks pracy) ----------
# Отдельная версия графика: только R1/R2, ставится независимо от диспозиции, проверяются правила:
# 11 ч отдыха между сменами, 35 ч непрерывного отдыха в каждой неделе (пн–вс), не больше 3 воскресений
# подряд (с учётом прошлого месяца). Хранится в month["kadry"]["sched"], как и обычный график: {день: {uid: код}}.

KADRY_CODES = ["R1", "R2"]
R4_START = "10:00"   # как в файле бассейна: R4 начинается в 10:00, длина — недостающие часы
R4_MAX_H = 8
DAILY_REST_H = int_env("DAILY_REST_H", 11)
WEEKLY_REST_H = int_env("WEEKLY_REST_H", 35)
DAY = dt.timedelta(days=1)


def r4_code(hours, start=R4_START):
    h, m = [int(x) for x in start.split(":")]
    end = h * 60 + m + round(hours * 60)
    return f"R4@{h:02d}:{m:02d}-{end // 60:02d}:{end % 60:02d}"


def is_kadry_code(code):
    return code in KADRY_CODES or bool(re.fullmatch(r"R\d@\d\d:\d\d-\d\d:\d\d", str(code)))


def dyn_shifts(*scheds):
    """Описание смен с произвольным временем для редактора (R4 и R3 из импорта)."""
    codes = {c for sc in scheds for day in (sc or {}).values() for c in day.values() if "@" in c}
    return {c: {"name": SHIFTS[c]["name"], "time": SHIFTS[c]["time"], "hours": SHIFTS[c]["hours"],
                "covers": [PERIODS.index(p) for p in SHIFTS[c]["covers"]]} for c in sorted(codes)}


def shift_span(code):
    (h1, m1), (h2, m2) = [(int(a), int(b)) for a, b in re.findall(r"(\d{1,2}):(\d{2})", SHIFTS[code]["time"])[:2]]
    s, e = h1 + m1 / 60, h2 + m2 / 60
    return s, e if e > s else e + 24


def prev_ym(ym):
    y, m = ym_parts(ym)
    return f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"


def kadry_of(month):
    return month.setdefault("kadry", {"sched": None, "prev_sundays": {}})


def prev_source(state, ym):
    """График прошлого месяца для правил: история (сначала «для кадр»), иначе месяц в работе."""
    pym = prev_ym(ym)
    h = state.get("history", {}).get(pym) or {}
    pm = state["months"].get(pym) or {}
    sched = ((h.get("kadry") or {}).get("sched") or (pm.get("kadry") or {}).get("sched")
             or (h.get("emp") or {}).get("sched") or pm.get("schedule"))
    return (pym, sched) if sched else (None, None)


# ---------- historia grafików ----------
# state["history"][ym] = {"emp": {...}, "kadry": {...}, "names": {uid: имя}}; версия = {"sched", "at", "source"}.
# emp — график для сотрудников (сохраняется при отправке и каждой правке после неё), kadry — при экспорте в кадры
# или импорте Excel. Хранится последняя версия каждого вида с отметкой времени.

def history_save(state, ym, kind, sched, source="bot"):
    import copy
    h = state.setdefault("history", {}).setdefault(ym, {})
    if source == "bot" and state.get("mode") == "test":
        source = "test"   # всё, что сохранено в тестовом режиме, при «Start» удаляется
    h[kind] = {"sched": copy.deepcopy(sched), "at": time.strftime("%Y-%m-%d %H:%M"), "source": source}
    names = h.setdefault("names", {})
    for day in sched.values():
        for u in day:
            if u in state["employees"]:
                names[u] = state["employees"][u]["name"]
    save_state(state)


def history_list(state):
    return [{"ym": ym, "title": month_title(ym), "kinds": [k for k in ("emp", "kadry") if h.get(k)],
             "source": (h.get("kadry") or h.get("emp") or {}).get("source", "")}
            for ym, h in sorted(state.get("history", {}).items(), reverse=True)]


def history_payload(state, ym):
    h = state.get("history", {}).get(ym)
    if not h:
        return None
    n = ndays(ym)
    hol = holidays_pl(ym_parts(ym)[0])
    versions = {k: (h.get(k) or {}).get("sched") or {} for k in ("emp", "kadry")}
    uids = list(dict.fromkeys([u for s in versions.values() for day in s.values() for u in day]))
    name = lambda u: h.get("names", {}).get(u) or ename(state, u)
    days = []
    for d in range(1, n + 1):
        day, need = date_of(ym, d), need_for(ym, d)
        cov = {k: [sum(p in SHIFTS[c]["covers"] for c in s.get(str(d), {}).values()) for p in PERIODS]
               for k, s in versions.items()}
        days.append({"d": d, "wd": DAYS[day.weekday()], "off": day.weekday() >= 5 or day in hol, "closed": is_closed(ym, d),
                     "need": [need[p] for p in PERIODS], "cov_emp": cov["emp"], "cov_kadry": cov["kadry"]})
    emps = []
    for u in sorted(uids, key=lambda x: name(x).lower()):
        e = {"uid": u, "name": name(u), "target": target_hours(state, u, ym) if u in state["employees"] else None,
             "etat": ETATS.get(etat_for(state, u, ym), ETATS["1"])[0]}
        for k, s in versions.items():
            mine = {d: day[u] for d, day in s.items() if u in day}
            e[k], e["hours_" + k] = mine, sum(SHIFTS[c]["hours"] for c in mine.values())
        emps.append(e)
    return {"ym": ym, "title": month_title(ym), "days": days, "emps": emps, "shifts": dyn_shifts(*versions.values()),
            "at": {k: (h.get(k) or {}).get("at") for k in ("emp", "kadry")},
            "source": {k: (h.get(k) or {}).get("source") for k in ("emp", "kadry")}}


def history_excel(state, ym, chats):
    h = state.get("history", {}).get(ym)
    if not h:
        return "Nie ma tego miesiąca w historii."
    for kind, label in (("emp", "Grafik pracowników"), ("kadry", "Grafik dla kadr")):
        if h.get(kind):
            path = write_kadry_xlsx(state, {"ym": ym, "kadry": {"sched": h[kind]["sched"]}},
                                    fname=f"Historia {label} {ym}.xlsx", names=h.get("names"))
            for c in chats:
                send_document(c, path, f"Historia: {label}, {month_title(ym)} (zapis {h[kind]['at']})")
    return None


def import_template(state, chats):
    """Пустой шаблон в том же формате, что экспорт «для кадр», на прошлый месяц."""
    ym = prev_ym(cur_month(state)["ym"]) if cur_month(state) else prev_ym(next_ym(dt.date.today()))
    path = write_kadry_xlsx(state, {"ym": ym, "kadry": {"sched": {}}}, fname=f"Wzór importu {ym}.xlsx")
    for c in chats:
        send_document(c, path, f"Wzór do importu historii: {month_title(ym)}")
        send(c, "Wpisz w komórkach zmiany (R1, R2 albo godziny 06:00-14:00 / 14:00-22:00) i wyślij mi ten plik "
                "jako dokument w tym czacie. Miesiąc rozpoznam po datach w nagłówku. Można też wysłać plik "
                "«Grafik dla kadr» z innego miesiąca.")
    return None


def norm_name(s):
    import unicodedata
    s = re.sub(r"\(test\)", "", str(s or "")).strip().lower()
    s = "".join(c for c in unicodedata.normalize("NFKD", s.replace("ł", "l")) if not unicodedata.combining(c))
    return " ".join(s.split())


def name_key(name):
    """Ключ имени без учёта порядка слов: «CICHOCKI JAKUB» = «Jakub Cichocki»."""
    return " ".join(sorted(norm_name(name).split()))


def emp_hist_key(state, uid):
    """Ключ, под которым человек мог попасть в историю до регистрации (импорт по имени)."""
    return "name:" + name_key(ename(state, uid))


# ---------- import historii z Excela ----------
# Понимает два формата:
#  • шаблон бота («📥 Wzór do importu» / «Grafik dla kadr»): строка заголовков с датами «dd.mm …»;
#  • годовой файл бассейна: по листу на месяц (STYCZEŃ…GRUDZIEŃ), строки «Dzień tyg» и «Numer dnia»,
#    под ними сотрудники (№ | ФАМИЛИЯ ИМЯ | коды по дням), строки «Czas zmiany»/«Czas opłacony» пропускаются.
# Коды: R1/R2/R3 (или часы 06:00-14:00 / 14:00-22:00) — смены; U, L4, ZW, UŻ, UNŻ — отсутствие; X, W — выходной.
# Кто ещё не зарегистрирован, сохраняется по имени («name:…») и потом сам связывается с сотрудником.

PL_MONTHS = {"STYCZEN": 1, "LUTY": 2, "MARZEC": 3, "KWIECIEN": 4, "MAJ": 5, "CZERWIEC": 6, "LIPIEC": 7,
             "SIERPIEN": 8, "WRZESIEN": 9, "PAZDZIERNIK": 10, "LISTOPAD": 11, "GRUDZIEN": 12}
PL_WD = {"pon": 0, "pn": 0, "wt": 1, "sr": 2, "śr": 2, "czw": 3, "cz": 3, "pt": 4, "so": 5, "sob": 5, "sb": 5,
         "nie": 6, "nd": 6, "niedz": 6}
ABSENCE_CODES = {"KRW", "U", "L4", "ZW", "UZ", "UŻ", "UNZ", "UNŻ", "UW", "CH"}   # urlop, L4/zwolnienie, urlop na żądanie…


def time_span(v):
    """«10:00 \\n14:00» → «10:00-14:00»; None, если в тексте нет двух времён."""
    t = re.findall(r"(\d{1,2}):(\d{2})", str(v or ""))
    return f"{int(t[0][0]):02d}:{t[0][1]}-{int(t[1][0]):02d}:{t[1][1]}" if len(t) >= 2 else None


def import_code(v, when=None):
    """Ячейка → ("shift", код) | ("absent", код) | None. when — строка «Czas zmiany» под ячейкой (файл бассейна).
    Коды: R1/R2 со стандартным временем, иначе «R4@10:00-14:00», «R3@10:00-16:00» с часами из файла."""
    v = str(v or "").strip().upper().replace("–", "-")
    if not v:
        return None
    flat = v.replace(" ", "")
    if flat in ABSENCE_CODES:
        return "absent", flat
    own = time_span(v)
    m = re.match(r"R[1-4]\b", v)
    label = m.group(0) if m and (v == m.group(0) or own) else None
    if not label and not own:
        return None
    t = own or time_span(when)
    if not label:
        std = next((c for c in KADRY_CODES if t == time_span(SHIFTS[c]["time"])), None)
        return "shift", std or f"R4@{t}"
    if label in CODES and (not t or t == time_span(SHIFTS[label]["time"])):
        return "shift", label
    if t:
        return "shift", f"{label}@{t}"
    return "shift", label   # R4 без времени: длину считает parse_import (недостающее до SUMA)


def import_target(state, by_key, name):
    """uid сотрудника по имени или ключ «name:…» для ещё не зарегистрированных."""
    return by_key.get(name_key(name)) or by_key.get("~" + link_key(name)) or "name:" + name_key(name)


def parse_template_sheet(state, ws, by_key):
    rows = list(ws.iter_rows(values_only=True))
    hdr_i = next((i for i, r in enumerate(rows[:10])
                  if sum(bool(re.match(r"^\d{2}\.\d{2}", str(c or ""))) for c in r) >= 20), None)
    if hdr_i is None:
        return None
    cols = {j: (int(m.group(1)), int(m.group(2))) for j, c in enumerate(rows[hdr_i])
            if (m := re.match(r"^(\d{2})\.(\d{2})", str(c or "")))}
    month_no = max(set(m for _, m in cols.values()), key=list(m for _, m in cols.values()).count)
    today = dt.date.today()
    ym = f"{today.year if month_no <= today.month + 1 else today.year - 1}-{month_no:02d}"
    out = {"ym": ym, "rows": {}}
    for r in rows[hdr_i + 1:]:
        if r and r[0] and not str(r[0]).startswith("KRW"):   # строка легенды — не сотрудник
            out["rows"][str(r[0]).strip()] = {d: r[j] for j, (d, mo) in cols.items() if mo == month_no}
    return out


def parse_pool_sheet(ws):
    """Лист годового файла бассейна (один месяц)."""
    rows = list(ws.iter_rows(values_only=True))
    lab = lambda r: norm_name(r[1] if len(r) > 1 else "")
    r_num = next((i for i, r in enumerate(rows[:15]) if lab(r).startswith("numer dnia")), None)
    if r_num is None:
        return None
    cols = {}
    for j, c in enumerate(rows[r_num]):
        if j >= 2 and isinstance(c, (int, float)) and 1 <= int(c) <= 31 and int(c) not in cols.values():
            cols[j] = int(c)
    if len(cols) < 28:
        return None
    title = norm_name(ws.title).upper().replace(" ", "")
    month_no = next((n for k, n in PL_MONTHS.items() if title.startswith(k)), None)
    if not month_no:
        return None
    # год: тот, где 1-е число месяца приходится на день недели из строки «Dzień tyg»
    r_wd = next((i for i, r in enumerate(rows[:15]) if lab(r).startswith("dzien tyg")), None)
    j1 = next(j for j, d in cols.items() if d == 1)
    wd1 = PL_WD.get(norm_name(rows[r_wd][j1]) if r_wd is not None else "", None)
    today = dt.date.today()
    years = [y for y in (today.year, today.year - 1, today.year + 1)
             if wd1 is None or dt.date(y, month_no, 1).weekday() == wd1]
    year = years[0] if years else today.year
    named = re.search(r"\b(20\d\d)\b", ws.title)   # «LISTOPAD 2026»
    year = int(named.group(1)) if named else year
    out = {"ym": f"{year}-{month_no:02d}", "rows": {}, "times": {}, "suma": {}}
    j_suma = next((j for j, v in enumerate(rows[r_wd] if r_wd is not None else ()) if str(v).strip().upper() == "SUMA"), None)
    for i, r in enumerate(rows[r_num + 1:], r_num + 1):
        name = str(r[1] if len(r) > 1 and r[1] else "").strip()
        if not name or norm_name(name).startswith(("czas ", "suma", "razem")) or not re.search(r"[A-Za-zÀ-ž]", name):
            continue
        below = rows[i + 1] if i + 1 < len(rows) else ()
        # строка сотрудника: номер в столбце A или строка «Czas zmiany» сразу под ней (файл без нумерации)
        if not isinstance(r[0], (int, float)) and not lab(below).startswith("czas zmiany"):
            continue
        out["rows"][name] = {d: r[j] for j, d in cols.items() if j < len(r)}
        if j_suma is not None and j_suma < len(r) and isinstance(r[j_suma], (int, float)):
            out["suma"][name] = r[j_suma]
        if lab(below).startswith("czas zmiany"):
            out["times"][name] = {d: below[j] for j, d in cols.items() if j < len(below)}
    return out


def parse_import(state, path):
    """Excel → {"months": {ym: {"sched": {день: {ключ: R*}}, "absent": {день: {ключ: код}}}}, "names", ...}."""
    wb = openpyxl.load_workbook(path, data_only=True)
    by_key = {name_key(e["name"]): u for u, e in state["employees"].items() if e.get("status") == "active"}
    by_key.update({"~" + link_key(e["name"]): u for u, e in state["employees"].items() if e.get("status") == "active"})
    by_key.update({ln["key"][5:]: u for u, ln in state.get("hist_links", {}).items() if ln.get("key")})
    sheets = []
    for ws in wb.worksheets:
        part = parse_pool_sheet(ws) or parse_template_sheet(state, ws, by_key)
        if part and part["rows"]:
            sheets.append(part)
    if not sheets:
        return None, ("Nie rozpoznałem układu pliku. Przyjmuję Excel .xlsx: wzór z «📥 Wzór do importu» (Grafik → Historia) "
                      "albo arkusz pływalni z wierszami «Dzień tyg» i «Numer dnia» i kodami R1/R2/R3/U/X.")
    res = {"months": {}, "names": {}, "unknown": 0}
    for part in sheets:
        ym = part["ym"]
        n = ndays(ym)
        mon = res["months"].setdefault(ym, {"sched": {str(d): {} for d in range(1, n + 1)},
                                            "absent": {str(d): {} for d in range(1, n + 1)}})
        for name, cells in part["rows"].items():
            key = import_target(state, by_key, name)
            res["names"][key] = name
            open_r4 = []
            for d, v in cells.items():
                if d > n:
                    continue
                c = import_code(v, part.get("times", {}).get(name, {}).get(d))
                if c == ("shift", "R4"):
                    open_r4.append(d)
                elif c and c[0] == "shift":
                    mon["sched"][str(d)][key] = c[1]
                elif c and c[0] == "absent":
                    mon["absent"][str(d)][key] = c[1]
                elif v not in (None, "") and str(v).strip().upper() not in ("X", "W"):
                    res["unknown"] += 1
            if open_r4:
                # R4 без времени в файле: это недостающие часы до SUMA, поровну на все такие клетки
                done = sum(SHIFTS[day[key]]["hours"] for day in mon["sched"].values() if key in day)
                done += 8 * sum(key in day for day in mon["absent"].values())
                left = part.get("suma", {}).get(name, 0) - done
                if left > 0:
                    for d in open_r4:
                        mon["sched"][str(d)][key] = r4_code(left / len(open_r4))
                else:
                    res["unknown"] += len(open_r4)
    res["unmatched"] = sorted({k for k in res["names"] if k.startswith("name:")})
    return res, None


def import_summary(state, res):
    lines = []
    for ym in sorted(res["months"]):
        mon = res["months"][ym]
        shifts = sum(len(d) for d in mon["sched"].values())
        absn = sum(len(d) for d in mon["absent"].values())
        people = len({k for d in mon["sched"].values() for k in d})
        old = state.get("history", {}).get(ym, {}).get("kadry")
        lines.append(f"• {month_title(ym)}: {people} os., {shifts} zmian" + (f", {absn} dni nieobecności" if absn else "")
                     + (f" (w historii jest już grafik dla kadr z {old['at']})" if old else ""))
    matched = [k for k in res["names"] if not k.startswith("name:")]
    text = f"📥 Import do historii, miesięcy: {len(res['months'])}\n" + "\n".join(lines)
    text += f"\n\nRozpoznani pracownicy: {len(matched)}" + (f" ({', '.join(ename(state, k) for k in matched)})" if matched else "")
    if res["unmatched"]:
        text += (f"\nJeszcze niezarejestrowani: {len(res['unmatched'])}. Zapiszę ich po nazwisku; gdy się zarejestrują, "
                 "bot sam ich połączy (kolejność imienia i nazwiska nie ma znaczenia). Możesz też przypisać ręcznie.")
    if res["unknown"]:
        text += f"\nNieczytelnych komórek (pominięte): {res['unknown']}."
    for ym in import_use_months(state, res):
        n = sum(len(res["months"][ym]["sched"].get(str(d), {})) for d in range(1, ndays(ym) + 1) if is_closed(ym, d))
        text += f"\n\n📅 {month_title(ym)} można od razu użyć jako grafik na ten miesiąc."
        if n:
            shut = [str(d) for d in range(1, ndays(ym) + 1) if is_closed(ym, d) and res["months"][ym]["sched"].get(str(d))]
            text += f"\n⚠️ W pliku jest {n} zmian w dni, gdy basen jest zamknięty ({', '.join(shut)}). W grafiku ich nie będzie."
    return text + ("\n\nCo to za grafik? «Dla pracowników» trafi do historii obok grafiku dla kadr i go nie zastąpi. "
                   "«Dla kadr» zastąpi zapis dla kadr z tych miesięcy; tego używają reguły (niedziele, przerwy na przełomie miesięcy).")


def import_use_months(state, res):
    """Месяцы из файла, которые можно сделать рабочим графиком: текущий в боте или будущий, ещё не отправленный."""
    this = dt.date.today().strftime("%Y-%m")
    return [ym for ym in sorted(res.get("months", {})) if (ym == state.get("cur") or ym > this)
            and not (state["months"].get(ym) or {}).get("published")]


def import_as_schedule(state, ym, mon):
    """График из файла становится графиком месяца: уже у людей (сообщений не шлём), сбор диспозиций на него закрыт."""
    month = state["months"].setdefault(ym, new_month(ym))
    month["schedule"] = {str(d): ({} if is_closed(ym, d) else dict(mon["sched"].get(str(d), {})))
                         for d in range(1, ndays(ym) + 1)}
    month["leave"] = {d: v for d, v in mon.get("absent", {}).items() if v and not is_closed(ym, int(d))}
    month.update(published=True, imported=True, collect_closed=True, auto_applied=True)
    if state.get("collect") == ym:
        state["collect"] = None
    state["cur"] = ym
    log(f"Grafik z pliku użyty jako grafik na {ym}")


def import_send(state, chat_id, ym):
    """Необязательно: разослать сотрудникам их смены из графика, загруженного файлом."""
    month = state["months"].get(ym)
    if not month or not month.get("imported") or month.get("import_sent"):
        return "Ten grafik został już wysłany albo nie jest z pliku."
    month["import_sent"] = True
    save_state(state)
    ok = sum(bool(send(u, f"📅 Grafik na {month_title(ym)}:\n\n" + personal(state, month, u), EMP_KB)) for u in active(state))
    send(chat_id, f"Grafik wysłany, dostało {ok} z {len(active(state))} osób.", DIR_KB)
    return None


def import_markup(state, res):
    free = [u for u in active(state) if u not in res["names"]]
    rows = [[btn(f"❓ Przypisz «{res['names'][k]}»", f"hmap:{i}")]
            for i, k in enumerate(res["unmatched"])][:10] if free else []
    use = [[btn(f"📅 Użyj jako grafik na {month_title(ym)}", "himp:use")] for ym in import_use_months(state, res)][:1]
    return ikb(rows + use + [[btn("👥 Zapisz: grafik dla pracowników", "himp:emp")],
                       [btn("🧾 Zapisz: grafik dla kadr", "himp:ok")], [btn("Anuluj", "himp:no")]])


def import_map_menu(state, chat_id, i):
    """Выбор сотрудника для нераспознанного имени из импорта."""
    res = state.get("pending_import")
    if not res or i >= len(res.get("unmatched", [])):
        send(chat_id, "To jest już nieaktualne.")
        return
    key = res["unmatched"][i]
    rows = [[btn(e["name"], f"hmapto:{i}:{u}")] for u, e in active(state).items() if u not in res["names"]]
    send(chat_id, f"Kim jest «{res['names'][key]}» z pliku?", ikb(rows + [[btn("Zostaw po nazwisku", f"hmapto:{i}:-")]]))


def import_map_to(state, chat_id, msg, i, uid):
    res = state.get("pending_import")
    if not res or i >= len(res.get("unmatched", [])):
        edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    key = res["unmatched"][i]
    name = res["names"][key]
    if uid != "-" and uid in active(state):
        for mon in res["months"].values():
            for part in ("sched", "absent"):
                for day in mon[part].values():
                    if key in day:
                        day[uid] = day.pop(key)
        res["names"][uid] = res["names"].pop(key)
        res["unmatched"][i] = uid   # индекс остаётся, чтобы кнопки других имён не сдвинулись
        text = f"«{name}» → {ename(state, uid)} (we wszystkich miesiącach)."
    else:
        text = f"«{name}» zostanie zapisany(-a) po nazwisku."
    save_state(state)
    edit(chat_id, msg["message_id"], text)


def handle_import_doc(state, chat_id, doc):
    name = doc.get("file_name", "")
    low = name.lower()
    if low.endswith((".xls", ".ods", ".csv")):
        send(chat_id, "Ten format nie jest obsługiwany. Otwórz plik w Excelu i zapisz jako «Skoroszyt programu Excel (*.xlsx)», "
                      "potem wyślij go jeszcze raz.")
        return
    if not low.endswith((".xlsx", ".xlsm")):
        send(chat_id, "Do historii przyjmuję plik Excel .xlsx: wzór z «📥 Wzór do importu» (Grafik → Historia) "
                      "albo arkusz pływalni (miesiące w zakładkach, wiersze «Dzień tyg» i «Numer dnia», kody R1/R2/R3/U/X).")
        return
    try:
        fp = tg("getFile", file_id=doc["file_id"])["result"]["file_path"]
        os.makedirs(SCHEDULE_DIR, exist_ok=True)
        path = os.path.join(SCHEDULE_DIR, f"import-{time.strftime('%Y%m%d-%H%M%S')}.xlsx")
        with urllib.request.urlopen(f"https://api.telegram.org/file/bot{TOKEN}/{fp}", timeout=60) as r, \
                open(path, "wb") as f:
            f.write(r.read())
        res, err = parse_import(state, path)
    except Exception as e:  # noqa: BLE001
        log(f"import failed: {e!r}")
        send(chat_id, "Nie udało się odczytać pliku. Czy to na pewno Excel .xlsx?")
        return
    if err:
        send(chat_id, f"Nie mogę zaimportować. {err}")
        return
    state["pending_import"] = res
    save_state(state)
    log(f"Import: {name}, miesiące {sorted(res['months'])}")
    send(chat_id, import_summary(state, res), import_markup(state, res))


def confirm_import(state, chat_id, msg, yes, kind="kadry", use=False):
    res = state.get("pending_import")
    use_months = import_use_months(state, res) if res and use else []
    state.pop("pending_import", None)
    save_state(state)
    if not res or not yes:
        edit(chat_id, msg["message_id"], "Import anulowany." if res else "To jest już nieaktualne.")
        return
    if "months" not in res:   # старый формат ожидающего импорта
        res = {"months": {res["ym"]: {"sched": res["sched"], "absent": {}}}, "names": {}}
    for ym, mon in res["months"].items():
        history_save(state, ym, kind, mon["sched"], source="import")
        h = state["history"][ym]
        h["names"] = {k: v for k, v in h.get("names", {}).items() if not k.startswith("name:")}   # прошлый импорт этого месяца
        h["names"].update({k: v for k, v in res["names"].items()})
        if kind == "kadry" or not h.get("kadry"):
            h["absences"] = {d: v for d, v in mon.get("absent", {}).items() if v}
        if kind == "emp":
            h["emp_absences"] = {d: v for d, v in mon.get("absent", {}).items() if v}
    links = state.setdefault("hist_links", {})
    for k, v in res["names"].items():
        if not k.startswith("name:"):
            links[k] = {"key": "name:" + name_key(v), "name": v}
    for ym in use_months[:1]:
        import_as_schedule(state, ym, res["months"][ym])
    hist_autolink_all(state)
    save_state(state)
    text = (f"✅ Zapisałem w historii ({'grafik dla pracowników' if kind == 'emp' else 'grafik dla kadr'}): "
            + ", ".join(month_title(ym) for ym in sorted(res["months"])) + ".")
    markup = None
    for ym in use_months[:1]:
        text += (f"\n\n📅 To jest teraz grafik na {month_title(ym)}: widać go w «Grafik», a zbieranie dyspozycji na ten "
                 "miesiąc jest zamknięte. Pracownicy nie dostali żadnej wiadomości. Osoby jeszcze niezarejestrowane "
                 "są w grafiku po nazwisku i połączą się po rejestracji.")
        markup = ikb([[btn("📤 Wyślij pracownikom (opcjonalnie)", f"impsend:{ym}")]])
    edit(chat_id, msg["message_id"], text, markup)


# ---------- powiązanie pracowników z historią ----------
# В импортированной истории человек лежит под ключом «name:…», пока его не свяжут с сотрудником. Связывание заменяет
# ключ на uid в импортированных месяцах (правила и просмотр сразу видят этого человека); state["hist_links"][uid] =
# {"key", "name"} хранит исходный ключ, чтобы связь можно было поменять. {"key": None} — директор отвязал вручную,
# автоматически больше не связываем.

CYR = str.maketrans({"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ж": "zh", "з": "z", "и": "i", "к": "k",
                     "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f",
                     "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sch", "ы": "i", "э": "e", "ю": "u", "я": "a",
                     "ь": "", "ъ": ""})


def link_tokens(name):
    """Слова имени в одной транскрипции: Czaplin = Chaplin, Yuri = Yurii; «1/2 etatu» в имени отбрасываем."""
    out = []
    for t in re.findall(r"[^\W\d_]+", norm_name(name).translate(CYR)):
        if t in ("etat", "etatu", "etaty"):
            continue
        for a, b in (("cz", "ch"), ("sz", "sh"), ("w", "v"), ("y", "i"), ("j", "i"), ("ii", "i")):
            t = t.replace(a, b)
        out.append(t)
    return sorted(out)


def link_key(name):
    return " ".join(link_tokens(name))


def hist_unlinked(state):
    """Люди из импортированной истории, ещё ни с кем не связанные: {ключ: имя из файла}."""
    res = {}
    for ym in sorted(state.get("history", {})):
        for k, v in state["history"][ym].get("names", {}).items():
            if k.startswith("name:") and k not in (state.get("hist_hidden") or {}):
                res[k] = v
    return res


def hist_hash(key):
    return hashlib.sha1(key.encode()).hexdigest()[:8]


def hist_match(state, name):
    """(точное совпадение или None, похожие ключи, лучшие первыми)."""
    un = hist_unlinked(state)
    lk = link_key(name)
    exact = [k for k, v in un.items() if link_key(v) == lk]
    if len(exact) == 1:
        return exact[0], []
    tokens, scored = link_tokens(name), []
    for k, v in un.items():
        other = link_tokens(v)
        if not tokens or not other:
            continue
        best = [max(difflib.SequenceMatcher(None, a, b).ratio() for b in other) for a in tokens]
        if max(best) >= 0.8:
            scored.append((sum(best) / len(best), k))
    return None, [k for _, k in sorted(scored, reverse=True)]


def hist_rename(state, old, new, name=None):
    """Заменить ключ человека в импортированных месяцах истории."""
    forward = str(old).startswith("name:")   # имя → сотрудник: везде; обратно — только в импортированном
    for m in state["months"].values():
        if (forward or m.get("imported")) and m.get("schedule"):
            for day in list(m["schedule"].values()) + list((m.get("leave") or {}).values()):
                if old in day:
                    day[new] = day.pop(old)
    for h in state.get("history", {}).values():
        parts = [h[k].get("sched") or {} for k in ("emp", "kadry") if h.get(k) and (forward or h[k].get("source") == "import")]
        if not parts:
            continue
        for part in parts + [h.get("absences") or {}, h.get("emp_absences") or {}]:
            for day in part.values():
                if old in day:
                    day[new] = day.pop(old)
        names = h.get("names", {})
        if old in names:
            names[new] = name or names[old]
            del names[old]


def hist_link(state, uid, key):
    """Связать сотрудника с человеком из истории; key=None — отвязать."""
    if uid not in state["employees"]:
        return "Nie ma takiego pracownika."
    un = hist_unlinked(state)
    if key and key not in un:
        return "Tej osoby nie ma już na liście, odśwież ekran."
    links = state.setdefault("hist_links", {})
    old = links.get(uid) or {}
    if old.get("key"):
        hist_rename(state, uid, old["key"], old.get("name"))
    if key:
        name = un[key]
        hist_rename(state, key, uid)
        links[uid] = {"key": key, "name": name}
        log(f"Historia: {ename(state, uid)} = {name}")
    else:
        links[uid] = {"key": None}
    save_state(state)
    return None


def hist_auto_link(state, uid):
    """При регистрации: связать, если имя совпадает однозначно. Ручное решение директора не трогаем."""
    if uid in state.get("hist_links", {}) or uid not in state["employees"]:
        return
    exact, _ = hist_match(state, state["employees"][uid]["name"])
    if exact:
        hist_link(state, uid, exact)


def hist_autolink_all(state):
    for u, e in list(state["employees"].items()):
        if e.get("status") in ("active", "pending") and not u.startswith("test"):
            hist_auto_link(state, u)


def hist_note(state, uid):
    """Строка и кнопка для карточки сотрудника; ("", []), если истории из файла ещё нет."""
    ln = state.get("hist_links", {}).get(uid) or {}
    if ln.get("key"):
        return f"🔗 Powiązano z historią: {ln['name']}", [[btn("🔗 Zmień powiązanie z historią", f"hl:{uid}")]]
    if uid in state.get("hist_links", {}):
        return "⚪ Nie ma w historii", [[btn("🔗 Powiąż z historią", f"hl:{uid}")]] if hist_unlinked(state) else []
    if hist_unlinked(state):
        return "❓ Brak w historii — powiąż", [[btn("🔗 Powiąż z historią", f"hl:{uid}")]]
    return "", []


def hist_link_menu(state, chat_id, uid):
    un = hist_unlinked(state)
    ln = state.get("hist_links", {}).get(uid) or {}
    _, sug = hist_match(state, ename(state, uid))
    order = sug + sorted((k for k in un if k not in sug), key=lambda k: un[k].lower())
    rows = [[btn(("✨ " if k in sug else "") + un[k], f"hlk:{uid}:{hist_hash(k)}")] for k in order[:40]]
    if ln.get("key"):
        rows.append([btn(f"✂️ Odłącz od «{ln['name']}»", f"hlk:{uid}:-")])
    else:
        rows.append([btn("⚪ Nie ma w historii", f"hlk:{uid}:-")])
    send(chat_id, f"🔗 Powiąż z historią: {ename(state, uid)}"
         + (f"\nTeraz: {ln['name']}." if ln.get("key") else "") + "\nKim ta osoba jest w historii?", ikb(rows))


def hist_waiting(state):
    """Сотрудники, о которых директор ещё не решил: нет ни связи, ни отметки «нет в истории»."""
    return [u for u in active(state) if u not in state.get("hist_links", {}) and not u.startswith("test") and u != DEMO_UID]


def hist_send_cards(state, chat_id):
    """Карточка связывания на каждого, кто ещё не связан."""
    wait = hist_waiting(state) if hist_unlinked(state) else []
    if not wait:
        send(chat_id, "🔗 Wszyscy pracownicy są już powiązani z historią albo oznaczeni, że ich w niej nie ma.")
    for u in wait:
        hist_link_menu(state, chat_id, u)


def hist_link_pick(state, chat_id, msg, uid, h):
    key = None if h == "-" else next((k for k in hist_unlinked(state) if hist_hash(k) == h), "?")
    err = hist_link(state, uid, key)
    ln = state.get("hist_links", {}).get(uid) or {}
    edit(chat_id, msg["message_id"], err or (f"🔗 {ename(state, uid)} = {ln['name']} (cała historia z pliku)."
                                             if ln.get("key") else f"⚪ {ename(state, uid)}: bez historii."))


def hist_unlinked_list(state, chat_id):
    un = hist_unlinked(state)
    free = [e["name"] for u, e in active(state).items() if not (state.get("hist_links", {}).get(u) or {}).get("key")]
    text = (f"Osoby z historii bez powiązania ({len(un)}):\n" + "\n".join(f"• {v}" for v in sorted(un.values()))
            if un else "Wszystkie osoby z historii są powiązane.")
    if free:
        text += "\n\nPracownicy bez historii: " + ", ".join(free) + ". Wybierz, kogo powiązać:"
    rows = [[btn(f"🔗 {e['name']}", f"hl:{u}")] for u, e in active(state).items()
            if not (state.get("hist_links", {}).get(u) or {}).get("key")] if un else []
    send(chat_id, text, ikb(rows) if rows else None)


def links_payload(state):
    un = hist_unlinked(state)
    emps = {}
    for u, e in state["employees"].items():
        if e.get("status") == "active":
            ln = state.get("hist_links", {}).get(u) or {}
            emps[u] = {"name": ln.get("name") if ln.get("key") else None, "sug": hist_match(state, e["name"])[1]}
    return {"unlinked": [{"key": k, "name": v} for k, v in sorted(un.items(), key=lambda kv: kv[1].lower())],
            "emps": emps}


def prev_sundays(ym):
    y, m = ym_parts(ym)
    d = dt.date(y, m, 1) - DAY
    while d.weekday() != 6:
        d -= DAY
    return [d - 14 * DAY, d - 7 * DAY, d]


def kadry_timeline(state, month, sched, uid):
    """{дата: код} смен сотрудника: прошлый месяц + этот (по графику для кадр)."""
    tl = {}
    pym, psched = prev_source(state, month["ym"])
    if psched:
        py_, pm_ = ym_parts(pym)
        nk = emp_hist_key(state, uid)   # импортирован до регистрации — ищем по имени
        tl.update({dt.date(py_, pm_, int(d)): day.get(uid) or day[nk] for d, day in psched.items()
                   if uid in day or nk in day})
    elif uid in kadry_of(month).get("prev_r2", []):
        # графика прошлого месяца нет, но директор отметил: в последний день работал(а) R2
        tl[dt.date(*ym_parts(month["ym"]), 1) - DAY] = "R2"
    y, m = ym_parts(month["ym"])
    tl.update({dt.date(y, m, int(d)): day[uid] for d, day in (sched or {}).items() if uid in day})
    return tl


def prev_required(state, month):
    """В рабочем режиме первый график для кадр нужно строить с данными прошлого месяца."""
    kad = kadry_of(month)
    return (state.get("mode") == "prod" and prev_source(state, month["ym"])[1] is None
            and not any(kad.get("prev_sundays", {}).values()) and not kad.get("prev_r2"))


def manual_sundays(month, uid):
    return {dt.date.fromisoformat(x) for x in kadry_of(month).get("prev_sundays", {}).get(uid, [])}


def rest_between(tl, d):
    """Отдых между сменой d и сменой d+1 (None, если одной из смен нет)."""
    a, b = tl.get(d), tl.get(d + DAY)
    if not a or not b:
        return None
    return 24 + shift_span(b)[0] - shift_span(a)[1]


def week_rest(tl, monday):
    """Самый длинный непрерывный отдых в неделе пн 00:00 — вс 24:00."""
    prev, best = 0.0, 0.0
    for i in range(7):
        code = tl.get(monday + i * DAY)
        if code:
            s, e = shift_span(code)
            best = max(best, i * 24 + s - prev)
            prev = i * 24 + e
    return max(best, 168 - prev)


def sunday_run(tl, manual, sunday):
    """Сколько воскресений подряд будет отработано, если работать в это воскресенье."""
    worked = lambda s: s in tl or s in manual
    run, s = 1, sunday - 7 * DAY
    while worked(s):
        run, s = run + 1, s - 7 * DAY
    s = sunday + 7 * DAY
    while worked(s):
        run, s = run + 1, s + 7 * DAY
    return run


def place_reason(month, tl, manual, day, code):
    """Почему нельзя поставить смену code на дату day (tl — смены сотрудника без этой даты). None — можно."""
    if not is_kadry_code(code):
        return "w grafiku dla kadr są tylko zmiany R1, R2 i R4"
    if is_closed(month["ym"], day.day):
        return "basen jest tego dnia zamknięty"
    y, m = ym_parts(month["ym"])
    last = dt.date(y, m, ndays(month["ym"]))
    old = tl.get(day)
    tl[day] = code
    try:
        for a in (day - DAY, day):
            r = rest_between(tl, a)
            if r is not None and r < DAILY_REST_H:
                return (f"tylko {r:g} h przerwy między zmianami {tl[a].split('@')[0]} i {tl[a + DAY].split('@')[0]}, "
                        f"wymagane {DAILY_REST_H} h")
        monday = day - day.weekday() * DAY
        if monday + 6 * DAY <= last:
            g = week_rest(tl, monday)
            if g < WEEKLY_REST_H:
                return (f"w tygodniu {monday:%d.%m}–{monday + 6 * DAY:%d.%m} najdłuższy odpoczynek to {g:g} h, "
                        f"wymagane {WEEKLY_REST_H} h bez przerwy")
        if day.weekday() == 6 and sunday_run(tl, manual, day) >= 4:
            return "to byłaby 4. niedziela z rzędu w pracy (co 4. niedziela musi być wolna)"
        return None
    finally:
        if old:
            tl[day] = old
        else:
            tl.pop(day, None)


def kadry_violations(state, month, uid):
    """Все нарушения правил у сотрудника в графике для кадр: [(день месяца, текст)]."""
    sched = kadry_of(month).get("sched") or {}
    tl, manual = kadry_timeline(state, month, sched, uid), manual_sundays(month, uid)
    y, m = ym_parts(month["ym"])
    first, last = dt.date(y, m, 1), dt.date(y, m, ndays(month["ym"]))
    res = []
    for d in range(1, ndays(month["ym"]) + 1):
        if not is_kadry_code(tl.get(dt.date(y, m, d), "R1")):
            res.append((d, "R3 (16 h) nie jest dozwolona w grafiku dla kadr"))
    day = first - DAY
    while day < last:
        r = rest_between(tl, day)
        if r is not None and r < DAILY_REST_H:
            res.append(((day + DAY).day, f"tylko {r:g} h przerwy po zmianie {tl[day].split('@')[0]} ({day:%d.%m}), "
                                         f"wymagane {DAILY_REST_H} h"))
        day += DAY
    monday = first - first.weekday() * DAY
    while monday + 6 * DAY <= last:
        g = week_rest(tl, monday)
        if g < WEEKLY_REST_H:
            res.append((max(monday, first).day, f"tydzień {monday:%d.%m}–{monday + 6 * DAY:%d.%m}: najdłuższy "
                                                 f"odpoczynek {g:g} h, wymagane {WEEKLY_REST_H} h"))
        monday += 7 * DAY
    run = 0
    for s in prev_sundays(month["ym"]) + [first + i * DAY for i in range((last - first).days + 1)
                                          if (first + i * DAY).weekday() == 6]:
        run = run + 1 if (s in tl or s in manual) else 0
        if run >= 4 and s >= first:
            res.append((s.day, "4. niedziela z rzędu w pracy (co 4. niedziela musi być wolna)"))
    return sorted(res)


def kcoverage(month, sched, d):
    cov = {p: 0 for p in PERIODS}
    for c in (sched or {}).get(str(d), {}).values():
        for p in SHIFTS[c]["covers"]:
            cov[p] += 1
    return cov


def build_kadry(state, month):
    """Из текущего черновика: R3 → R1/R2, всё, что нарушает правила, убираем, часы подгоняем под ставку."""
    ym, n = month["ym"], ndays(month["ym"])
    y, m = ym_parts(ym)
    emps = list(active(state))
    sched = {str(d): {} for d in range(1, n + 1)}
    base = month["schedule"] or {}
    leave = month_leave(month)
    need = {u: max(0, (target_hours(state, u, ym) or 0) - leave_hours(month, u)) // int(SHIFTS["R1"]["hours"]) for u in emps}
    tls = {u: kadry_timeline(state, month, {}, u) for u in emps}
    manual = {u: manual_sundays(month, u) for u in emps}

    def short_of(d, code):
        cov, nd = kcoverage(month, sched, d), need_for(ym, d)
        return sum(nd[p] - cov[p] for p in SHIFTS[code]["covers"])

    def place(u, d, code):
        sched[str(d)][u] = code
        tls[u][dt.date(y, m, d)] = code

    def unplace(u, d):
        sched[str(d)].pop(u, None)
        tls[u].pop(dt.date(y, m, d), None)

    def full(d, code):
        cov = kcoverage(month, sched, d)
        return any(cov[p] >= max_for(month["ym"]) for p in SHIFTS[code]["covers"])

    # 1. берём черновик по порядку дней, R3 превращаем в ту половину дня, где людей меньше
    for d in range(1, n + 1):
        for u, c in base.get(str(d), {}).items():
            if u not in need or need[u] == 0 or (u in leave.get(str(d), {}) or is_gone(ym, d, u)):
                continue
            codes = [c] if c in KADRY_CODES else sorted(KADRY_CODES, key=lambda x: -short_of(d, x))
            for code in codes:
                if not full(d, code) and not place_reason(month, tls[u], manual[u], dt.date(y, m, d), code):
                    place(u, d, code)
                    break
    # 2. лишние смены сверх ставки — там, где людей больше всего
    for u in emps:
        mine = [d for d in range(1, n + 1) if u in sched[str(d)]]
        while len(mine) > need[u]:
            d = max(mine, key=lambda x: (-short_of(x, sched[str(x)][u]), x))
            unplace(u, d)
            mine.remove(d)
    # 3. добираем до ставки: сначала туда, где не хватает людей, потом куда можно по правилам;
    #    сначала не больше MAX_PER_SHIFT на смене, и только если иначе ставку не набрать — сверх него
    def fill(capped):
        while True:
            placed = False
            for u in sorted(emps, key=lambda x: -(need[x] - sum(x in sched[str(d)] for d in range(1, n + 1)))):
                if sum(u in sched[str(d)] for d in range(1, n + 1)) >= need[u]:
                    continue
                best = None
                for d in range(1, n + 1):
                    if u in sched[str(d)] or (u in leave.get(str(d), {}) or is_gone(ym, d, u)):
                        continue
                    for code in KADRY_CODES:
                        if (capped and full(d, code)) or place_reason(month, tls[u], manual[u], dt.date(y, m, d), code):
                            continue
                        score = (short_of(d, code) > 0, code in options(month, u, d), short_of(d, code), -d)
                        if best is None or score > best[0]:
                            best = (score, d, code)
                if best:
                    place(u, best[1], best[2])
                    placed = True
            if not placed:
                return

    fill(True)   # MAX_PER_SHIFT — жёстко: сверх него полных смен не ставим

    # 3б. ремонт: часы у людей уже кончились, а где-то меньше минимума. Переносим смену человека с дня, где людей
    #     больше минимума, на день с нехваткой, если там это разрешают правила (перерывы, 35 ч, воскресенья).
    #     Норма часов при этом не меняется.
    def repair():
        for _ in range(400):
            short = [(d, p) for d in range(1, n + 1) for p in PERIODS
                     if kcoverage(month, sched, d)[p] < need_for(ym, d)[p]]
            moved = False
            for d, p in short:
                code = "R1" if p == "rano" else "R2"
                if full(d, code):
                    continue
                for u in emps:
                    if u in sched[str(d)] or u in leave.get(str(d), {}) or is_gone(ym, d, u):
                        continue
                    mine = [x for x in range(1, n + 1) if u in sched[str(x)] and sched[str(x)][u] in KADRY_CODES]
                    for d2 in sorted(mine, key=lambda x: -min(kcoverage(month, sched, x)[q] - need_for(ym, x)[q]
                                                              for q in SHIFTS[sched[str(x)][u]]["covers"])):
                        c2 = sched[str(d2)][u]
                        cov2, nd2 = kcoverage(month, sched, d2), need_for(ym, d2)
                        if any(cov2[q] - 1 < nd2[q] for q in SHIFTS[c2]["covers"]):
                            continue
                        unplace(u, d2)
                        if not place_reason(month, tls[u], manual[u], dt.date(y, m, d), code):
                            place(u, d, code)
                            moved = True
                            break
                        place(u, d2, c2)
                    if moved:
                        break
                if moved:
                    break
            if not moved:
                return

    repair()

    # 4. что осталось до нормы (остаток от деления на 8 или нехватка из-за правил) — R4 с нужным числом часов.
    #    На обсаду R4 не считается (как в файле бассейна), поэтому лимит MAX_PER_SHIFT её не касается.
    def fill_r4():
        for u in emps:
            t = target_hours(state, u, ym)
            if not t:
                continue
            left = t - leave_hours(month, u) - sum(SHIFTS[day[u]]["hours"] for day in sched.values() if u in day)
            while left > 0:
                code = r4_code(min(left, R4_MAX_H))
                best = None
                for d in range(1, n + 1):
                    date = dt.date(y, m, d)
                    if u in sched[str(d)] or (u in leave.get(str(d), {}) or is_gone(ym, d, u)) or place_reason(month, tls[u], manual[u], date, code):
                        continue
                    # лучше будний день без праздника, где R4 ещё нет
                    score = (date.weekday() < 5 and date not in holidays_pl(y),
                             date.weekday() != 6, -sum("@" in c for c in sched[str(d)].values()), -d)
                    if best is None or score > best[0]:
                        best = (score, d)
                if not best:
                    break
                place(u, best[1], code)
                left -= SHIFTS[code]["hours"]

    fill_r4()
    for u in emps:   # на случай дробной нормы: итог ровно по норме, не больше
        kadry_of(month)["sched"] = sched
        if kadry_over(state, month, u) > 0:
            kadry_level(state, month, u)
    kad = kadry_of(month)
    kad["sched"] = sched
    save_state(state)


def kadry_set(state, uid, d, code):
    month = cur_month(state)
    if not month or uid not in active(state) or not 1 <= d <= ndays(month["ym"]):
        return "Nie ma takiego pracownika lub dnia."
    kad = kadry_of(month)
    if kad.get("sched") is None:
        return "Najpierw ułóż grafik dla kadr."
    day = kad["sched"][str(d)]
    if code and code not in KADRY_CODES and not (str(code).startswith("R4@") and is_kadry_code(code)
                                                 and 0 < SHIFTS[code]["hours"] <= R4_MAX_H):
        return f"R4 może mieć od 1 do {R4_MAX_H} h."
    if code and is_gone(month["ym"], d, uid):
        return "Ta osoba już wtedy nie pracuje."
    if code and uid in month_leave(month).get(str(d), {}):
        return "Tego dnia ta osoba ma urlop lub zwolnienie."
    if code:
        tl = kadry_timeline(state, month, kad["sched"], uid)
        y, m = ym_parts(month["ym"])
        tl.pop(dt.date(y, m, d), None)
        reason = place_reason(month, tl, manual_sundays(month, uid), dt.date(y, m, d), code)
        if reason:
            return f"Nie można: {reason}."
        day[uid] = code
    else:
        day.pop(uid, None)
    save_state(state)
    if 0 < kadry_over(state, month, uid) < SHIFT_H:
        kadry_level(state, month, uid)
    return None


def kadry_move(state, uid, d, d2, code=None):
    month = cur_month(state)
    kad = kadry_of(month) if month else {}
    if not month or kad.get("sched") is None or uid not in active(state):
        return "Najpierw ułóż grafik dla kadr."
    n = ndays(month["ym"])
    if not (1 <= d <= n and 1 <= d2 <= n):
        return "Nie ma takiego dnia."
    sched = kad["sched"]
    old = sched[str(d)].get(uid)
    if not old:
        return "Ta osoba nie pracuje tego dnia."
    if uid in sched[str(d2)]:
        return "Tego dnia ta osoba już pracuje."
    if is_gone(month["ym"], d2, uid):
        return "Ta osoba już wtedy nie pracuje."
    if uid in month_leave(month).get(str(d2), {}):
        return "Tego dnia ta osoba ma urlop lub zwolnienie."
    sched[str(d)].pop(uid)
    y, m = ym_parts(month["ym"])
    tl, manual = kadry_timeline(state, month, sched, uid), manual_sundays(month, uid)
    reasons = {}
    for c in ([code] if code else [old] if "@" in old else [old] + [x for x in KADRY_CODES if x != old]):
        reasons[c] = place_reason(month, tl, manual, dt.date(y, m, d2), c)
        if not reasons[c]:
            sched[str(d2)][uid] = c
            save_state(state)
            return None
    sched[str(d)][uid] = old
    return f"Nie można: {next(iter(reasons.values()))}."


def shorter_code(code, cut):
    """Та же смена с тем же началом, но короче на cut часов: «R1» − 2 ч → «R1@06:00-12:00»."""
    a, b_ = shift_span(code)
    b_ -= cut
    fmt = lambda x: f"{int(x):02d}:{round((x - int(x)) * 60):02d}"
    return f"{code.split('@')[0]}@{fmt(a)}-{fmt(b_)}"


def kadry_over(state, month, uid):
    t = target_hours(state, uid, month["ym"])
    if t is None:
        return 0
    sched = kadry_of(month).get("sched") or {}
    return sum(SHIFTS[day[uid]]["hours"] for day in sched.values() if uid in day) + leave_hours(month, uid) - t


def kadry_level(state, month, uid):
    """Выравнивание до нормы: сверх нормы укорачиваем смену (сначала R4, потом день, где людей больше всего).
    Начало смены не меняем, поэтому перерывы только растут и правила не нарушаются. Если лишнего больше смены — смену снимаем."""
    sched = kadry_of(month).get("sched") or {}
    over = kadry_over(state, month, uid)
    ym = month["ym"]
    days = [int(d) for d, day in sched.items() if uid in day]

    def spare(d):
        cov, need = kcoverage(month, sched, d), need_for(ym, d)
        return min((cov[p] - need[p] for p in SHIFTS[sched[str(d)][uid]]["covers"]), default=99)

    for d in sorted(days, key=lambda x: (not sched[str(x)][uid].startswith("R4"), -spare(x), -x)):
        if over <= 0:
            break
        code = sched[str(d)][uid]
        cut = min(over, SHIFTS[code]["hours"])
        if cut >= SHIFTS[code]["hours"]:
            del sched[str(d)][uid]
        else:
            sched[str(d)][uid] = shorter_code(code, cut)
        over -= cut
    save_state(state)
    return None


def kadry_prev_sunday(state, uid, date, worked):
    month = cur_month(state)
    if not month or uid not in active(state) or date not in [s.isoformat() for s in prev_sundays(month["ym"])]:
        return "Błędne dane."
    lst = kadry_of(month).setdefault("prev_sundays", {}).setdefault(uid, [])
    if worked and date not in lst:
        lst.append(date)
    if not worked and date in lst:
        lst.remove(date)
    save_state(state)
    return None


def kadry_payload(state, month):
    """Данные «для кадр» для редактора: смены, допустимые смены по правилам, нарушения."""
    kad = kadry_of(month)
    sched = kad.get("sched")
    ym, n = month["ym"], ndays(month["ym"])
    y, m = ym_parts(ym)
    emps = {}
    for u in active(state):
        tl, manual = kadry_timeline(state, month, sched or {}, u), manual_sundays(month, u)
        allow = {}
        if sched is not None:
            for d in range(1, n + 1):
                if u not in sched[str(d)]:
                    onleave = u in month_leave(month).get(str(d), {}) or is_gone(ym, d, u)
                    allow[str(d)] = {c: "urlop lub zwolnienie" if onleave else place_reason(month, tl, manual, dt.date(y, m, d), c)
                                     for c in KADRY_CODES}
        mine = {d: day[u] for d, day in (sched or {}).items() if u in day}
        emps[u] = {"ksched": mine, "khours": sum(SHIFTS[c]["hours"] for c in mine.values()) + leave_hours(month, u), "kallow": allow,
                   "kviol": kadry_violations(state, month, u) if sched is not None else [],
                   "kprev": sorted(kad.get("prev_sundays", {}).get(u, [])), "kprev_r2": u in kad.get("prev_r2", [])}
    kcov = [[kcoverage(month, sched, d)[p] for p in PERIODS] for d in range(1, n + 1)] if sched else None
    shorts = [{"d": d, "p": i, "cov": kcoverage(month, sched, d)[p], "need": need_for(ym, d)[p]}
              for d in range(1, n + 1) for i, p in enumerate(PERIODS)
              if sched is not None and kcoverage(month, sched, d)[p] < need_for(ym, d)[p]]
    return {"built": sched is not None, "shorts": shorts, "prev_known": prev_source(state, ym)[1] is not None,
            "prev_required": prev_required(state, month), "prev_title": month_title(prev_ym(ym)),
            "prev_last_day": (dt.date(y, m, 1) - DAY).isoformat(),
            "prev_sundays": [s.isoformat() for s in prev_sundays(ym)], "daily_rest": DAILY_REST_H,
            "weekly_rest": WEEKLY_REST_H, "kcov": kcov, "norm": norm_info(state, ym), "shifts": dyn_shifts(sched)}, emps


def write_kadry_xlsx(state, month, fname=None, names=None):
    """Excel «Grafik dla kadr»: сотрудник × день, в клетке часы смены (06:00-14:00), итог часов и норма.
    Тот же формат принимается обратно при импорте истории."""
    os.makedirs(SCHEDULE_DIR, exist_ok=True)
    ym, n = month["ym"], ndays(month["ym"])
    y, m = ym_parts(ym)
    sched = kadry_of(month).get("sched") or {}
    people = dict(active(state))
    people.update({u: state["employees"][u] for day in sched.values() for u in day if u in state["employees"]})
    for u, nm in (names or {}).items():   # в истории могут быть уже уволенные
        if any(u in day for day in sched.values()):
            people.setdefault(u, {"name": nm, "etat": "1"})
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Grafik dla kadr"
    ws.append([kadry_title(ym)])   # заголовок «Grafik za okres 01.11.2026 – 30.11.2026, Chełm»
    ws.cell(row=1, column=1).font = Font(bold=True, size=13)
    ws.append(["Pracownik", "Etat"] + [f"{d:02d}.{m:02d} {DAYS_XLS[date_of(ym, d).weekday()]}" for d in range(1, n + 1)]
              + ["Godziny", "Norma"])
    for cell in ws[2]:
        cell.font, cell.alignment, cell.fill = Font(bold=True, color="FFFFFF"), CENTER, FILL_HEAD
    for u, e in people.items():
        row, hours = [e["name"], ETATS.get(etat_for(state, u, ym), ETATS["1"])[0]], 0
        for d in range(1, n + 1):
            c = sched.get(str(d), {}).get(u)
            off = month_leave(month).get(str(d), {}).get(u)
            if off:
                row.append(off)
                hours += leave_h(ym, d, u, off)
            elif c and "@" in c:   # R4 и т. п.: код и часы в клетке, чтобы кадры видели, что это за смена
                row.append(f"{c.split('@')[0]} {SHIFTS[c]['time']} ({SHIFTS[c]['hours']:g} h)")
            else:
                row.append(SHIFTS[c]["time"].replace("–", "-") if c else "")
            hours += SHIFTS[c]["hours"] if c else 0
        row += [hours, target_hours(state, u, ym)]
        ws.append(row)
        r = ws.max_row
        for i, d in enumerate(range(1, n + 1), 3):
            cell = ws.cell(row=r, column=i)
            cell.alignment, cell.border = CENTER, BORDER
            c = sched.get(str(d), {}).get(u)
            if month_leave(month).get(str(d), {}).get(u) == "KRW":
                cell.fill = FILL_KRW
            elif month_leave(month).get(str(d), {}).get(u) == "U":
                cell.fill = FILL_U
            elif c:
                cell.fill = FILL_CODE[c.split("@")[0]]
            elif is_closed(ym, d):
                cell.fill = FILL_HOLIDAY
            elif date_of(ym, d).weekday() >= 5:
                cell.fill = FILL_WEEKEND
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width = 26, 12
    for i in range(3, n + 3):
        ws.column_dimensions[get_column_letter(i)].width = 12
    ws.freeze_panes = "C3"
    if any("KRW" in day.values() for day in month_leave(month).values()):
        ws.append([])
        ws.append([KRW_LEGEND])
        ws.cell(row=ws.max_row, column=1).font = BOLD
        ws.cell(row=ws.max_row, column=1).fill = FILL_KRW
    rows = []
    if state["months"].get(ym) is month:   # только рабочий месяц, не история
        for u, e in active(state).items():
            x = extra_info(state, u)
            if x["hours"] > 0:
                days = ", ".join(f"{p['d']:02d}.{m:02d} {p['code']}" for p in (x["days"] or {}).get("plan", []))
                rows.append([e["name"], x["shifts"], x["hours"], x["room"], days])
    if rows:
        ws2 = wb.create_sheet("Nadgodziny")
        ws2.append(["Pracownik", "Zmiany do rozliczenia (płatne dodatkowo)", "Godziny", f"Do wpisania w tym miesiącu (maks. {EXTRA_MAX_MONTH})", "Propozycja dni (zgodnie z Kodeksem pracy)"])
        for cell in ws2[1]:
            cell.font, cell.alignment, cell.fill = Font(bold=True, color="FFFFFF"), CENTER, FILL_HEAD
        for r_ in rows:
            ws2.append(r_)
        for col_, w in zip("ABCDE", (26, 14, 10, 18, 60)):
            ws2.column_dimensions[col_].width = w
    path = os.path.join(SCHEDULE_DIR, fname or kadry_file_name(ym))
    wb.save(path)
    return path


POOL_CITY = ENV.get("POOL_CITY", "Chełm")


# ---------- aktualizacje ----------
# Владелец присылает боту aktualizacja-*.zip (или жмёт /aktualizuj и присылает файл). Бот показывает version.txt,
# после «Zainstaluj» проверяет синтаксис, кладёт текущие файлы в backups/code-ДАТА/, заменяет их и перезапускается.
# updates/pending.json: если новая версия 3 раза подряд не продержится 90 с, update_guard.py (из run_bot.cmd)
# вернёт прежние файлы. /przywroc — вернуть предыдущую версию вручную.

UPDATE_FILES = {"pool_bot.py", "editor.html", "update_guard.py", "README.md", "PRZENIESIENIE.md", "install.ps1",
                "install.cmd", "wylacz_autostart.cmd", "requirements.txt", "stop_bot.cmd", "restart_bot.cmd", "start_bot.vbs"}
UPDATE_SKIP = {"run_bot.cmd", "version.txt"}   # run_bot.cmd работает во время обновления — меняется только вручную
UPDATE_OK_SEC = 90


def upd_dir():
    d = os.path.join(BASE, "updates")
    os.makedirs(d, exist_ok=True)
    return d


def update_check_zip(path):
    """(файлы {имя: путь в zip}, текст version.txt, ошибка)."""
    import zipfile
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        return None, "", "To nie jest plik zip."
    files, info, bad = {}, "", []
    for n in z.namelist():
        if n.endswith("/"):
            continue
        name = n.replace("\\", "/").split("/")[-1]
        if name == "version.txt":
            info = z.read(n).decode("utf-8", errors="replace")[:1500]
        elif name in UPDATE_FILES:
            files[name] = n
        elif name not in UPDATE_SKIP:
            bad.append(name)
    if bad:
        return None, info, "W archiwum są pliki, których bot nie podmienia: " + ", ".join(bad[:8]) + ". Nic nie zainstalowano."
    if not files:
        return None, info, "W archiwum nie ma plików bota."
    return files, info, None


def can_update(state, uid):
    """Ставить и откатывать обновления могут владелец и директора (бот работает на компьютере директора)."""
    uid = str(uid or "")
    return bool(uid) and (uid == owner_id(state) or uid in admin_ids(state))


def update_people(state):
    """Кому сообщать о новой версии и о результате обновления: владелец и все директора."""
    return list(dict.fromkeys([u for u in [owner_id(state)] + sorted(admin_ids(state)) if u and not u.startswith("test")]))


def update_received(state, chat_id, doc):
    if not can_update(state, chat_id):
        send(chat_id, "Aktualizacje może instalować tylko kierownik lub właściciel bota.")
        return
    path = os.path.join(upd_dir(), "incoming.zip")
    try:
        fp = tg("getFile", file_id=doc["file_id"])["result"]["file_path"]
        with urllib.request.urlopen(f"https://api.telegram.org/file/bot{TOKEN}/{fp}", timeout=60) as r, open(path, "wb") as f:
            f.write(r.read())
    except Exception as e:  # noqa: BLE001
        log(f"update download failed: {e!r}")
        send(chat_id, "Nie udało się pobrać pliku.")
        return
    update_offer(state, chat_id, path)


def update_offer(state, chat_id, path):
    files, info, err = update_check_zip(path)
    if err:
        send(chat_id, "⚠️ " + err)
        return
    state["pending_update"] = {"path": path, "files": sorted(files)}
    save_state(state)
    send(chat_id, f"🔄 Aktualizacja bota (teraz wersja {VERSION})\n\n{info.strip() or '(brak opisu)'}\n\n"
                  f"Pliki: {', '.join(sorted(files))}.\nDane, ustawienia i token zostają bez zmian. Bot uruchomi się "
                  "ponownie (ok. 15 s). Jeśli nowa wersja nie wystartuje, wróci poprzednia.\n\nZainstalować?",
         ikb([[btn("✅ Zainstaluj", "upd:ok"), btn("Anuluj", "upd:no")]]))


def update_install(state, chat_id, msg, yes):
    import zipfile
    pend = state.pop("pending_update", None)
    save_state(state)
    if not yes or not pend or not can_update(state, chat_id):
        edit(chat_id, msg["message_id"], "Aktualizacja anulowana." if pend else "To jest już nieaktualne.")
        return
    files, info, err = update_check_zip(pend["path"])
    if err:
        edit(chat_id, msg["message_id"], "⚠️ " + err)
        return
    stage = os.path.join(upd_dir(), "new")
    shutil.rmtree(stage, ignore_errors=True)
    os.makedirs(stage)
    with zipfile.ZipFile(pend["path"]) as z:
        for name, n in files.items():
            with open(os.path.join(stage, name), "wb") as f:
                f.write(z.read(n))
    if "pool_bot.py" in files:   # синтаксис проверяем до замены
        chk = subprocess.run([sys.executable, "-m", "py_compile", os.path.join(stage, "pool_bot.py")],
                             capture_output=True, text=True)
        if chk.returncode:
            edit(chat_id, msg["message_id"], "⚠️ Nowa wersja ma błąd, nic nie zainstalowano:\n" + (chk.stderr or "")[-600:])
            return
    backup = os.path.join(BASE, "backups", "code-" + time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(backup)
    for name in UPDATE_FILES:
        if os.path.exists(os.path.join(BASE, name)):
            shutil.copy(os.path.join(BASE, name), os.path.join(backup, name))
    for name in files:
        shutil.copy(os.path.join(stage, name), os.path.join(BASE, name))
    version = next((ln.strip() for ln in info.splitlines() if ln.strip()), "")[:80]
    with open(os.path.join(upd_dir(), "pending.json"), "w", encoding="utf-8") as f:
        json.dump({"backup": backup, "version": version, "chat": chat_id, "attempts": 0}, f, ensure_ascii=False)
    log(f"Aktualizacja zainstalowana ({version}), kopia: {os.path.basename(backup)}; restart")
    edit(chat_id, msg["message_id"], "⏳ Instaluję i uruchamiam ponownie… Za chwilę napiszę, czy wszystko działa.")
    restart_self()


# ---------- aktualizacje przez internet ----------
# Бот раз в UPDATE_CHECK_MIN минут (по умолчанию 10) читает latest.json по адресу UPDATE_URL:
#   {"version": "2026-11-19", "notes": "что нового", "zip": "aktualizacja-20261119.zip", "sha256": "..."}
# Если версия новее текущей, владелец получает «🔔 Jest nowa wersja» с кнопкой «🔄 Aktualizuj».
# По кнопке бот скачивает zip, сверяет sha256 и ставит его тем же путём, что и присланный файл
# (проверка синтаксиса, копия в backups/, автоматический откат). /sprawdz — проверить вручную.
# UPDATE_URL=off в .env выключает проверку.

DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/Pancrupt/Invest-app/pool-bot-updates/latest.json"
UPDATE_URL = (ENV.get("UPDATE_URL") or DEFAULT_UPDATE_URL).strip()
UPDATE_CHECK_MIN = max(5, int_env("UPDATE_CHECK_MINUTES", 10))   # как часто смотреть, нет ли новой версии


def update_fetch_manifest():
    """(манифест или None, ошибка). Манифест берётся без кэша, чтобы видеть свежую версию сразу."""
    if UPDATE_URL.lower() in ("off", "0", "nie", "no"):
        return None, "Sprawdzanie aktualizacji jest wyłączone (UPDATE_URL=off)."
    urls = [(UPDATE_URL + ("&" if "?" in UPDATE_URL else "?") + "t=" + str(int(time.time())), {})]
    gh = re.match(r"https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$", UPDATE_URL)
    if gh:   # raw.githubusercontent кэширует файл до 5 минут; API GitHub отдаёт свежую версию сразу
        o, r_, br, fp = gh.groups()
        urls.insert(0, (f"https://api.github.com/repos/{o}/{r_}/contents/{fp}?ref={br}",
                        {"Accept": "application/vnd.github.raw"}))
    m, last = None, None
    for url, hdr in urls:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "pool-bot", "Cache-Control": "no-cache", **hdr})
            with urllib.request.urlopen(req, timeout=30) as r:
                m = json.loads(r.read().decode("utf-8"))
            break
        except Exception as e:  # noqa: BLE001
            last = e
    if m is None:
        log(f"update check failed: {last!r}")
        return None, "Nie udało się sprawdzić aktualizacji (brak internetu albo serwer niedostępny)."
    if not isinstance(m, dict) or not m.get("version") or not m.get("zip") or not m.get("sha256"):
        return None, "Plik z informacją o aktualizacji jest niepoprawny."
    return m, None


def update_is_newer(version):
    return str(version).strip() > VERSION


def update_notice_text(m):
    return (f"🔔 Jest nowa wersja bota: {m['version']} (teraz {VERSION}).\n\n"
            f"{(m.get('notes') or '').strip()[:1500] or '(brak opisu)'}\n\n"
            "Dane, ustawienia i token zostają bez zmian. Po «🔄 Aktualizuj» bot pobierze nową wersję, "
            "uruchomi się ponownie (ok. 15 s) i napisze, czy wszystko działa. Jeśli nowa wersja nie wystartuje, "
            "sam wróci do poprzedniej.")


def update_notice_kb():
    return ikb([[btn("🔄 Aktualizuj", "updnet"), btn("Później", "updlater")]])


def update_check(state, chat_id=None):
    """Проверить latest.json. chat_id — ручная проверка (/sprawdz): отвечаем всегда.
    Без chat_id (фоновая проверка) пишем владельцу и директорам только один раз на каждую новую версию."""
    m, err = update_fetch_manifest()
    if err:
        if chat_id:
            send(chat_id, "⚠️ " + err)
        return
    with LOCK:
        if not update_is_newer(m["version"]):
            state.pop("update_available", None)
            save_state(state)
            if chat_id:
                send(chat_id, f"✅ Masz najnowszą wersję bota ({VERSION}).")
            return
        already = (state.get("update_available") or {}).get("version") == m["version"]
        state["update_available"] = {"version": m["version"], "notes": (m.get("notes") or "")[:1500]}
        save_state(state)
    for u in ([chat_id] if chat_id else [] if already else update_people(state)):
        send(u, update_notice_text(m), update_notice_kb())


def update_poll(state):
    time.sleep(120)   # даём боту спокойно запуститься
    while True:
        try:
            update_check(state)
        except Exception as e:  # noqa: BLE001
            log(f"update poll failed: {e!r}")
        time.sleep(UPDATE_CHECK_MIN * 60)


def update_from_net(state, chat_id, msg=None):
    """Кнопка «🔄 Aktualizuj»: скачать zip из latest.json, сверить sha256 и установить."""
    import hashlib as _h
    from urllib.parse import urljoin

    def say(text):
        if msg:
            edit(chat_id, msg["message_id"], text)
        else:
            send(chat_id, text)

    if not can_update(state, chat_id):
        say("Aktualizacje może instalować tylko kierownik lub właściciel bota.")
        return
    m, err = update_fetch_manifest()
    if err:
        say("⚠️ " + err)
        return
    if not update_is_newer(m["version"]):
        state.pop("update_available", None)
        save_state(state)
        say(f"✅ Masz już najnowszą wersję ({VERSION}).")
        return
    say(f"⏳ Pobieram wersję {m['version']}…")
    path = os.path.join(upd_dir(), "incoming.zip")
    zip_url = urljoin(UPDATE_URL, m["zip"])
    urls = [(zip_url, {})]
    gh = re.match(r"https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$", zip_url)
    if gh:   # сначала API GitHub: raw-адрес до 5 минут отдаёт старый файл
        o, r_, br, fp = gh.groups()
        urls.insert(0, (f"https://api.github.com/repos/{o}/{r_}/contents/{fp}?ref={br}",
                        {"Accept": "application/vnd.github.raw"}))
    data, want = None, str(m["sha256"]).strip().lower()
    for url, hdr in urls:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "pool-bot", **hdr})
            with urllib.request.urlopen(req, timeout=120) as r:
                got = r.read()
        except Exception as e:  # noqa: BLE001
            log(f"update download failed ({url}): {e!r}")
            continue
        data = got
        if _h.sha256(got).hexdigest().lower() == want:
            break
    if data is None:
        say("⚠️ Nie udało się pobrać aktualizacji. Spróbuj później: /sprawdz")
        return
    if _h.sha256(data).hexdigest().lower() != want:
        log("update sha256 mismatch")
        say("⚠️ Pobrany plik się nie zgadza (inna suma kontrolna), nic nie zainstalowano. Jeśli wersja dopiero co się pojawiła, spróbuj za 5 minut: /sprawdz")
        return
    with open(path, "wb") as f:
        f.write(data)
    files, info, err = update_check_zip(path)
    if err:
        say("⚠️ " + err)
        return
    state["pending_update"] = {"path": path, "files": sorted(files)}
    state.pop("update_available", None)
    save_state(state)
    if msg is None:
        msg = tg("sendMessage", chat_id=chat_id, text="⏳ Instaluję…").get("result") or {}
    update_install(state, chat_id, msg, True)


def restart_self():
    """Выход с кодом 1: run_bot.cmd запустит бота заново через 10 с; туннель cloudflared остаётся."""
    threading.Timer(1.0, lambda: os._exit(1)).start()


def update_after_start(state):
    """После запуска: сообщить об откате или, если новая версия продержалась 90 с, — об успешном обновлении."""
    d = upd_dir()
    rb = os.path.join(d, "rollback.json")
    if os.path.exists(rb):
        try:
            with open(rb, encoding="utf-8") as f:
                r = json.load(f)
            for u in update_people(state):
                send(u, f"⚠️ Aktualizacja nie powiodła się ({r.get('version') or '?'}), przywrócono poprzednią "
                        f"wersję {VERSION}.\nBłąd (koniec bot.log):\n{(r.get('error') or '')[-800:]}")
        finally:
            os.remove(rb)
    pend = os.path.join(d, "pending.json")
    if not os.path.exists(pend):
        return

    def confirm():
        time.sleep(UPDATE_OK_SEC)
        try:
            with open(pend, encoding="utf-8") as f:
                p = json.load(f)
            os.remove(pend)
        except (OSError, ValueError):
            return
        log(f"Aktualizacja działa: wersja {VERSION}")
        for u in dict.fromkeys([p.get("chat")] + update_people(state)):
            if u:
                send(u, f"✅ Zaktualizowano do wersji {VERSION}." + (f" ({p['version']})" if p.get("version") else "")
                     + "\nGdyby coś było nie tak: /przywroc — powrót do poprzedniej wersji.")

    threading.Thread(target=confirm, daemon=True).start()


def update_rollback(state, chat_id, msg=None, sure=False):
    if not can_update(state, chat_id):
        return
    d = os.path.join(BASE, "backups")
    backups = sorted(x for x in os.listdir(d) if x.startswith("code-")) if os.path.isdir(d) else []
    if not backups:
        send(chat_id, "Nie ma zapisanej poprzedniej wersji.")
        return
    last = os.path.join(d, backups[-1])
    if not sure:
        send(chat_id, f"↩️ Przywrócić poprzednią wersję (kopia z {backups[-1][5:]})? Bot uruchomi się ponownie, dane zostają.",
             ikb([[btn("✅ Przywróć", "updrb"), btn("Anuluj", "noop")]]))
        return
    for name in os.listdir(last):
        shutil.copy(os.path.join(last, name), os.path.join(BASE, name))
    try:
        os.remove(os.path.join(upd_dir(), "pending.json"))
    except OSError:
        pass
    shutil.rmtree(last, ignore_errors=True)   # следующий /przywroc вернёт ещё более раннюю версию
    log(f"Przywrócono poprzednią wersję z {backups[-1]}")
    if msg:
        edit(chat_id, msg["message_id"], "↩️ Przywracam poprzednią wersję i uruchamiam ponownie…")
    restart_self()


def kadry_title(ym):
    y, m = ym_parts(ym)
    return f"Grafik za okres 01.{m:02d}.{y} – {ndays(ym):02d}.{m:02d}.{y}, {POOL_CITY}"


def kadry_file_name(ym):
    """Имя файла для кадров: «Grafik za okres 01.11.2026-30.11.2026 Chełm.xlsx» (без символов, мешающих Windows)."""
    y, m = ym_parts(ym)
    return f"Grafik za okres 01.{m:02d}.{y}-{ndays(ym):02d}.{m:02d}.{y} {POOL_CITY}.xlsx"


# ---------- archiwum do przeniesienia ----------

ARCHIVE_FILES = ["pool_bot.py", "editor.html", "update_guard.py", "state.json", ".env", "cloudflared.exe", "README.md", "PRZENIESIENIE.md",
                 "install.cmd", "install.ps1", "wylacz_autostart.cmd", "requirements.txt", "run_bot.cmd", "start_bot.vbs",
                 "stop_bot.cmd", "restart_bot.cmd", "tickets.log"]


def make_archive(state):
    """Свежий zip папки бота: программа, данные, .env, файлы, 3 последние копии; без логов и адреса туннеля."""
    import zipfile
    save_state(state)
    path = os.path.join(SCHEDULE_DIR, f"pool-bot-przeniesienie-{time.strftime('%Y%m%d-%H%M')}.zip")
    os.makedirs(SCHEDULE_DIR, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in ARCHIVE_FILES:
            if os.path.exists(os.path.join(BASE, f)):
                z.write(os.path.join(BASE, f), f"pool-bot/{f}")
        for f in os.listdir(SCHEDULE_DIR):
            full = os.path.join(SCHEDULE_DIR, f)
            if os.path.isfile(full) and not f.startswith("pool-bot-przeniesienie-"):
                z.write(full, f"pool-bot/grafiki/{f}")
        bdir = os.path.join(BASE, "backups")
        if os.path.isdir(bdir):
            for f in sorted(os.listdir(bdir), key=lambda x: os.path.getmtime(os.path.join(bdir, x)))[-3:]:
                z.write(os.path.join(bdir, f), f"pool-bot/backups/{f}")
    return path


def send_archive(state, chat_id):
    if chat_id != owner_id(state):
        send(chat_id, "Ta funkcja jest tylko dla właściciela bota.")
        return
    path = make_archive(state)
    mb = os.path.getsize(path) / 1e6
    send_document(chat_id, path, f"📦 Archiwum do przeniesienia bota ({mb:.1f} MB, {time.strftime('%d.%m %H:%M')}).\n"
                                 "Zawiera token bota i dane osobowe pracowników — tylko do przeniesienia, nie przesyłaj dalej.\n"
                                 "Dane są aktualne na teraz; bot dalej tu działa.", "application/zip")
    os.remove(path)
    log(f"Archiwum do przeniesienia wysłane właścicielowi ({mb:.1f} MB)")
    send(chat_id, "W dniu przeniesienia: najpierw zatrzymaj bota tutaj, potem kopiuj. Mogę to zrobić za Ciebie: "
                  "wyślę świeże archiwum i od razu zatrzymam bota na tym komputerze (bez automatycznego startu).",
         ikb([[btn("⏹ Wyślij świeże archiwum i zatrzymaj bota tutaj", "archstop")]]))


def archive_stop(state, chat_id, msg, sure):
    if chat_id != owner_id(state):
        return
    if not sure:
        edit(chat_id, msg["message_id"], "Na pewno? Bot przestanie działać na tym komputerze, dopóki nie uruchomisz go "
                                         "na nowym (install.cmd -Start).", ikb([[btn("✅ Tak, zatrzymaj", "archstopy"), btn("Anuluj", "noop")]]))
        return
    path = make_archive(state)
    send_document(chat_id, path, "📦 Świeże archiwum (bot zatrzymany). Rozpakuj na nowym komputerze i uruchom install.cmd -Start. "
                                 "Zawiera token i dane osobowe — nie przesyłaj dalej.", "application/zip")
    os.remove(path)
    edit(chat_id, msg["message_id"], "⏹ Bot zatrzymany na tym komputerze. Uruchom go na nowym.")
    try:
        os.remove(os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup\Bot grafiki (basen).lnk"))
    except OSError:
        pass
    log("Przeniesienie: bot zatrzymany na tym komputerze, autostart usunięty")
    kill_old_tunnel()
    os._exit(3)   # run_bot.cmd po kodzie 3 nie uruchamia bota ponownie


def kadry_export(state, chats):
    month = cur_month(state)
    if not month or kadry_of(month).get("sched") is None:
        return "Najpierw ułóż grafik dla kadr."
    bad = sum(len(kadry_violations(state, month, u)) for u in active(state))
    path = write_kadry_xlsx(state, month)
    history_save(state, month["ym"], "kadry", kadry_of(month)["sched"])
    for c in chats:
        send_document(c, path, kadry_title(month["ym"]) + (f" (uwaga: naruszeń przepisów: {bad})" if bad else ""))
    return None


# ---------- cofnij / ponów ----------
# Перед каждой правкой в «Grafik» сохраняем снимок графика месяца (отдельно для сотрудников и для кадр) вместе с
# закрытыми днями и обсадой. month["undo"|"redo"][вид] — стеки снимков, month["gen"][вид] — состояние сразу после
# последнего «Ułóż». Хранится в state, переживает перезапуск, удаляется вместе с месяцем.

UNDO_MAX = 40
UNDO_KINDS = {"/api/set": ("emp",), "/api/move": ("emp",), "/api/build": ("emp",), "/api/over/apply": ("emp",),
              "/api/over/all": ("emp",), "/api/autofill": ("emp",),
              "/api/kadry/set": ("kadry",), "/api/kadry/move": ("kadry",), "/api/kadry/build": ("kadry",),
              "/api/kadry/level": ("kadry",),
              "/api/closed": ("emp", "kadry"), "/api/staffing": ("emp", "kadry"), "/api/staffing/del": ("emp", "kadry"),
              "/api/staffing/day": ("emp", "kadry")}
BUILD_PATHS = {"/api/build": "emp", "/api/autofill": "emp", "/api/kadry/build": "kadry"}


def undo_snap(state, month, kind):
    import copy
    ym = month["ym"]
    sched = month.get("schedule") if kind == "emp" else kadry_of(month).get("sched")
    return {"sched": copy.deepcopy(sched), "closed": copy.deepcopy(CLOSED_DAYS.get(ym)),
            "staff": copy.deepcopy(state.get("staffing")), "day_need": copy.deepcopy(DAY_NEED.get(ym)),
            "pub": bool(month.get("published"))}


def undo_label(state, path, data, month):
    ym = month["ym"]
    d = data.get("d")
    who = ename(state, str(data.get("uid"))) if data.get("uid") else ""
    day = f"{int(d):02d}.{ym[5:]}" if d else ""
    code = str(data.get("code") or "")
    return {"/api/set": f"{code.split('@')[0] or 'usunięcie zmiany'} {day} — {who}",
            "/api/kadry/set": f"{code.split('@')[0] or 'usunięcie zmiany'} {day} — {who}",
            "/api/move": f"przeniesienie {day} → {int(data.get('d2') or 0):02d}.{ym[5:]} — {who}",
            "/api/kadry/move": f"przeniesienie {day} → {int(data.get('d2') or 0):02d}.{ym[5:]} — {who}",
            "/api/build": "Ułóż od nowa", "/api/autofill": "Auto dla bez odpowiedzi", "/api/kadry/build": "Ułóż grafik dla kadr",
            "/api/kadry/level": f"Wyrównaj do normy — {who}", "/api/over/apply": f"nadwyżka {day} — {who}",
            "/api/over/all": "nadwyżka: wszystko", "/api/closed": f"{'zamknięcie' if data.get('closed') else 'otwarcie'} dnia {day}",
            "/api/staffing": "Obsada zmian", "/api/staffing/del": "Obsada zmian", "/api/staffing/day": f"minimum dnia {day}",
            }.get(str(path), "zmiana")


def undo_begin(state, path, data):
    kinds = UNDO_KINDS.get(path)
    month = cur_month(state)
    if path == "/api/closed":
        month = state["months"].get(str(data.get("ym")))
    if not kinds or not month:
        return None
    return {"month": month, "kinds": kinds, "path": path, "label": undo_label(state, path, data, month),
            "before": {k: undo_snap(state, month, k) for k in kinds}}


def undo_end(state, ctx, err):
    if not ctx or err:
        return
    month = ctx["month"]
    for k in ctx["kinds"]:
        before, after = ctx["before"][k], undo_snap(state, month, k)
        if before == after:
            continue
        before["label"], before["at"] = ctx["label"], time.strftime("%H:%M")
        stack = month.setdefault("undo", {}).setdefault(k, [])
        stack.append(before)
        del stack[:-UNDO_MAX]
        month.setdefault("redo", {})[k] = []
        if BUILD_PATHS.get(ctx["path"]) == k:
            month.setdefault("gen", {})[k] = after
    save_state(state)


def undo_apply(state, month, kind, snap):
    """Вернуть снимок. В уже отправленном графике сотрудники получают сообщения только о своих изменённых днях."""
    ym = month["ym"]
    old = (month.get("schedule") if kind == "emp" else kadry_of(month).get("sched")) or {}
    if kind == "emp":
        month["schedule"] = snap["sched"]
    else:
        kadry_of(month)["sched"] = snap["sched"]
    if snap.get("closed"):
        CLOSED_DAYS[ym] = snap["closed"]
    else:
        CLOSED_DAYS.pop(ym, None)
    if snap.get("staff") is not None:
        state["staffing"][:] = snap["staff"]
    if snap.get("day_need"):
        DAY_NEED[ym] = snap["day_need"]
    else:
        DAY_NEED.pop(ym, None)
    if kind == "emp" and month.get("published"):
        new = month["schedule"] or {}
        for u in state["employees"]:
            changes = []
            for d in range(1, ndays(ym) + 1):
                a, b_ = old.get(str(d), {}).get(u), new.get(str(d), {}).get(u)
                if a != b_:
                    changes.append(f"{dlabel(ym, d)} — " + (f"teraz {sh_text(b_)}" if b_ else "zmiana usunięta"))
            if changes:
                notify_change(state, month, u, "\n" + "\n".join(changes))


def undo_step(state, kind, redo=False):
    month = cur_month(state)
    if not month or kind not in ("emp", "kadry"):
        return "Nie ma bieżącego miesiąca."
    src = month.setdefault("redo" if redo else "undo", {}).setdefault(kind, [])
    dst = month.setdefault("undo" if redo else "redo", {}).setdefault(kind, [])
    if not src:
        return "Nie ma czego " + ("ponowić." if redo else "cofnąć.")
    snap = src.pop()
    cur = undo_snap(state, month, kind)
    cur["label"], cur["at"] = snap.get("label"), time.strftime("%H:%M")
    dst.append(cur)
    del dst[:-UNDO_MAX]
    undo_apply(state, month, kind, snap)
    save_state(state)
    log(f"{'Ponów' if redo else 'Cofnij'} ({kind}): {snap.get('label')}")
    return None


def undo_to_gen(state, kind):
    month = cur_month(state)
    gen = (month or {}).get("gen", {}).get(kind)
    if not gen:
        return "Nie ma zapisanej wersji wygenerowanej."
    import copy
    cur = undo_snap(state, month, kind)
    cur["label"], cur["at"] = "powrót do wersji wygenerowanej", time.strftime("%H:%M")
    month.setdefault("undo", {}).setdefault(kind, []).append(cur)
    month.setdefault("redo", {})[kind] = []
    undo_apply(state, month, kind, copy.deepcopy(gen))
    save_state(state)
    return None


def undo_payload(month):
    res = {}
    for k in ("emp", "kadry"):
        u, r = (month.get("undo") or {}).get(k) or [], (month.get("redo") or {}).get(k) or []
        res[k] = {"n": len(u), "label": u[-1].get("label") if u else None, "pub": u[-1].get("pub") if u else None,
                  "redo_n": len(r), "redo_label": r[-1].get("label") if r else None, "gen": bool((month.get("gen") or {}).get(k))}
    return res


# ---------- dni wolne (basen zamknięty) ----------

def closed_calendar(state, ym):
    """Текущий месяц и три следующих: чтобы закрыть день заранее, ещё до сбора диспозиций."""
    res = []
    for _ in range(4):
        month = state["months"].get(ym) or {}
        sched, ksched = month.get("schedule") or {}, (month.get("kadry") or {}).get("sched") or {}
        hol = holidays_pl(ym_parts(ym)[0])
        days = []
        for d in range(1, ndays(ym) + 1):
            day = date_of(ym, d)
            days.append({"d": d, "wd": DAYS[day.weekday()], "closed": is_closed(ym, d), "holiday": day in hol,
                         "working": [ename(state, u) for u in sched.get(str(d), {})],
                         "kworking": len(ksched.get(str(d), {}))})
        res.append({"ym": ym, "title": month_title(ym), "built": bool(sched), "kbuilt": bool(ksched),
                    "published": bool(month.get("published")), "days": days})
        y, m = ym_parts(ym)
        ym = next_ym(dt.date(y, m, 1))
    return res


def set_closed(state, ym, d, closed, rebuild=False):
    """Закрыть или открыть день. При закрытии смены этого дня снимаются; если график уже у сотрудников,
    им приходит сообщение. rebuild — разложить неопубликованный черновик (и график для кадр) заново."""
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(ym)) or not 1 <= d <= ndays(ym):
        return "Nie ma takiego dnia."
    if is_closed(ym, d) == bool(closed):
        return None
    c = CLOSED_DAYS.setdefault(ym, {"closed": [], "open": []})
    for lst in c.values():
        if d in lst:
            lst.remove(d)
    default = bool(CLOSED_ON_HOLIDAYS) and date_of(ym, d) in holidays_pl(ym_parts(ym)[0])
    if bool(closed) != default:
        c["closed" if closed else "open"].append(d)
    if not c["closed"] and not c["open"]:
        CLOSED_DAYS.pop(ym, None)
    log(f"{'Dzień wolny' if closed else 'Dzień otwarty'}: {d} {month_title(ym)}")
    month = state["months"].get(ym)
    if month:
        if closed:
            removed = (month.get("schedule") or {}).get(str(d), {})
            who = list(removed)
            removed.clear()
            ksched = kadry_of(month).get("sched")
            if ksched:
                ksched[str(d)] = {}
            for r in month.get("requests", []):
                if r["day"] == d and r["status"] == "pending":
                    r["status"] = "rejected"
            if month.get("calls"):
                month["calls"] = [x for x in month["calls"] if not (x["d"] == d and x["status"] == "open")]
            for u in who:
                notify_change(state, month, u, f"{dlabel(ym, d)}: basen zamknięty, Twoja zmiana jest odwołana.")
        if rebuild and not month.get("published"):
            if month.get("schedule"):
                build_schedule(state, month)
            if kadry_of(month).get("sched") is not None:
                build_kadry(state, month)
    save_state(state)
    return None


# ---------- dodatkowe zmiany (nadgodziny do rozliczenia) ----------
# Сверх нормы месяца в отправленном графике сотрудников накапливается счётчик (в сменах по 8 ч). Директор отмечает,
# сколько смен передал в кадры (не больше EXTRA_MAX_MONTH за месяц), и счётчик уменьшается. График для кадр не меняется:
# бот только предлагает дни, куда кадры могут записать эти смены по Кодексу. state["extra"][uid] = {"start": часов на
# начало, "sent": [{"ym", "n", "at"}]}.

EXTRA_MAX_MONTH = int_env("EXTRA_MAX_MONTH", 5)
EXTRA_FROM = ENV.get("EXTRA_FROM", "2026-10")   # счётчик ведём с этого месяца
SHIFT_H = 8


def extra_days(state, month, uid, want):
    """Дни в графике для кадр, куда по правилам можно записать смены: план (вместе не нарушает правил) и другие варианты."""
    sched = kadry_of(month).get("sched")
    if sched is None:
        return None
    ym, n = month["ym"], ndays(month["ym"])
    y, m = ym_parts(ym)
    tl, manual = kadry_timeline(state, month, sched, uid), manual_sundays(month, uid)
    leave = month_leave(month)

    def free(d):
        return uid not in sched[str(d)] and uid not in leave.get(str(d), {}) and not is_gone(ym, d, uid)

    def fits(d, code):
        cov = kcoverage(month, sched, d)
        return (not any(cov[p] >= max_for(month["ym"]) for p in SHIFTS[code]["covers"])
                and not place_reason(month, tl, manual, dt.date(y, m, d), code))

    options_ = [d for d in range(1, n + 1) if free(d) and any(fits(d, c) for c in KADRY_CODES)]
    plan = []
    # сначала дни, где не хватает людей, и равномерно по месяцу
    for d in sorted(options_, key=lambda x: (min(kcoverage(month, sched, x)[p] - need_for(ym, x)[p] for p in PERIODS), x)):
        if len(plan) >= want:
            break
        if any(abs(d - x["d"]) < 2 for x in plan):
            continue
        code = next((c for c in sorted(KADRY_CODES, key=lambda c: kcoverage(month, sched, d)[SHIFTS[c]["covers"][0]]) if fits(d, c)), None)
        if code:
            plan.append({"d": d, "code": code})
            tl[dt.date(y, m, d)] = code
    for d in sorted(options_):   # если через день не набралось — добираем подряд
        if len(plan) >= want:
            break
        if not any(x["d"] == d for x in plan):
            code = next((c for c in KADRY_CODES if fits(d, c)), None)
            if code:
                plan.append({"d": d, "code": code})
                tl[dt.date(y, m, d)] = code
    chosen = {x["d"] for x in plan}
    return {"plan": sorted(plan, key=lambda x: x["d"]), "other": [d for d in options_ if d not in chosen]}


def extra_info(state, uid):
    """Счётчик сотрудника: накоплено, передано, остаток, предложения дней на текущий месяц."""
    rec = state.get("extra", {}).get(uid) or {}
    months = []
    for ym in sorted(set(state["months"]) | set(state.get("history", {}))):
        if ym < EXTRA_FROM:
            continue
        m = state["months"].get(ym)
        h = state.get("history", {}).get(ym) or {}
        if m and m.get("published"):
            worked = hours_of(m, uid)
        elif not m and h.get("emp"):   # месяц только в истории: смены плюс urlop/ZW из файла, как в SUMA
            worked = sum(SHIFTS[day[uid]]["hours"] for day in h["emp"]["sched"].values() if uid in day)
            worked += 8 * sum(uid in day for day in (h.get("emp_absences") or {}).values())
        else:
            continue
        t = target_hours(state, uid, ym)
        if t is not None and worked > t:
            # к оплате только целые смены; остаток меньше смены — погрешность, он не копится и не переносится
            whole = (worked - t) // SHIFT_H
            months.append({"ym": ym, "title": month_title(ym), "hours": worked - t, "shifts": int(whole), "rest": (worked - t) - whole * SHIFT_H})
    start = rec.get("start", 0)
    sent = rec.get("sent", [])
    left = max(0, start + SHIFT_H * sum(x["shifts"] for x in months) - SHIFT_H * sum(x["n"] for x in sent))
    cur = state.get("cur")
    sent_now = sum(x["n"] for x in sent if x["ym"] == cur)
    room = max(0, EXTRA_MAX_MONTH - sent_now)
    need = int(-(-left // SHIFT_H))   # неполная смена округляется вверх
    res = {"hours": left, "shifts": left / SHIFT_H, "start": start, "months": months, "sent_now": sent_now,
           "room": min(room, need), "max": EXTRA_MAX_MONTH, "log": sent[-5:], "days": None}
    month = state["months"].get(cur)
    if month and left > 0:
        res["days"] = extra_days(state, month, uid, min(room, need))
    return res


def extra_sent(state, uid, n):
    """Директор передал в кадры n дополнительных смен за текущий месяц."""
    if uid not in active(state):
        return "Nie ma takiego pracownika."
    cur = state.get("cur")
    if not cur:
        return "Nie ma bieżącego miesiąca."
    info = extra_info(state, uid)
    n = int(n)
    if n < 1:
        return "Podaj liczbę zmian."
    if n > info["max"] - info["sent_now"]:
        return f"W jednym miesiącu można rozliczyć najwyżej {info['max']} zmian (już: {info['sent_now']})."
    if n * SHIFT_H - info["hours"] >= SHIFT_H:
        return f"Na liczniku jest tylko {info['hours'] / SHIFT_H:g} zm."
    rec = state.setdefault("extra", {}).setdefault(uid, {})
    rec.setdefault("sent", []).append({"ym": cur, "n": n, "at": time.strftime("%Y-%m-%d %H:%M")})
    save_state(state)
    log(f"Dodatkowe zmiany: {ename(state, uid)} rozliczono {n} ({cur})")
    return None


def extra_undo(state, uid):
    rec = state.get("extra", {}).get(uid) or {}
    if not rec.get("sent"):
        return "Nie ma czego cofnąć."
    rec["sent"].pop()
    save_state(state)
    return None


def extra_start(state, uid, shifts):
    """Stan licznika sprzed bota, w zmianach."""
    if uid not in active(state):
        return "Nie ma takiego pracownika."
    shifts = int(float(shifts))   # только целые смены
    if not 0 <= shifts <= 200:
        return "Podaj liczbę zmian od 0 do 200."
    state.setdefault("extra", {}).setdefault(uid, {})["start"] = round(shifts * SHIFT_H)
    save_state(state)
    return None


# ---------- zwolnienie, byli pracownicy, ręczne dodanie ----------
# Вместо удаления: человек работает до последнего дня, потом выпадает из новых графиков и теряет доступ. История и счётчик
# сохраняются, можно вернуть. Смены в отправленном графике снимаются только по подтверждению директора.

def exit_shifts(state, uid, date):
    """Смены после последнего дня: [(ym, день, код, отправлен ли график, остаётся ли день без людей)]."""
    res = []
    for ym, m in sorted(state["months"].items()):
        for d, day in (m.get("schedule") or {}).items():
            if uid in day and date_of(ym, int(d)).isoformat() > date:
                cov, need = coverage(m, int(d)), need_for(ym, int(d))
                short = any(cov[p] - 1 < need[p] for p in SHIFTS[day[uid]]["covers"])
                res.append({"ym": ym, "d": int(d), "code": day[uid], "label": dlabel(ym, int(d)),
                            "published": bool(m.get("published")), "short": short})
    return sorted(res, key=lambda x: (x["ym"], x["d"]))


def exit_preview(state, uid, date):
    e = state["employees"].get(uid)
    if not e or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(date)):
        return {"error": "Wybierz datę."}
    rows = exit_shifts(state, uid, date)
    return {"name": e["name"], "date": date, "published": [x for x in rows if x["published"]],
            "draft": [x for x in rows if not x["published"]], "extra": extra_info(state, uid)["shifts"]}


def emp_exit(state, uid, date, drop_published=False):
    """Последний рабочий день. Черновик и график для кадр очищаем сразу, отправленный график — только по подтверждению."""
    e = state["employees"].get(uid)
    p = exit_preview(state, uid, date)
    if p.get("error") or not e:
        return p.get("error") or "Nie ma takiego pracownika."
    e["exit"] = date
    for ym, m in state["months"].items():
        for part in ((m.get("kadry") or {}).get("sched"), None if m.get("published") else m.get("schedule")):
            for d, day in (part or {}).items():
                if uid in day and date_of(ym, int(d)).isoformat() > date:
                    del day[uid]
        for r in m.get("requests", []):
            if r["uid"] == uid and r["status"] == "pending" and date_of(ym, r["day"]).isoformat() > date:
                r["status"] = "rejected"
        if m.get("blood", {}).get(uid):
            m["blood"][uid] = [d for d in m["blood"][uid] if date_of(ym, d).isoformat() <= date]
    if drop_published:
        for x in p["published"]:
            m = state["months"][x["ym"]]
            m["schedule"][str(x["d"])].pop(uid, None)
            notify_change(state, m, uid, f"{x['label']} — zmiana usunięta.")
    save_state(state)
    refresh_roles(state)
    log(f"Zwolnienie: {e['name']}, ostatni dzień {date}")
    apply_exits(state)
    return None


def apply_exits(state):
    """После последнего дня: статус «бывший», кнопка «Grafik» убирается. Доступ закрывает уже active()."""
    today = dt.date.today().isoformat()
    changed = False
    for u, e in state["employees"].items():
        if e.get("status") == "active" and e.get("exit") and e["exit"] < today:
            e["status"], changed = "former", True
            log(f"Były pracownik: {e['name']}")
            if not u.startswith(("test", "man")):
                try:
                    tg("setChatMenuButton", chat_id=u, menu_button={"type": "default"})
                except Exception as x:  # noqa: BLE001
                    log(f"setChatMenuButton {u} failed: {x}")
    if changed:
        save_state(state)
        refresh_roles(state)


def emp_restore(state, uid):
    e = state["employees"].get(uid)
    if not e or e.get("status") not in ("former", "active"):
        return "Nie ma takiego pracownika."
    e["status"] = "active"
    e.pop("exit", None)
    save_state(state)
    refresh_roles(state)
    set_menu_button(uid)
    log(f"Przywrócono: {e['name']}")
    return None


def former_payload(state):
    res = []
    for u, e in state["employees"].items():
        if e.get("status") == "former" or (e.get("status") == "active" and e.get("exit") and u not in active(state)):
            res.append({"uid": u, "name": e["name"], "exit": e.get("exit"), "extra": extra_info(state, u)["shifts"],
                        "left": exit_shifts(state, u, e.get("exit") or "0000")})
    return {"people": sorted(res, key=lambda x: x["name"].lower()),
            "hidden": [{"key": k, "name": v} for k, v in sorted((state.get("hist_hidden") or {}).items())]}


def emp_add(state, name, etat):
    """Сотрудник без Telegram: только имя и ставка. Позже может зарегистрироваться по ссылке, и директор его свяжет."""
    name = " ".join(str(name or "").split())[:40]
    if len(name) < 2 or etat not in ETATS:
        return "Podaj imię, nazwisko i etat."
    uid = "man" + uuid.uuid4().hex[:8]
    state["employees"][uid] = {"name": name, "etat": etat, "status": "active", "manual": True}
    hist_auto_link(state, uid)
    save_state(state)
    log(f"Dodano ręcznie: {name}")
    return None


def uid_swap(o, old, new):
    """Заменить uid во всех структурах: ключи и значения."""
    if isinstance(o, dict):
        return {(new if k == old else k): uid_swap(v, old, new) for k, v in o.items()}
    if isinstance(o, list):
        return [uid_swap(x, old, new) for x in o]
    return new if o == old else o


def emp_merge(state, chat_id, msg, new, man):
    """Добавленный вручную зарегистрировался в Telegram: его смены, ставка и история переходят к настоящей учётной записи."""
    a, b_ = state["employees"].get(new), state["employees"].get(man)
    if not a or not b_ or a.get("status") != "pending" or not man.startswith("man"):
        edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    merge_into(state, new, man)
    accept(state, chat_id, msg, new, True)


def merge_into(state, new, man):
    """Перенести всё с записи, добавленной вручную, на настоящую учётную запись Telegram (без дубля)."""
    a, b_ = state["employees"][new], state["employees"][man]
    for k in ("months", "history", "extra", "hist_links", "blood_carry"):
        if k in state:
            fresh = uid_swap(state[k], man, new)
            state[k].clear()
            state[k].update(fresh)
    a.update({k: v for k, v in b_.items() if k in ("name", "etat", "etat_periods", "donor", "exit")})
    a.pop("merge_with", None)
    del state["employees"][man]
    save_state(state)
    log(f"Połączono: {a['name']} (ręcznie dodany → Telegram {new})")


def hist_hide(state, key, hide=True):
    """Человек из истории, который уже не работает и не зарегистрируется: убрать из списков ожидания."""
    hidden = state.setdefault("hist_hidden", {})
    if hide:
        name = hist_unlinked(state).get(key)
        if not name:
            return "Tej osoby nie ma już na liście."
        hidden[key] = name
    else:
        hidden.pop(key, None)
    save_state(state)
    return None


def exit_menu(state, chat_id, msg, uid):
    e = state["employees"].get(uid)
    if not e:
        edit(chat_id, msg["message_id"], "Pracownik został już usunięty.")
        return
    today = dt.date.today()
    last = dt.date(today.year, today.month, calendar.monthrange(today.year, today.month)[1])
    rows = [[btn(f"Dziś: {today:%d.%m}", f"zwc:{uid}:{today.isoformat()}")]]
    if last != today:
        rows.append([btn(f"Koniec miesiąca: {last:%d.%m}", f"zwc:{uid}:{last.isoformat()}")])
    rows.append([btn("Anuluj", f"emp:{uid}")])
    edit(chat_id, msg["message_id"], f"🚪 Zwolnić: {e['name']}. Ostatni dzień pracy? Inną datę wybierzesz w «Grafik» → ✏️ Edytuj pracownika.\n"
                                     "Historia i licznik zostają, można przywrócić.", ikb(rows))


def exit_confirm(state, chat_id, msg, uid, date):
    p = exit_preview(state, uid, date)
    if p.get("error"):
        edit(chat_id, msg["message_id"], p["error"])
        return
    fmt = lambda x: x["label"] + (" ⚠️ zabraknie ludzi" if x["short"] else "")
    text = f"🚪 {p['name']}: ostatni dzień {date[8:]}.{date[5:7]}.{date[:4]}."
    if p["draft"]:
        text += f"\nZe szkicu zniknie {len(p['draft'])} zmian."
    rows = []
    if p["published"]:
        text += "\nW wysłanym grafiku są zmiany po tej dacie:\n" + "\n".join(fmt(x) for x in p["published"][:25])
        rows.append([btn("✅ Potwierdź i usuń te zmiany", f"zwy:{uid}:{date}:1")])
        rows.append([btn("Potwierdź, zmiany zostają (zastępstwa później)", f"zwy:{uid}:{date}:0")])
    else:
        rows.append([btn("✅ Potwierdź", f"zwy:{uid}:{date}:0")])
    rows.append([btn("Anuluj", f"emp:{uid}")])
    edit(chat_id, msg["message_id"], text, ikb(rows))


def web_publish(state, chats):
    month = cur_month(state)
    if not month or not month["schedule"]:
        return "Najpierw ułóż grafik."
    if month["published"]:
        return "Grafik jest już wysłany pracownikom. Zmiany dochodzą do nich automatycznie."
    publish(state, chats[0] if chats else next(iter(admin_ids(state))))
    return None


# ---------- Excel в формате таблицы бассейна ----------

THIN = Side(style="thin", color="808080")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
FILL_HEAD = PatternFill("solid", fgColor="1F4E79")
FILL_HOLIDAY = PatternFill("solid", fgColor="7F7F7F")
FILL_WEEKEND = PatternFill("solid", fgColor="D9D9D9")
FILL_KRW = PatternFill("solid", fgColor="F4A6A6")
FILL_U = PatternFill("solid", fgColor="D9C6F2")   # urlop
KRW_LEGEND = "KRW — zwolnienie honorowego dawcy krwi (płatne)"
FILL_SHORT = PatternFill("solid", fgColor="F8CBAD")
FILL_EXTRA = PatternFill("solid", fgColor="FFE699")
FILL_CODE = {"R1": PatternFill("solid", fgColor="BDD7EE"), "R2": PatternFill("solid", fgColor="C6E0B4"),
             "R3": PatternFill("solid", fgColor="F4B183"), "R4": PatternFill("solid", fgColor="D9C3F0")}
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
BOLD = Font(bold=True)


def write_xlsx(state, month, sched=None, fname=None):
    os.makedirs(SCHEDULE_DIR, exist_ok=True)
    ym = month["ym"]
    y, m = ym_parts(ym)
    n = ndays(ym)
    emps = active(state)
    sched = (month["schedule"] if sched is None else sched) or {}
    emps = {**emps, **{u: state["employees"][u] for day in sched.values() for u in day if u in state["employees"]}}
    first_col, last_col = 3, 2 + n
    col = get_column_letter
    end = col(last_col)
    first_row = 7
    last_row = first_row + 2 * max(len(emps), 1) - 1

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"{MONTHS[m - 1].upper()} {y}"
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 24
    for i in range(first_col, last_col + 1):
        ws.column_dimensions[col(i)].width = 6.5
    for i, w in enumerate((8, 8, 8, 9), last_col + 1):
        ws.column_dimensions[col(i)].width = w

    # строки 1–4: сколько людей стоит утром / вечером и сколько нужно
    ws["B1"], ws["B2"], ws["B3"], ws["B4"] = "RANO", "POPOŁUDNIE", "minimum rano", "minimum popoł."
    for d in range(1, n + 1):
        c = col(first_col + d - 1)
        rng = f"{c}{first_row}:{c}{last_row}"
        ws[f"{c}1"] = f'=COUNTIF({rng},"R1")+COUNTIF({rng},"R3")'
        ws[f"{c}2"] = f'=COUNTIF({rng},"R2")+COUNTIF({rng},"R3")'
        need = need_for(ym, d)
        ws[f"{c}3"], ws[f"{c}4"] = need["rano"], need["popołudnie"]
        for r in (1, 2, 3, 4):
            ws[f"{c}{r}"].alignment = CENTER
            ws[f"{c}{r}"].border = BORDER
    for r, nr in ((1, 3), (2, 4)):
        rng = f"C{r}:{end}{r}"
        ws.conditional_formatting.add(rng, FormulaRule(formula=[f"C{r}<C{nr}"], fill=FILL_SHORT))
        ws.conditional_formatting.add(rng, FormulaRule(formula=[f"C{r}>C{nr}"], fill=FILL_EXTRA))
    for r in (1, 2):
        ws[f"B{r}"].font = BOLD

    ws["B5"], ws["B6"] = "Dzień tyg", "Numer dnia"
    norm = month_norm(state, ym)
    for i, v in enumerate(("SUMA", "ETAT", "NORMA", "RÓŻNICA"), last_col + 1):
        ws.cell(row=5, column=i, value=v)
    ws.cell(row=6, column=last_col + 3, value=f"etat {norm} h")
    hol = holidays_pl(y)
    for d in range(1, n + 1):
        day = date_of(ym, d)
        for r, v in ((5, DAYS_XLS[day.weekday()]), (6, d)):
            cell = ws.cell(row=r, column=first_col + d - 1, value=v)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = FILL_HEAD if day.weekday() < 5 and day not in hol and not is_closed(ym, d) else FILL_HOLIDAY
            cell.alignment = CENTER
    for i in range(last_col + 1, last_col + 5):
        for r in (5, 6):
            ws.cell(row=r, column=i).font = BOLD
            ws.cell(row=r, column=i).alignment = CENTER

    # по две строки на человека: коды смен и оплачиваемые часы (часы считаются формулой из кода)
    r = first_row
    for u, e in emps.items():
        ws.cell(row=r, column=2, value=e["name"].upper()).font = BOLD
        ws.cell(row=r + 1, column=2, value="Czas opłacony")
        for d in range(1, n + 1):
            ci = first_col + d - 1
            code = sched.get(str(d), {}).get(u)
            cell = ws.cell(row=r, column=ci, value=code)
            off = month_leave(month).get(str(d), {}).get(u)
            if code:
                cell.fill = FILL_CODE[code.split("@")[0]]
                cell.value = code.split("@")[0]
            elif off:
                cell.value = off
                if off == "KRW":
                    cell.fill = FILL_KRW
                elif off == "U":
                    cell.fill = FILL_U
            elif date_of(ym, d).weekday() >= 5:
                cell.fill = FILL_WEEKEND
            ref = f"{col(ci)}{r}"
            ws.cell(row=r + 1, column=ci,
                    value=leave_h(ym, d, u, off) if off and not code else SHIFTS[code]["hours"] if code and "@" in code else
                    f'=IF({ref}="R1",{SHIFTS["R1"]["hours"]:g},IF({ref}="R2",{SHIFTS["R2"]["hours"]:g},'
                    f'IF({ref}="R3",{SHIFTS["R3"]["hours"]:g},"")))')
            for rr in (r, r + 1):
                ws.cell(row=rr, column=ci).alignment = CENTER
                ws.cell(row=rr, column=ci).border = BORDER
        th = grafik_hours(state, u, ym)
        ws.cell(row=r, column=last_col + 1, value=f"=SUM(C{r + 1}:{end}{r + 1})").font = BOLD
        ws.cell(row=r, column=last_col + 2, value=etat_for(state, u, ym) if etat_for(state, u, ym) != "0" else "umowa")
        if th is not None:
            ws.cell(row=r, column=last_col + 3, value=th)
            ws.cell(row=r, column=last_col + 4, value=f"={col(last_col + 1)}{r}-{col(last_col + 3)}{r}")
        for i in range(last_col + 1, last_col + 5):
            ws.cell(row=r, column=i).alignment = CENTER
        r += 2
    if any("KRW" in day.values() for day in month_leave(month).values()):
        ws.cell(row=r + 1, column=2, value=KRW_LEGEND).font = BOLD
        ws.cell(row=r + 1, column=2).fill = FILL_KRW
    ws.freeze_panes = "C7"

    # диспозиция: что человек отмечал, чтобы директор видел, кого можно двигать
    ws2 = wb.create_sheet("Dyspozycja")
    ws2.column_dimensions["A"].width = 24
    ws2.cell(row=1, column=1, value="Pracownik").font = BOLD
    for d in range(1, n + 1):
        cell = ws2.cell(row=1, column=1 + d, value=f"{DAYS_XLS[date_of(ym, d).weekday()]}\n{d}")
        cell.font, cell.alignment = BOLD, CENTER
        ws2.column_dimensions[col(1 + d)].width = 7
    for i, (u, e) in enumerate(emps.items(), 2):
        ws2.cell(row=i, column=1, value=e["name"])
        av = month["avail"].get(u)
        for d in range(1, n + 1):
            if not av:
                v = "brak" if d == 1 else None
            elif av.get("all"):
                v = "każda"
            else:
                v = "/".join(av.get("days", {}).get(str(d), [])) or None
            cell = ws2.cell(row=i, column=1 + d, value=v)
            cell.alignment, cell.border = CENTER, BORDER

    ws3 = wb.create_sheet("Zmiany")
    ws3.append(["Kod", "Zmiana", "Godziny pracy", "Ilość godzin"])
    for code, sh in SHIFTS.items():
        ws3.append([code, sh["name"], sh["time"], sh["hours"]])
    for c in "BCD":
        ws3.column_dimensions[c].width = 14

    path = os.path.join(SCHEDULE_DIR, fname or f"Grafik {y}-{m:02d}.xlsx")
    wb.save(path)
    return path


# ---------- сотрудники ----------

def etat_kb(prefix, uid=""):
    return ikb([[btn(label.capitalize(), f"{prefix}:{uid}:{k}" if uid else f"{prefix}:{k}")]
                for k, (label, _) in ETATS.items()])


def reg_text(state, uid, text):
    w = state["wiz"].get(uid, {})
    name = " ".join(text.split())[:40]
    if w.get("step") != "name" or len(name) < 2 or name.startswith("/"):
        send(uid, "Dzień dobry! To bot grafików pływalni. Napisz proszę imię i nazwisko.")
        state["wiz"][uid] = {"step": "name"}
        save_state(state)
        return
    state["wiz"][uid] = {"step": "etat", "name": name}
    save_state(state)
    send(uid, f"{name}, jaki masz etat?", etat_kb("reg"))


def reg_etat(state, uid, msg, key):
    w = state["wiz"].pop(uid, None)
    if not w or w.get("step") != "etat" or key not in ETATS:
        edit(uid, msg["message_id"], "Zacznij od nowa: napisz /start")
        return
    state["employees"][uid] = {"name": w["name"], "etat": key, "status": "pending"}
    hist_auto_link(state, uid)
    save_state(state)
    label = ETATS[key][0]
    edit(uid, msg["message_id"], f"{w['name']}, {label}. Wysłałem zgłoszenie do kierownika, "
                                 "bot napisze, gdy zostanie przyjęte.")
    manual = [(u, e) for u, e in active(state).items() if u.startswith("man")]
    manual.sort(key=lambda x: link_key(x[1]["name"]) != link_key(w["name"]))
    same = [u for u, e in manual if link_key(e["name"]) == link_key(w["name"])]
    if len(same) == 1:   # то же имя, что у добавленного вручную: соединим при «✅ Przyjmij»
        state["employees"][uid]["merge_with"] = same[0]
        save_state(state)
        note, rows = f"🔗 To ta sama osoba co dodana ręcznie: {state['employees'][same[0]]['name']}. Po «✅ Przyjmij» zmiany, etat i historia przejdą na to konto.", []
    else:
        note, rows = hist_note(state, uid)
        rows = rows + [[btn(f"👤 To ta sama osoba: {e['name']}", f"mrg:{uid}:{u}")] for u, e in manual[:5]]
    for a in admin_ids(state):
        send(a, f"Nowy pracownik: {w['name']}, {label}." + (f"\n{note}" if note else ""),
             ikb([[btn("✅ Przyjmij", f"acc:{uid}"), btn("✏️ Zmień etat", f"acce:{uid}"),
                   btn("❌ Odrzuć", f"rej:{uid}")]] + rows))
        if not (state.get("hist_links", {}).get(uid) or {}).get("key") and hist_unlinked(state) \
                and not state["employees"][uid].get("merge_with"):
            hist_link_menu(state, a, uid)


def accept(state, chat_id, msg, uid, yes):
    e = state["employees"].get(uid)
    if not e or e["status"] != "pending":
        edit(chat_id, msg["message_id"], "To zgłoszenie zostało już rozpatrzone.")
        return
    man = e.get("merge_with")
    if yes and man in state["employees"]:
        merge_into(state, uid, man)
    e.pop("merge_with", None)
    e["status"] = "active" if yes else "rejected"
    if yes:
        hist_auto_link(state, uid)
    elif (state.get("hist_links", {}).get(uid) or {}).get("key"):
        hist_link(state, uid, None)   # отклонённый не должен занимать чужую историю
    save_state(state)
    refresh_roles(state)
    if yes:
        note, rows = hist_note(state, uid)
        edit(chat_id, msg["message_id"], f"✅ {e['name']} ({ETATS[e['etat']][0]}) dodany(a)." + (f"\n{note}" if note else ""),
             ikb(rows) if rows else None)
        if state.get("mode") == "test":
            send(uid, "Kierownik przyjął zgłoszenie. Bot jest jeszcze przygotowywany: tabelę dyspozycji dostaniesz, "
                      "gdy kierownik go uruchomi.\n\n" + HELP_EMP, EMP_KB, force=True)
            return
        send(uid, "Kierownik przyjął zgłoszenie.\n\n" + HELP_EMP, EMP_KB)
        set_menu_button(uid)   # «Grafik» — podgląd grafiku i prośby o dodatkowe zmiany
        month = cur_month(state)
        if month and not month["published"]:
            ask_avail(state, uid)
    else:
        edit(chat_id, msg["message_id"], f"❌ Zgłoszenie {e['name']} odrzucone.")
        send(uid, "Kierownik odrzucił zgłoszenie.", force=True)


def accept_with_etat(state, chat_id, msg, uid, key=None):
    """«✏️ Zmień etat» на карточке нового сотрудника: выбрать ставку и сразу принять."""
    e = state["employees"].get(uid)
    if not e or e["status"] != "pending":
        edit(chat_id, msg["message_id"], "To zgłoszenie zostało już rozpatrzone.")
        return
    if key is None:
        edit(chat_id, msg["message_id"], f"{e['name']}: wybierz etat (zgłoszenie zostanie przyjęte).",
             etat_kb("accset", uid))
        return
    if key in ETATS:
        e["etat"] = key
        accept(state, chat_id, msg, uid, True)


def emp_link(state, chat_id, new=False):
    """Ссылка регистрации сотрудников t.me/<бот>?start=emp_<код>: многоразовая, можно заменить новой."""
    if new or not state.get("emp_code"):
        state["emp_code"] = uuid.uuid4().hex[:10]
        save_state(state)
    name = bot_username()
    link = f"https://t.me/{name}?start=emp_{state['emp_code']}" if name else f"/start emp_{state['emp_code']}"
    send(chat_id, "🔗 Tekst do przesłania pracownikom (skopiuj i wyślij):", DIR_KB)
    send(chat_id, "Cześć! Grafik pływalni układamy teraz w Telegramie.\n"
                  f"1. Otwórz link: {link}\n"
                  "2. Kliknij «Start», wpisz imię i nazwisko, wybierz etat.\n"
                  "3. Gdy kierownik zatwierdzi, bot przyśle tabelę dyspozycji: zaznacz dni i kliknij «✅ Gotowe».")
    send(chat_id, ("Link działa dla wielu osób. " if not new else "Nowy link gotowy, poprzedni już nie działa. ") +
         ("Bot jest w trybie testowym: nowi pracownicy mogą się już rejestrować, ale tabelę dyspozycji dostaną "
          f"dopiero po «{B_LAUNCH}»." if state.get("mode") == "test" else ""),
         ikb([[btn("🔄 Nowy link (stary przestanie działać)", "emplinknew")]]))


def staff(state, chat_id):
    emps = active(state)
    ym = state["cur"] or next_ym(dt.date.today())
    lines = [f"Pracowników: {len(emps)}. Norma na pełny etat w {MONTHS_LOC[ym_parts(ym)[1] - 1]}: "
             f"{month_norm(state, ym)} h."]
    for u, e in emps.items():
        lines.append(f"• {e['name']} — {ETATS[etat_for(state, u, ym)][0]}")
    pending = [e["name"] for e in state["employees"].values() if e["status"] == "pending"]
    if pending:
        lines.append(f"Czekają na akceptację: {', '.join(pending)}")
    un = hist_unlinked(state)
    linked = [u for u, ln in state.get("hist_links", {}).items() if ln.get("key") and u in emps]
    if un or linked:
        lines.append(f"Zarejestrowani z historii: {len(linked)} z {len(linked) + len(un)}"
                     + (f". Jeszcze nie ma: {', '.join(sorted(un.values()))}" if un else ""))
    link = bot_username()
    if link:
        lines.append(f"\nLink dla pracowników: https://t.me/{link}\n"
                     "Pracownik otwiera link, klika «Start», pisze imię i wybiera etat, a Ty dostajesz zgłoszenie.")
    rows = [[btn(f"⚙️ {e['name']}", f"emp:{u}")] for u, e in emps.items()]
    un = hist_unlinked(state)
    if un:
        rows.append([btn(f"🔗 Powiąż pracowników ({len(hist_waiting(state))})", "hlall")])
        rows.append([btn(f"📋 Osoby z historii bez powiązania ({len(un)})", "hll")])
    rows += [[btn(f"↩️ Przywróć: {x['name']}", f"zwr:{x['uid']}")] for x in former_payload(state)["people"]]
    send(chat_id, "\n".join(lines) + ("\n\nZmienić etat albo usunąć — przyciskiem poniżej." if rows else ""),
         ikb(rows) if rows else None)
    admins = sorted(admin_ids(state))
    me = [] if chat_id in state["employees"] else [[btn("🙋 Ja też pracuję (dodaj mnie jako pracownika)", "selfemp")]]
    send(chat_id, "Kierownicy: " + ", ".join(admin_name(state, a) + (" (Ty)" if a == chat_id else "") for a in admins),
         ikb([[btn("🔗 Link dla pracowników", "emplink")]] + me + [[btn("👔 Dodaj kierownika (link)", "invadm")]] +
             [[btn(f"🗑 Usuń kierownika: {admin_name(state, a)}", f"rmadm:{a}")] for a in admins if a != chat_id]))


def emp_menu(state, chat_id, msg, uid):
    e = state["employees"].get(uid)
    if not e:
        edit(chat_id, msg["message_id"], "Pracownik został już usunięty.")
        return
    kb = etat_kb("ets", uid)
    note, rows = hist_note(state, uid)
    kb["inline_keyboard"] += rows
    kb["inline_keyboard"].append([btn(f"🩸 Honorowy dawca krwi: {'tak ✅' if e.get('donor') else 'nie'}", f"dnr:{uid}")])
    kb["inline_keyboard"].append([btn("🚪 Zwolnij pracownika", f"zw:{uid}")])
    edit(chat_id, msg["message_id"], f"{e['name']}, teraz: {ETATS[etat_for(state, uid, state.get('cur') or next_ym(dt.date.today()))][0]}." + (f"\n{note}" if note else "") + "\nNowy etat:", kb)


def set_etat(state, chat_id, msg, uid, key):
    e = state["employees"].get(uid)
    if not e or key not in ETATS:
        return
    # ставка меняется не задним числом: выбираем, с какого месяца и на сколько
    cur = state.get("cur") or next_ym(dt.date.today())
    y, m = ym_parts(cur)
    nxt = next_ym(dt.date(y, m, 1))
    title = lambda ym: month_title(ym)
    rows = [[btn(f"Na stałe od: {title(cur)}", f"etp:{uid}:{key}:{cur}:-")],
            [btn(f"Na stałe od: {title(nxt)}", f"etp:{uid}:{key}:{nxt}:-")],
            [btn(f"Tylko: {title(cur)}", f"etp:{uid}:{key}:{cur}:{cur}")],
            [btn(f"Okres: {title(cur)} – {title(nxt)}", f"etp:{uid}:{key}:{cur}:{nxt}")]]
    edit(chat_id, msg["message_id"], f"{e['name']}: {ETATS[key][0]}. Od kiedy? Inne miesiące wybierzesz w «Grafik» → ✏️ Edytuj pracownika.", ikb(rows))


def etat_pick(state, chat_id, msg, uid, key, frm, to):
    err = etat_period_add(state, uid, key, frm, None if to == "-" else to)
    e = state["employees"].get(uid) or {}
    edit(chat_id, msg["message_id"], err or f"{e.get('name')}: {etat_period_text(e['etat_periods'][-1])}.\nGrafik już ułożony sam się nie zmieni: ułóż go od nowa, jeśli trzeba.")


def remove_emp(state, chat_id, msg, uid, sure):
    e = state["employees"].get(uid)
    if not e:
        edit(chat_id, msg["message_id"], "Już usunięty(a).")
        return
    if not sure:   # старые кнопки «Usuń» ведут к увольнению с датой: так ничего не теряется
        exit_menu(state, chat_id, msg, uid)
        return
    del state["employees"][uid]
    for month in state["months"].values():
        for day in (month["schedule"] or {}).values():
            day.pop(uid, None)
    save_state(state)
    edit(chat_id, msg["message_id"], f"{e['name']} usunięty(a).")


# ---------- редактор графика (браузер и Telegram Mini App) ----------
# HTTP-сервер в том же процессе, что и бот, слушает только 127.0.0.1:WEB_PORT.
# Если рядом лежит cloudflared.exe, бот поднимает временный туннель *.trycloudflare.com
# и ставит директору кнопку меню «Grafik» (Mini App). Через туннель API пускает только
# с подписанным Telegram initData директора; на этом компьютере — с localhost без подписи.

WEB_URL = ""          # публичный https-адрес туннеля, меняется при каждом запуске
WEB_TOKENS = {}       # токен -> (uid директора, срок): вход в редактор из обычного браузера
TUNNEL_PID_FILE = os.path.join(BASE, "tunnel.pid")


def web_button(chat_id, text):
    if WEB_URL:
        send(chat_id, text, ikb([[{"text": "🗓 Otwórz grafik", "web_app": {"url": WEB_URL}}]]))


def web_link(state, chat_id):
    if WEB_URL:
        web_button(chat_id, "Edytor grafiku: wybierz pracownika i zobacz, na które dni można go postawić albo "
                            "przenieść. Ten sam edytor jest pod przyciskiem «Grafik» obok pola wiadomości.")
    else:
        send(chat_id, f"Edytor grafiku działa na komputerze, na którym jest uruchomiony bot. "
                      f"Otwórz tam w przeglądarce: http://localhost:{WEB_PORT}", DIR_KB)


def set_menu_button(chat_id):
    if not WEB_URL or str(chat_id).startswith("man"):
        return
    try:
        tg("setChatMenuButton", chat_id=chat_id,
           menu_button={"type": "web_app", "text": "Grafik", "web_app": {"url": WEB_URL}})
    except Exception as e:  # noqa: BLE001
        log(f"setChatMenuButton {chat_id} failed: {e}")


def set_menu_all(state):
    """Кнопка «Grafik» директорам и (в рабочем режиме) всем подтверждённым сотрудникам."""
    for a in admin_ids(state):
        set_menu_button(a)
    if state.get("mode") == "prod":
        for u in active(state):
            if not u.startswith("test") and u not in admin_ids(state):
                set_menu_button(u)


def check_init_data(init):
    """Проверка подписи Telegram WebApp initData. Возвращает id пользователя или None."""
    try:
        pairs = dict(urllib.parse.parse_qsl(init, keep_blank_values=True, strict_parsing=True))
    except ValueError:
        return None
    got = pairs.pop("hash", "")
    check = "\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))
    secret = hmac.new(b"WebAppData", TOKEN.encode(), hashlib.sha256).digest()
    if not got or not hmac.compare_digest(hmac.new(secret, check.encode(), hashlib.sha256).hexdigest(), got):
        return None
    try:
        if time.time() - int(pairs.get("auth_date", "0")) > 86400:
            return None
        return str(json.loads(pairs.get("user", "{}"))["id"])
    except (ValueError, KeyError, TypeError):
        return None


def unreg_emps(state, month):
    """Люди из импортированного графика, ещё не зарегистрированные: показываем, но править нельзя."""
    now = active_in(state, month["ym"])
    keys = sorted({u for part in ("schedule", "leave") for day in (month.get(part) or {}).values() for u in day
                   if u.startswith("name:") or u not in now})
    names = hist_unlinked(state)
    return [{"uid": u, "name": names.get(u) or ename(state, u), "etat": "niezarejestrowany(-a)" if u.startswith("name:") else "zwolniony(-a)", "unreg": True, "target": None,
             "ktarget": None, "hours": hours_of(month, u), "answered": True, "cap": None, "asked": None, "test": False,
             "auto": False, "no_room": False, "avail": {}, "sched": {d: day[u] for d, day in month["schedule"].items() if u in day},
             "leave": {d: day[u] for d, day in month_leave(month).items() if u in day},
             "ksched": {}, "khours": 0, "kallow": {}, "kviol": [], "kprev": [], "kprev_r2": False} for u in keys]


def web_payload(state):
    month = cur_month(state)
    if not month:
        return {"month": None, "vacations": vac_payload(state)}
    ym = month["ym"]
    n = ndays(ym)
    hol = holidays_pl(ym_parts(ym)[0])
    sched = month["schedule"] or {}
    days = []
    for d in range(1, n + 1):
        day = date_of(ym, d)
        need, cov = need_for(ym, d), coverage(month, d)
        days.append({"d": d, "wd": DAYS[day.weekday()], "off": day.weekday() >= 5 or day in hol,
                     "closed": is_closed(ym, d), "day_min": (DAY_NEED.get(ym) or {}).get(str(d)),
                     "need": [need[p] for p in PERIODS], "cov": [cov[p] for p in PERIODS]})
    emps = []
    for u, e in active_in(state, ym).items():
        emps.append({"uid": u, "name": e["name"], "exit": e.get("exit"), "etat": ETATS.get(etat_for(state, u, ym), ETATS["1"])[0],
                     "donor": bool(e.get("donor")), "blood": sorted(blood_picks(month, u)), "blood_days": blood_days(month, u),
                     "etat_key": etat_for(state, u, ym), "avail_line": avail_line(state, month, u) if u in month["done"] else None, "etat_base": ETATS.get(e.get("etat", "1"), ETATS["1"])[0],
                     "etat_periods": [{**p, "text": etat_period_text(p)} for p in e.get("etat_periods") or []],
                     "target": grafik_hours(state, u, ym), "ktarget": target_hours(state, u, ym), "hours": hours_of(month, u),
                     "answered": u in month["done"], "cap": avail_hours(month, u),
                     "asked": month.get("asked", {}).get(u), "test": u.startswith("test"),
                     "auto": bool(month["avail"].get(u, {}).get("auto")), "no_room": no_room(state, month, u),
                     "avail": {str(d): options(month, u, d) for d in range(1, n + 1) if options(month, u, d)},
                     "leave": {d: day[u] for d, day in month_leave(month).items() if u in day},
                     "extra": extra_info(state, u),
                     "sched": {d: day[u] for d, day in sched.items() if u in day}})
    emps.sort(key=lambda e: (e["test"], e["name"].lower()))   # настоящие сотрудники первыми, тестовые после
    kinfo, kemps = kadry_payload(state, month)
    for e in emps:
        e.update(kemps[e["uid"]])
    if kinfo["kcov"]:
        for i, d in enumerate(days):
            d["kcov"] = kinfo["kcov"][i]
    kinfo.pop("kcov")
    emps += unreg_emps(state, month)
    shifts = {c: {"name": s["name"], "time": s["time"], "hours": s["hours"],
                  "covers": [PERIODS.index(p) for p in s["covers"]]} for c, s in SHIFTS.items()}
    shifts.update(dyn_shifts(month["schedule"]))
    return {"month": {"ym": ym, "title": month_title(ym), "published": month["published"],
                      "imported": bool(month.get("imported")), "import_sent": bool(month.get("import_sent")),
                      "built": month["schedule"] is not None, "auto_day": AUTO_FILL_DAY,
                      "auto_applied": bool(month.get("auto_applied"))},
            "shifts": shifts, "days": days, "emps": emps, "kadry": kinfo, "history": history_list(state),
            "over": over_suggestions(state, month), "max_per_shift": max_for(month["ym"]), "mode": state.get("mode", "prod"),
            "links": links_payload(state), "closed_cal": closed_calendar(state, ym), "former": former_payload(state), "undo": undo_payload(month),
            "staffing": {"timeline": [x for x in state["staffing"]], "cur": staffing_for(ym)},
            "collect": collect_payload(state), "vacations": vac_payload(state), **calls_payload(state, month)}


def collect_payload(state):
    """Статус сбора диспозиций для «Grafik»: на какой месяц, срок, сколько прислали."""
    if state.get("mode") != "prod":
        return None
    m = collect_month(state)
    if not m:
        nxt, opens = upcoming_open(dt.date.today())
        return {"open": False, "next": month_title(nxt), "opens": f"{opens:%d.%m}"}
    emps = [u for u in active(state) if u != DEMO_UID]
    return {"open": True, "ym": m["ym"], "title": month_title(m["ym"]), "deadline": f"{deadline_of(m['ym']):%d.%m}",
            "manual": bool(m.get("manual_close")), "done": sum(1 for u in emps if u in m["done"]), "total": len(emps)}


def extra_reason(state, month, me, d, code):
    """Почему сотрудник не может попроситься на эту смену (None — может)."""
    if is_closed(month["ym"], d):
        return "basen jest tego dnia zamknięty"
    if d in blood_days(month, me):
        return "tego dnia masz wolne: oddajesz krew"
    if month_leave(month).get(str(d), {}).get(me) == "U":
        return "tego dnia masz urlop"
    if me in month["schedule"][str(d)]:
        return "tego dnia już pracujesz"
    if any(r["uid"] == me and r["day"] == d and r["status"] == "pending" for r in month.get("requests", [])):
        return "⏳ prośba wysłana, czeka na kierownika"
    y, m = ym_parts(month["ym"])
    tl = emp_timeline(state, month, me)
    tl[dt.date(y, m, d)] = code
    for a in (dt.date(y, m, d) - DAY, dt.date(y, m, d)):
        r = rest_between(tl, a)
        if r is not None and r < DAILY_REST_H:
            return f"tylko {r:g} h odpoczynku między zmianami (wymagane {DAILY_REST_H} h)"
    return None


def emp_payload(state, me, preview=False):
    """«Grafik» для сотрудника: только просмотр опубликованного графика + свои часы и просьбы о доп. сменах.
    Чужие часы, ставки, диспозиции, причины отсутствия и график для кадр сюда не попадают."""
    if (state.get("mode") == "test" and not preview and not me.startswith("test")
            and me not in admin_ids(state)):
        return {"month": None, "role": "emp", "note": "Bot jest jeszcze przygotowywany. Grafik zobaczysz po uruchomieniu.",
                "myvac": vac_payload(state, me), "me": me, "preview": preview}
    month = published_month(state)
    if not month:
        return {"month": None, "role": "emp", "note": "Grafik nie jest jeszcze opublikowany.",
                "myvac": vac_payload(state, me), "me": me, "preview": preview}
    ym = month["ym"]
    hol = holidays_pl(ym_parts(ym)[0])
    days = []
    for d in range(1, ndays(ym) + 1):
        day, need, cov = date_of(ym, d), need_for(ym, d), coverage(month, d)
        bal = {p: cov[p] - need[p] for p in PERIODS}
        # смены с нехваткой: можно ли этому сотруднику попроситься (или почему нет)
        req = {c: extra_reason(state, month, me, d, c) for c in CODES
               if all(bal[p] < 0 for p in SHIFTS[c]["covers"])}
        days.append({"d": d, "wd": DAYS[day.weekday()], "off": day.weekday() >= 5 or day in hol,
                     "closed": is_closed(ym, d), "need": [need[p] for p in PERIODS], "cov": [cov[p] for p in PERIODS],
                     "req": req})
    emps = []
    for u, e in active(state).items():
        if u == DEMO_UID:
            continue
        mine = {d: day[u] for d, day in month["schedule"].items() if u in day}
        x = {"uid": u, "name": e["name"], "etat": "", "sched": mine, "avail": {}, "answered": True, "auto": False,
             "cap": None, "asked": None, "test": u.startswith("test"), "kviol": [], "kprev": [],
             "hours": hours_of(month, u) if u == me else 0, "target": grafik_hours(state, u, ym) if u == me else None,
             # свои отсутствия целиком; у коллег виден только urlop (U), причины других отсутствий — нет
             "leave": {d: day[u] for d, day in month_leave(month).items() if u in day and (u == me or day[u] == "U")},
             "myextra": {"hours": extra_info(state, u)["hours"]} if u == me else None}
        emps.append(x)
    emps += [{**x, "etat": "", "hours": 0, "leave": {}} for x in unreg_emps(state, month)]
    emps.sort(key=lambda e: (e["uid"] != me, e["test"], e["name"].lower()))
    shifts = {c: {"name": s["name"], "time": s["time"], "hours": s["hours"],
                  "covers": [PERIODS.index(p) for p in s["covers"]]} for c, s in SHIFTS.items()}
    shifts.update(dyn_shifts(month["schedule"]))
    reqs = [{"d": r["day"], "code": r["code"], "status": r["status"]} for r in month.get("requests", []) if r["uid"] == me]
    calls = [{"id": c["id"], "d": c["d"], "code": c["code"], "answered": me in c["yes"] or me in c["no"],
              "yes": me in c["yes"]} for c in month.get("calls", []) if c["status"] == "open" and me in c["asked"]]
    return {"role": "emp", "me": me, "preview": preview, "month": {"ym": ym, "title": month_title(ym),
                                                                   "published": True, "built": True},
            "shifts": shifts, "days": days, "emps": emps, "myreq": reqs, "mycalls": calls, "myvac": vac_payload(state, me),
            "max_per_shift": max_for(month["ym"]), "mode": state.get("mode", "prod")}


def web_extra(state, uid, d, code):
    """Сотрудник из «Grafik» просится на доп. смену там, где не хватает людей."""
    month = published_month(state)
    if not month or code not in CODES or not 1 <= d <= ndays(month["ym"]):
        return "Grafik nie jest opublikowany."
    if uid in month["schedule"][str(d)]:
        return "Tego dnia już pracujesz."
    bal = balance(month, d)
    if not all(bal[p] < 0 for p in SHIFTS[code]["covers"]):
        return "Na tej zmianie nie brakuje już ludzi."
    why = extra_reason(state, month, uid, d, code)
    if why:
        return f"Nie można: {why}."
    rid = state["next_req"]
    state["next_req"] += 1
    month["requests"].append({"id": rid, "uid": uid, "day": d, "code": code, "status": "pending"})
    save_state(state)
    ym = month["ym"]
    what = f"{dlabel(ym, d)}, {sh_text(code)}"
    th = grafik_hours(state, uid, ym)
    hrs = f"{hours_of(month, uid):g}" + (f" z {th}" if th is not None else "") + " h"
    warn = replacement_warnings(state, month, uid, d, code)
    for a in admin_ids(state):
        send(a, f"🙋 {ename(state, uid)} zgłasza się na dodatkową zmianę: {what}. Teraz ma {hrs}. (z aplikacji «Grafik»)"
                + ("\n⚠️ " + "\n⚠️ ".join(warn) if warn else ""),
             ikb([[btn("✅ Zatwierdź", f"xa:{rid}"), btn("❌ Odrzuć", f"xn:{rid}")]]))
    log(f"Dodatkowa zmiana z aplikacji: {ename(state, uid)} {what}")
    return None


def web_check(state, uid, d):
    month = cur_month(state)
    if not month:
        return None, "Nie ma bieżącego miesiąca."
    if uid not in active(state):
        return None, "Nie ma takiego pracownika."
    if not 1 <= d <= ndays(month["ym"]):
        return None, "Nie ma takiego dnia."
    if month["schedule"] is None:
        month["schedule"] = {str(x): {} for x in range(1, ndays(month["ym"]) + 1)}
    return month, None


def web_set(state, uid, d, code):
    month, err = web_check(state, uid, d)
    if err:
        return err
    if code is not None and code not in CODES:
        return "Nie ma takiej zmiany."
    if code and is_closed(month["ym"], d):
        return "Tego dnia basen jest zamknięty. Najpierw otwórz dzień."
    if code and d in blood_days(month, uid):
        return "Tego dnia ta osoba oddaje krew (dzień wolny)."
    if code and is_gone(month["ym"], d, uid):
        return "Ta osoba już wtedy nie pracuje."
    if code and uid in month_leave(month).get(str(d), {}):
        return "Tego dnia ta osoba ma urlop lub zwolnienie."
    ym, day = month["ym"], month["schedule"][str(d)]
    old = day.get(uid)
    if code:
        day[uid] = code
    else:
        day.pop(uid, None)
    save_state(state)
    if old != code:
        if code and old:
            text = f"{dlabel(ym, d)} — teraz {sh_text(code)}."
        elif code:
            text = f"dodana zmiana {dlabel(ym, d)}, {sh_text(code)}."
        else:
            text = f"{dlabel(ym, d)} — zmiana usunięta."
        notify_change(state, month, uid, text)
    return None


def web_move(state, uid, d, d2, code=None):
    month, err = web_check(state, uid, d)
    if not err and not 1 <= d2 <= ndays(month["ym"]):
        err = "Nie ma takiego dnia."
    if err:
        return err
    ym, sched = month["ym"], month["schedule"]
    if uid not in sched[str(d)]:
        return "Ta osoba nie pracuje tego dnia."
    if uid in sched[str(d2)]:
        return "Tego dnia ta osoba już pracuje."
    if code is not None and code not in CODES:
        return "Nie ma takiej zmiany."
    if is_closed(ym, d2):
        return "Tego dnia basen jest zamknięty."
    if d2 in blood_days(month, uid):
        return "Tego dnia ta osoba oddaje krew (dzień wolny)."
    if is_gone(ym, d2, uid):
        return "Ta osoba już wtedy nie pracuje."
    if uid in month_leave(month).get(str(d2), {}):
        return "Tego dnia ta osoba ma urlop lub zwolnienie."
    old = sched[str(d)].pop(uid)
    opts = options(month, uid, d2)
    c = code or (old if old in opts or not opts else max(opts, key=lambda x: shift_score(month, d2, x)))
    sched[str(d2)][uid] = c
    save_state(state)
    notify_change(state, month, uid, f"zmiana z {dlabel(ym, d)} przeniesiona na {dlabel(ym, d2)}, {sh_text(c)}.")
    return None


def web_ask(state, uid):
    """Просьба сотруднику дослать/дополнить диспозицию до ставки (кнопка в редакторе)."""
    month = cur_month(state)
    if not month or uid not in active(state):
        return "Nie ma takiego pracownika."
    if month["published"]:
        return "Grafik jest już opublikowany, dyspozycje są zamknięte."
    ym, title = month["ym"], month_title(month["ym"])
    t, cap = grafik_hours(state, uid, ym), avail_hours(month, uid)
    if not needs_more(state, month, uid):
        return "Dyspozycja tej osoby wystarcza do etatu."
    if uid not in month["done"]:
        text = f"Przypomnienie od kierownika: prześlij proszę dyspozycję na {title}."
    else:
        short = [dlabel(ym, d) for d in range(1, ndays(ym) + 1)
                 if any(v < 0 for v in balance(month, d).values())][:6]
        text = (f"Kierownik prosi o uzupełnienie dyspozycji na {title}: zaznaczone dni dają maks. {cap:g} h, "
                f"a Twój etat to {t} h, brakuje {t - cap:g} h. Dodaj proszę dni lub zmiany"
                + (f", najlepiej tam, gdzie brakuje ludzi: {', '.join(short)}" if short else "") + ".")
    if not can_edit_avail(state, month, uid):   # сбор уже закрыт — открываем повторно только для этого человека
        month.setdefault("reopen", []).append(uid)
    send(uid, text, EMP_KB)
    ask_avail(state, uid, month)
    month.setdefault("asked", {})[uid] = {"at": time.strftime("%H:%M"), "answered": False}
    save_state(state)
    log(f"Prośba o dyspozycję wysłana: {ename(state, uid)}")
    if uid.startswith("test") and uid != DEMO_UID and month.get("test_silent") != uid:
        simulate_test_more(state, uid, ym)
    return None


def needs_more(state, month, uid):
    """Нет диспозиции или она не добирает до ставки."""
    if uid not in month["done"]:
        return True
    t, cap = grafik_hours(state, uid, month["ym"]), avail_hours(month, uid)
    return t is not None and cap is not None and cap < t


def web_autofill(state):
    month = cur_month(state)
    if not month:
        return "Nie ma bieżącego miesiąca."
    if month["published"]:
        return "Grafik jest już opublikowany."
    filled = auto_fill(state, month)
    if not filled:
        return "Wszyscy przysłali dyspozycje."
    build_schedule(state, month)
    log(f"Auto-dyspozycja z edytora: {', '.join(ename(state, u) for u in filled)}")
    return None


def simulate_test_more(state, uid, ym):
    """Тестовый сотрудник через 5–10 с «добавляет» дни (сначала там, где не хватает людей)."""
    import random

    def run():
        time.sleep(random.uniform(5, 10))
        with LOCK:
            month = state["months"].get(ym)
            if not month or month["published"] or state["cur"] != ym or uid not in active(state):
                return
            av = month["avail"].setdefault(uid, {"all": False, "days": {}})
            if av.get("all"):
                return
            t = grafik_hours(state, uid, ym) or month_norm(state, ym)
            days = [d for d in range(1, ndays(ym) + 1) if str(d) not in av["days"]]
            random.shuffle(days)
            days.sort(key=lambda d: not any(v < 0 for v in balance(month, d).values()))
            while avail_hours(month, uid) < t and days:
                av["days"][str(days.pop(0))] = ["R1", "R2"]
            mark_done(state, uid)

    threading.Thread(target=run, daemon=True).start()


def web_build(state):
    month = cur_month(state)
    if not month:
        return "Najpierw zbierz dyspozycje w bocie."
    if month["published"]:
        return "Grafik jest już opublikowany, nie układam go od nowa."
    build_schedule(state, month)
    return None


class WebServer(ThreadingHTTPServer):
    allow_reuse_address = False   # на Windows иначе можно молча занять порт другой программы
    daemon_threads = True


class WebHandler(BaseHTTPRequestHandler):
    state = None

    def log_message(self, *args):
        pass

    def _token_uid(self):
        tok = WEB_TOKENS.get(self.headers.get("X-Token") or "")
        return tok[0] if tok and tok[1] > time.time() else None

    def _requesters(self):
        """Кому слать файлы/сводки: директор, открывший редактор из Telegram, иначе все директора."""
        uid = check_init_data(self.headers.get("X-Init-Data") or "") or self._token_uid()
        return [uid] if uid else sorted(admin_ids(self.state))

    def _employee(self):
        """Сотрудник (не директор), открывший «Grafik» из Telegram: только просмотр и просьба о доп. смене."""
        uid = check_init_data(self.headers.get("X-Init-Data") or "")
        if uid and uid not in admin_ids(self.state) and uid in active(self.state):
            return uid
        return None

    def _authorized(self):
        if self._token_uid() in admin_ids(self.state):
            return True
        init = self.headers.get("X-Init-Data") or ""
        if init:
            return check_init_data(init) in admin_ids(self.state)
        # без подписи — только прямой запрос с этого компьютера, не через туннель
        via_tunnel = any(h in self.headers for h in ("Cf-Ray", "Cf-Connecting-IP"))
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0]
        return not via_tunnel and host in ("localhost", "127.0.0.1")

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False))

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/":
            with open(WEB_PAGE_FILE, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        elif path == "/api/state":
            emp = None if self._authorized() else self._employee()
            if not emp and not self._authorized():
                return self._json({"error": "Brak dostępu."}, 403)
            as_uid = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("as", [""])[0]
            with LOCK:
                if emp:
                    payload = emp_payload(self.state, emp)
                elif as_uid and as_uid in active(self.state):   # директор: «👁 Podgląd jako pracownik»
                    payload = emp_payload(self.state, as_uid, preview=True)
                else:
                    payload = web_payload(self.state)
                    if self.state.get("update_available"):   # плашка «есть новая версия» в редакторе
                        payload["update"] = dict(self.state["update_available"],
                                                 owner=any(can_update(self.state, u) for u in self._requesters()[:1]))
                self._json({"state": payload})
        elif path == "/api/history":
            if not self._authorized():
                return self._json({"error": "Brak dostępu."}, 403)
            ym = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("ym", [""])[0]
            with LOCK:
                h = history_payload(self.state, ym)
            self._json({"history": h} if h else {"error": "Nie ma tego miesiąca w historii."})
        else:
            self._send(404, "not found", "text/plain")

    def do_POST(self):
        path = self.path.split("?")[0]
        try:   # тело читаем всегда, даже если откажем: иначе Windows рвёт соединение
            raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        except (ValueError, OSError):
            raw = b""
        emp = None if self._authorized() else self._employee()
        if self.headers.get("X-Pool") == "1" and emp and path in ("/api/extra", "/api/callanswer", "/api/ticket/start",
                                                                   "/api/vacation", "/api/vacation/cancel"):
            try:   # сотрудник: только своя просьба о доп. смене, ответ на «zastępstwo» и заявка о проблеме
                data = json.loads(raw or b"{}")
                with LOCK:
                    if path == "/api/extra":
                        err = web_extra(self.state, emp, int(data["d"]), str(data["code"]))
                    elif path == "/api/callanswer":
                        _, c = find_call(self.state, int(data["cid"]))
                        err = None if c and emp in c["asked"] else "To jest już nieaktualne."
                        if not err:
                            call_answer(self.state, emp, None, c["id"], bool(data.get("yes")))
                    elif path == "/api/vacation":   # wniosek o urlop: daty od–do z kalendarza
                        _, err = vac_create(self.state, emp, dt.date.fromisoformat(str(data["from"])),
                                            dt.date.fromisoformat(str(data["to"])), str(data.get("note") or ""))
                    elif path == "/api/vacation/cancel":
                        err = vac_cancel(self.state, emp, int(data["id"]))
                    else:
                        ticket_start(self.state, emp)
                        err = None
                    return self._json({"error": err, "state": emp_payload(self.state, emp)})
            except (ValueError, TypeError, KeyError) as e:
                return self._json({"error": f"Błędne zapytanie: {e}"}, 400)
        if self.headers.get("X-Pool") != "1" or not self._authorized():
            return self._json({"error": "Brak dostępu."}, 403)
        if path == "/api/update":   # кнопка «🔄 Aktualizuj» в редакторе: директор или владелец, ставим в фоне
            who = self._requesters()[0] if self._requesters() else ""
            if not can_update(self.state, who):
                return self._json({"error": "Aktualizację może zainstalować tylko kierownik lub właściciel bota."})
            threading.Thread(target=lambda: update_from_net(self.state, who), daemon=True).start()
            return self._json({"error": None, "ok": True})
        try:
            data = json.loads(raw or b"{}")
            with LOCK:
                undo = undo_begin(self.state, path, data)
                if path == "/api/set":
                    err = web_set(self.state, str(data["uid"]), int(data["d"]), data.get("code"))
                elif path == "/api/move":
                    err = web_move(self.state, str(data["uid"]), int(data["d"]), int(data["d2"]), data.get("code"))
                elif path == "/api/publish":
                    err = web_publish(self.state, self._requesters())
                elif path == "/api/kadry/build":
                    month = cur_month(self.state)
                    err = None if month else "Nie ma bieżącego miesiąca."
                    if month and prev_required(self.state, month) and not data.get("force"):
                        err = (f"Najpierw wgraj grafik dla kadr za {month_title(prev_ym(month['ym']))} "
                               "(albo ułóż bez poprzedniego miesiąca).")
                    elif month:
                        build_kadry(self.state, month)
                elif path == "/api/kadry/prevr2":
                    month = cur_month(self.state)
                    uid = str(data["uid"])
                    lst = kadry_of(month).setdefault("prev_r2", []) if month else []
                    if data.get("on") and uid not in lst:
                        lst.append(uid)
                    elif not data.get("on") and uid in lst:
                        lst.remove(uid)
                    save_state(self.state)
                    err = None
                elif path == "/api/kadry/set":
                    err = kadry_set(self.state, str(data["uid"]), int(data["d"]), data.get("code"))
                elif path == "/api/kadry/move":
                    err = kadry_move(self.state, str(data["uid"]), int(data["d"]), int(data["d2"]), data.get("code"))
                elif path == "/api/kadry/level":
                    month = cur_month(self.state)
                    err = kadry_level(self.state, month, str(data["uid"])) if month else "Nie ma bieżącego miesiąca."
                elif path == "/api/kadry/prevsun":
                    err = kadry_prev_sunday(self.state, str(data["uid"]), str(data["date"]), bool(data.get("worked")))
                elif path == "/api/kadry/export":
                    err = kadry_export(self.state, self._requesters())
                elif path == "/api/token":
                    # одноразовая ссылка «открыть в браузере»: токен живёт 12 ч и только в памяти бота
                    uid = check_init_data(self.headers.get("X-Init-Data") or "") or self._token_uid()
                    tok = uuid.uuid4().hex
                    WEB_TOKENS[tok] = (uid, time.time() + 12 * 3600)
                    return self._json({"token": tok})
                elif path == "/api/call":
                    err = web_call(self.state, int(data["d"]), str(data.get("code") or "R1"),
                                   str(data.get("scope") or "all"), data.get("absent_uid"),
                                   str(data.get("reason") or ""), bool(data.get("auto")))
                elif path == "/api/launch/ask":
                    # кнопка в «Grafik»: подтверждение запуска приходит в чат с ботом
                    err = None if self.state.get("mode") == "test" else "Bot już działa w trybie pracy."
                    if not err:
                        for c in self._requesters()[:1]:
                            launch_confirm(self.state, c)
                elif path == "/api/collect/close":
                    m = collect_month(self.state)
                    err = None if (self.state.get("mode") == "prod" and m and not m.get("collect_closed")) \
                        else "Teraz nie ma otwartego zbierania."
                    if not err:
                        close_collection(self.state, m, by=(self._requesters() or ["web"])[0])
                elif path == "/api/call/preview":
                    return self._json(call_preview(self.state, int(data["d"]), str(data.get("code") or "R1"),
                                                   data.get("absent_uid")))
                elif path == "/api/ticket/start":
                    for c in self._requesters()[:1]:
                        ticket_start(self.state, c)
                    err = None
                elif path == "/api/over/apply":
                    err = apply_over_action(self.state, str(data["uid"]), int(data["d"]), dict(data["action"]))
                elif path == "/api/over/all":
                    err = fix_over_all(self.state)
                elif path == "/api/history/excel":
                    err = history_excel(self.state, str(data["ym"]), self._requesters())
                elif path == "/api/history/link":
                    err = hist_link(self.state, str(data["uid"]), data.get("key") or None)
                elif path == "/api/emp/etat":
                    err = etat_period_add(self.state, str(data["uid"]), str(data["etat"]), str(data["from"]), data.get("to") or None)
                elif path == "/api/emp/etat/del":
                    err = etat_period_del(self.state, str(data["uid"]), int(data["i"]))
                elif path == "/api/staffing":
                    err = staffing_set(self.state, str(data["from"]), data["rano"], data["pop"], data["max"])
                elif path == "/api/staffing/del":
                    err = staffing_del(self.state, str(data["from"]))
                elif path == "/api/staffing/day":
                    err = day_need_set(self.state, str(data["ym"]), int(data["d"]), data.get("n"))
                elif path == "/api/emp/exit/preview":
                    return self._json(exit_preview(self.state, str(data["uid"]), str(data["date"])))
                elif path == "/api/emp/exit":
                    err = emp_exit(self.state, str(data["uid"]), str(data["date"]), bool(data.get("drop")))
                elif path == "/api/emp/restore":
                    err = emp_restore(self.state, str(data["uid"]))
                elif path == "/api/vacation/decide":
                    _, err = vac_decide(self.state, (self._requesters() or [""])[0], int(data["id"]), bool(data.get("ok")))
                elif path == "/api/emp/add":
                    err = emp_add(self.state, data.get("name"), str(data.get("etat") or "1"))
                elif path == "/api/history/hide":
                    err = hist_hide(self.state, str(data["key"]), bool(data.get("hide", True)))
                elif path == "/api/emp/donor":
                    err = set_donor(self.state, str(data["uid"]), bool(data.get("on")))
                elif path == "/api/emp/name":
                    err = emp_rename(self.state, str(data["uid"]), data.get("name"))
                elif path == "/api/overtime/sent":
                    err = extra_sent(self.state, str(data["uid"]), data["n"])
                elif path == "/api/overtime/undo":
                    err = extra_undo(self.state, str(data["uid"]))
                elif path == "/api/overtime/start":
                    err = extra_start(self.state, str(data["uid"]), data["shifts"])
                elif path == "/api/import/send":
                    err = import_send(self.state, (self._requesters() or [owner_id(self.state)])[0], str(data["ym"]))
                elif path == "/api/closed":
                    err = set_closed(self.state, str(data["ym"]), int(data["d"]), bool(data.get("closed")),
                                     bool(data.get("rebuild")))
                elif path == "/api/kadry/norm":
                    month = cur_month(self.state)
                    err = set_norm(self.state, month["ym"], data.get("hours")) if month else "Nie ma bieżącego miesiąca."
                elif path == "/api/history/template":
                    err = import_template(self.state, self._requesters())
                elif path == "/api/autofill":
                    err = web_autofill(self.state)
                elif path == "/api/ask":
                    err = web_ask(self.state, str(data["uid"]))
                elif path == "/api/build":
                    err = web_build(self.state)
                elif path == "/api/undo":
                    err = undo_step(self.state, str(data.get("kind")), bool(data.get("redo")))
                elif path == "/api/undo/gen":
                    err = undo_to_gen(self.state, str(data.get("kind")))
                else:
                    return self._send(404, "not found", "text/plain")
                undo_end(self.state, undo, err)
                self._json({"error": err, "state": web_payload(self.state)})
        except (ValueError, TypeError, KeyError) as e:
            self._json({"error": f"Błędne zapytanie: {e}"}, 400)


def start_web(state):
    try:
        srv = WebServer(("127.0.0.1", WEB_PORT), WebHandler)
    except OSError as e:
        log(f"Edytor grafiku nie wystartował (port {WEB_PORT}): {e}")
        return
    WebHandler.state = state
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log(f"Edytor grafiku: http://localhost:{WEB_PORT}")
    start_tunnel(state)


TUNNEL_URL_FILE = os.path.join(BASE, "tunnel.url")


def old_tunnel_pid():
    """PID cloudflared от прошлого запуска бота, если он ещё жив."""
    try:
        with open(TUNNEL_PID_FILE) as f:
            pid = int(f.read().strip())
    except (OSError, ValueError):
        return None
    out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                         capture_output=True).stdout or b""
    return pid if b"cloudflared" in out.lower() else None


def kill_old_tunnel():
    pid = old_tunnel_pid()
    if pid:
        subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True)


def url_reachable(url):
    try:
        with urllib.request.urlopen(url + "/", timeout=15) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def tunnel_watch(state):
    """Быстрый туннель cloudflared может пропасть после сна или обрыва сети, хотя процесс жив: адрес перестаёт
    существовать. Раз в 5 минут проверяем адрес; если интернет есть, а адрес дважды подряд не отвечает — новый туннель,
    и кнопка «Grafik» у всех обновляется сама."""
    fails = 0
    while True:
        time.sleep(300)
        if not WEB_URL or url_reachable(WEB_URL):
            fails = 0
            continue
        if not url_reachable("https://api.telegram.org"):
            continue   # нет интернета вообще — ждём
        fails += 1
        if fails >= 2:
            fails = 0
            log(f"Tunel nie odpowiada ({WEB_URL}), uruchamiam nowy")
            restart_tunnel(state)


def restart_tunnel(state):
    global WEB_URL
    WEB_URL = ""
    start_tunnel(state)


def start_tunnel(state):
    global WEB_URL
    exe = os.path.join(BASE, "cloudflared.exe")
    if not os.path.exists(exe):
        exe = shutil.which("cloudflared")
    if not exe or ENV.get("TUNNEL", "1") == "0":
        log("Tunel: brak cloudflared, edytor działa tylko na tym komputerze")
        return
    # туннель переживает перезапуск бота: тот же адрес, открытое приложение не теряет связь
    try:
        with open(TUNNEL_URL_FILE) as f:
            old_url = f.read().strip()
    except OSError:
        old_url = ""
    if old_url and old_tunnel_pid() and url_reachable(old_url):
        WEB_URL = old_url
        log(f"Tunel (ten sam adres): {WEB_URL}")
        set_menu_all(state)
        return
    kill_old_tunnel()
    proc = subprocess.Popen([exe, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{WEB_PORT}"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True,
                            encoding="utf-8", errors="replace",
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    with open(TUNNEL_PID_FILE, "w") as f:
        f.write(str(proc.pid))

    def read_output():
        global WEB_URL
        for line in proc.stderr:
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
            if m and not WEB_URL:
                WEB_URL = m.group(0)
                with open(TUNNEL_URL_FILE, "w") as f:
                    f.write(WEB_URL)
                log(f"Tunel: {WEB_URL}")
                with LOCK:
                    set_menu_all(state)
                log("Przycisk «Grafik» ustawiony dla kierownika")
        log("Tunel cloudflared zakończył działanie")

    threading.Thread(target=read_output, daemon=True).start()


WEB_PAGE_FILE = os.path.join(BASE, "editor.html")


# ---------- nieobecność i pilne zastępstwo ----------
# Директор отмечает «🚫 nie przyszedł» (смена снимается, запись в month["absences"]) и/или рассылает
# «🚨 Pilnie potrzebna osoba»: «Wszyscy» или «Tylko wolni» (не работают в этот день и не нарушат 11 ч отдыха).
# Ответ «✅ Mogę» приходит директору карточкой с предупреждениями (11 ч, 35 ч в неделю, воскресенья, ставка);
# можно включить «automatycznie pierwszy». После подтверждения человек ставится в график, у остальных
# кнопки гаснут: «Zastępstwo znalezione». Сотрудник сам может нажать «🤒 Nie mogę przyjść» в «📋 Mój grafik».

ABSENCE_REASONS = {"choroba": "choroba", "l4": "L4", "nz": "urlop na żądanie", "inne": "inne"}


def emp_timeline(state, month, uid, extra=None):
    """{дата: код} по графику сотрудников (+ прошлый месяц) — для проверки отдыха при замене."""
    tl = {}
    pym, psched = prev_source(state, month["ym"])
    if psched:
        py_, pm_ = ym_parts(pym)
        nk = emp_hist_key(state, uid)
        tl.update({dt.date(py_, pm_, int(d)): day.get(uid) or day[nk] for d, day in psched.items()
                   if uid in day or nk in day})
    y, m = ym_parts(month["ym"])
    tl.update({dt.date(y, m, int(d)): day[uid] for d, day in month["schedule"].items() if uid in day})
    if extra:
        tl[extra[0]] = extra[1]
    return tl


def replacement_warnings(state, month, uid, d, code):
    """Что нарушит выход uid на смену code в день d: отдых 11 ч, 35 ч в неделю, 4-е воскресенье, ставка."""
    y, m = ym_parts(month["ym"])
    day = dt.date(y, m, d)
    tl = emp_timeline(state, month, uid)
    warn = []
    if code == "R3":
        warn.append("16 h w jednym dniu")
    reason = place_reason(month, tl, set(), day, code if code in KADRY_CODES else "R1")
    if reason and "tylko zmiany R1 i R2" not in reason:
        warn.append(reason)
    t = grafik_hours(state, uid, month["ym"])
    if t and hours_of(month, uid) + SHIFTS[code]["hours"] > t:
        warn.append(f"ponad etat: {hours_of(month, uid) + SHIFTS[code]['hours']:g}/{t} h")
    return warn


OTHER_SHIFT = {"R1": "R2", "R2": "R1"}


def extends_shift(month, d, code, uid):
    """Человек уже на другой половине дня (R1 при запросе R2 и наоборот): может остаться на весь день."""
    return OTHER_SHIFT.get(code) is not None and month["schedule"][str(d)].get(uid) == OTHER_SHIFT[code]


def call_targets(state, month, d, code, scope, exclude=None):
    """«all» — все, кто не работает в этот день, и те, кто на другой половине дня (останутся на весь день);
    «free» — только свободные без нарушения 11 ч отдыха."""
    y, m = ym_parts(month["ym"])
    day = month["schedule"][str(d)]
    res = []
    for u in active(state):
        if u in day and not (scope == "all" and extends_shift(month, d, code, u)):
            continue
        if u == DEMO_UID or u == exclude or d in blood_days(month, u) or is_gone(month["ym"], d, u) or u.startswith("man"):
            continue
        if scope == "free":
            tl = emp_timeline(state, month, u)
            tl[dt.date(y, m, d)] = code
            if any((r := rest_between(tl, a)) is not None and r < DAILY_REST_H
                   for a in (dt.date(y, m, d) - DAY, dt.date(y, m, d))):
                continue
        res.append(u)
    return res


def send_get_id(chat_id, text, markup=None):
    """Как send(), но возвращает message_id (чтобы потом погасить кнопки); для тестовых — None."""
    if str(chat_id).startswith("test") and not (str(chat_id) == DEMO_UID and DEMO_CHAT[0]):
        return None
    if ROLES["mode"] == "test" and str(chat_id) in ROLES["real"]:
        return None
    if str(chat_id) == DEMO_UID:
        return send(chat_id, text, markup) and None
    try:
        params = {"chat_id": chat_id, "text": text}
        if markup:
            params["reply_markup"] = markup
        return tg("sendMessage", **params)["result"]["message_id"]
    except Exception as e:  # noqa: BLE001
        log(f"sendMessage {chat_id} failed: {e}")
        return None


def call_preview(state, d, code, absent_uid=None):
    month = cur_month(state)
    if not month or not month["schedule"]:
        return {"all": 0, "free": 0}
    sched_day = month["schedule"][str(d)]
    saved = sched_day.pop(absent_uid, None) if absent_uid else None   # считаем как будто его уже сняли
    try:
        allt = call_targets(state, month, d, code, "all", absent_uid)
        return {"all": len(allt), "free": len(call_targets(state, month, d, code, "free", absent_uid)),
                "other": sum(extends_shift(month, d, code, u) for u in allt)}
    finally:
        if saved:
            sched_day[absent_uid] = saved


def web_call(state, d, code, scope="all", absent_uid=None, reason="", auto=False):
    month = cur_month(state)
    if not month or not month["schedule"]:
        return "Najpierw ułóż grafik."
    if code not in CODES or not 1 <= d <= ndays(month["ym"]):
        return "Błędna zmiana."
    ym = month["ym"]
    if is_closed(ym, d):
        return "Tego dnia basen jest zamknięty."
    if absent_uid:
        absent_uid = str(absent_uid)
        if absent_uid not in state["employees"]:
            return "Ta osoba nie jest jeszcze zarejestrowana."
        old = month["schedule"][str(d)].pop(absent_uid, None)
        if not old:
            return "Ta osoba nie pracuje tego dnia."
        code = old
        month.setdefault("absences", []).append({"uid": absent_uid, "d": d, "code": old,
                                                 "reason": ABSENCE_REASONS.get(reason, reason),
                                                 "at": time.strftime("%Y-%m-%d %H:%M")})
        if month["published"]:
            history_save(state, ym, "emp", month["schedule"])
    if scope == "none":   # только отметить отсутствие, без рассылки
        save_state(state)
        log(f"Nieobecność: {ename(state, absent_uid)} {dlabel(ym, d)}")
        return None
    targets = call_targets(state, month, d, code, scope, absent_uid)
    cid = state.get("next_call", 1)
    state["next_call"] = cid + 1
    why = ABSENCE_REASONS.get(reason, reason)
    call = {"id": cid, "d": d, "code": code, "absent": absent_uid, "reason": why, "status": "open", "auto": auto,
            "asked": targets, "yes": [], "no": [], "msgs": {}, "at": time.strftime("%Y-%m-%d %H:%M")}
    month.setdefault("calls", []).append(call)
    what = f"{dlabel(ym, d)}, {sh_text(code)}"
    for u in targets:
        if extends_shift(month, d, code, u):
            text = (f"🚨 Pilnie potrzebna osoba: {what}" + (f" ({why})" if why else "") +
                    f".\nMasz już {OTHER_SHIFT[code]} tego dnia — czy możesz zostać także na {code} (cały dzień {SHIFTS['R3']['time']})?")
            kb = ikb([[btn("✅ Mogę zostać", f"cally:{cid}"), btn("❌ Nie mogę", f"calln:{cid}")]])
        else:
            text = f"🚨 Pilnie potrzebna osoba: {what}" + (f" ({why})" if why else "") + ".\nMożesz przyjść?"
            kb = ikb([[btn("✅ Mogę przyjść", f"cally:{cid}"), btn("❌ Nie mogę", f"calln:{cid}")]])
        mid = send_get_id(u, text, kb)
        if mid:
            call["msgs"][u] = mid
    save_state(state)
    log(f"Zastępstwo #{cid}: {what}, wysłano do {len(targets)}")
    simulate_call_answers(state, ym, cid, targets)
    return None


def find_call(state, cid):
    for m in state["months"].values():
        for c in m.get("calls", []):
            if c["id"] == cid:
                return m, c
    return None, None


def call_answer(state, uid, msg, cid, yes):
    month, c = find_call(state, cid)
    if not c or c["status"] != "open":
        if msg:
            edit(uid, msg["message_id"], "Dziękujemy, zastępstwo już znalezione.")
        return
    what = f"{dlabel(month['ym'], c['d'])}, {sh_text(c['code'])}"
    for lst in (c["yes"], c["no"]):
        if uid in lst:
            lst.remove(uid)
    (c["yes"] if yes else c["no"]).append(uid)
    save_state(state)
    if msg:
        edit(uid, msg["message_id"], f"{'✅ Dziękujemy! Kierownik zaraz potwierdzi' if yes else 'Rozumiemy, dziękujemy'}: {what}.")
    for a in admin_ids(state):
        if not yes:
            send(a, f"🚨 #{cid} {what}: {ename(state, uid)} nie może.")
    if not yes:
        return
    if c.get("auto"):
        call_confirm(state, None, None, cid, uid, True)
        return
    t = grafik_hours(state, uid, month["ym"])
    hrs = f"{hours_of(month, uid):g}" + (f"/{t}" if t else "") + " h"
    longer = extends_shift(month, c["d"], c["code"], uid)
    disp = "w dyspozycji" if (("R3" if longer else c["code"]) in options(month, uid, c["d"])) else "poza dyspozycją"
    if longer:   # остаётся на весь день: проверяем R3 вместо его смены
        day = month["schedule"][str(c["d"])]
        own = day.pop(uid)
        try:
            warn = replacement_warnings(state, month, uid, c["d"], "R3")
            y, m = ym_parts(month["ym"])
            tl = emp_timeline(state, month, uid)
            tl[dt.date(y, m, c["d"])] = "R3"
            for a in (dt.date(y, m, c["d"]) - DAY, dt.date(y, m, c["d"])):
                r = rest_between(tl, a)
                if r is not None and r < DAILY_REST_H and not any("przerwy" in w for w in warn):
                    warn.append(f"tylko {r:g} h przerwy między zmianami, wymagane {DAILY_REST_H} h")
        finally:
            day[uid] = own
        if t and hours_of(month, uid) + SHIFTS[c["code"]]["hours"] > t:
            warn.append("+1 do licznika dodatkowych zmian (płatne dodatkowo)")
    else:
        warn = replacement_warnings(state, month, uid, c["d"], c["code"])
    for a in admin_ids(state):
        send(a, f"🚨 #{cid} {ename(state, uid)} " + (f"może zostać na cały dzień (ma już {OTHER_SHIFT[c['code']]}, będzie R3): " if longer else "może przyjść: ")
                + f"{what}\n(teraz {hrs}, {disp})"
                + ("\n⚠️ " + "\n⚠️ ".join(warn) if warn else "\n✅ bez naruszeń przepisów"),
             ikb([[btn("✅ Zatwierdź", f"callok:{cid}:{uid}"), btn("❌ Nie", f"callx:{cid}:{uid}")]]))


def call_confirm(state, chat_id, msg, cid, uid, yes):
    month, c = find_call(state, cid)
    if not c:
        if msg:
            edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    what = f"{dlabel(month['ym'], c['d'])}, {sh_text(c['code'])}"
    if not yes:
        if msg:
            edit(chat_id, msg["message_id"], f"Odrzucono: {ename(state, uid)}, {what}.")
        send(uid, f"Dziękujemy, na {what} kierownik znalazł inną osobę.")
        return
    longer = extends_shift(month, c["d"], c["code"], uid)
    if c["status"] != "open" or (uid in month["schedule"][str(c["d"])] and not longer):
        if msg:
            edit(chat_id, msg["message_id"], f"Zastępstwo na {what} jest już obsadzone.")
        return
    month["schedule"][str(c["d"])][uid] = "R3" if longer else c["code"]   # z drugiej zmiany — cały dzień, bez drugiego wpisu
    c["status"], c["filled_by"], c["filled_at"] = "filled", uid, time.strftime("%Y-%m-%d %H:%M")
    save_state(state)
    if msg:
        edit(chat_id, msg["message_id"], f"✅ Zastępstwo: {ename(state, uid)}, {what}.")
    send(uid, (f"✅ Zostajesz na cały dzień: {dlabel(month['ym'], c['d'])}, {sh_text('R3')}." if longer else f"✅ Masz zmianę: {what}.")
         + " Kierownik potwierdził zastępstwo, dziękujemy!", EMP_KB)
    if month["published"]:
        history_save(state, month["ym"], "emp", month["schedule"])
    for u, mid in c.get("msgs", {}).items():   # гасим кнопки у остальных
        if u != uid:
            edit(u, mid, f"🚨 {what}: zastępstwo znalezione, dziękujemy.")
    for a in admin_ids(state):
        if chat_id is None or a != chat_id:
            send(a, f"🔁 #{cid} {what}: zastępstwo — {ename(state, uid)}" + (" (automatycznie pierwszy)" if c.get("auto") else "."))
    log(f"Zastępstwo #{cid}: {ename(state, uid)}")


def cant_come(state, uid, msg, d):
    """Сотрудник сам сообщает «🤒 Nie mogę przyjść» на свою смену — директору с кнопкой поиска замены."""
    month = published_month(state)
    if not month or uid not in month["schedule"].get(str(d), {}):
        edit(uid, msg["message_id"], "Nie masz zmiany tego dnia.")
        return
    code = month["schedule"][str(d)][uid]
    what = f"{dlabel(month['ym'], d)}, {sh_text(code)}"
    edit(uid, msg["message_id"], f"Przekazałem kierownikowi: nie możesz przyjść {what}. Kierownik odpisze.")
    for a in admin_ids(state):
        send(a, f"🤒 {ename(state, uid)} nie może przyjść: {what}.",
             ikb([[btn("📣 Szukaj zastępstwa (wszyscy)", f"callfor:{d}:{uid}")],
                  [btn("Zostaw w grafiku", "noop")]]))


def call_for(state, chat_id, msg, d, uid):
    month = cur_month(state)
    if not month or not month["schedule"]:
        edit(chat_id, msg["message_id"], "To jest już nieaktualne.")
        return
    err = web_call(state, d, "R1", "all", uid, "zgłosił(a) sam(a)")
    edit(chat_id, msg["message_id"], err or f"📣 Wysłałem prośbę o zastępstwo na {dlabel(month['ym'], d)}.")


def simulate_call_answers(state, ym, cid, targets):
    """Тест: трое тестовых сотрудников через несколько секунд отвечают: один «Mogę», двое «Nie mogę»."""
    import random
    tests = [u for u in targets if u.startswith("test")]
    if not tests:
        return
    picks = random.sample(tests, min(3, len(tests)))

    def run():
        for i, u in enumerate(picks):
            time.sleep(random.uniform(3, 6))
            with LOCK:
                call_answer(state, u, None, cid, i == len(picks) - 1)

    threading.Thread(target=run, daemon=True).start()


def test_absence(state, chat_id):
    """Тестовое меню: случайный тестовый сотрудник «не вышел» — снимаем и рассылаем «Tylko wolni»."""
    import random
    month = cur_month(state)
    if not month or not month["schedule"]:
        send(chat_id, f"Najpierw ułóż grafik («{B_BUILD}»).", DIR_KB)
        return
    shifts = [(int(d), u) for d, day in month["schedule"].items() for u in day if u.startswith("test")]
    if not shifts:
        send(chat_id, "W grafiku nie ma pracowników testowych.", DIR_KB)
        return
    d, u = random.choice(shifts)
    send(chat_id, f"🧪 Symulacja: {ename(state, u)} nie przyszedł(a) {dlabel(month['ym'], d)} (choroba). "
                  "Wysyłam prośbę o zastępstwo do wolnych; za kilka sekund odpowiedzą 3 osoby, jedna «Mogę».", DIR_KB)
    web_call(state, d, "R1", "free", u, "choroba")


def calls_payload(state, month):
    return {"absences": [{**a, "name": ename(state, a["uid"])} for a in month.get("absences", [])],
            "calls": [{"id": c["id"], "d": c["d"], "code": c["code"], "status": c["status"],
                       "asked": len(c["asked"]), "yes": [ename(state, u) for u in c["yes"]],
                       "no": len(c["no"]), "uid_filled": c.get("filled_by"),
                       "filled_by": ename(state, c["filled_by"]) if c.get("filled_by") else None,
                       "absent": ename(state, c["absent"]) if c.get("absent") else None, "reason": c.get("reason")}
                      for c in month.get("calls", [])[-10:]]}


# ---------- zgłoszenia problemów (pomoc) ----------
# «❓ Pomoc» → «🆘 Zgłoś problem»: человек пишет текст и/или шлёт скриншоты, потом «📨 Wyślij zgłoszenie».
# Заявка уходит владельцу (OWNER_ID в .env — разработчик/поддержка, не обязательно директор): описание, фото,
# хвост bot.log и снимок state.json. Владелец отвечает reply-ем на карточку или «✍️ Odpowiedz»;
# «✅ Rozwiązane» сообщает автору, что исправлено. Заявки — в state["tickets"] и в tickets.log.

TICKETS_LOG = os.path.join(BASE, "tickets.log")


def owner_id(state):
    return str(ENV.get("OWNER_ID") or ENV.get("SUPPORT_ID") or (state["admins"][0] if state["admins"] else ""))


def help_markup(state, uid):
    rows = [[btn("🆘 Zgłoś problem", "ticket:new")]]
    if uid == owner_id(state):
        rows.append([btn("📋 Zgłoszenia", "ticket:list")])
    return ikb(rows)


def ticket_start(state, uid):
    state["wiz"][uid] = {"step": "ticket", "texts": [], "photos": []}
    save_state(state)
    send(uid, "Opisz problem: co robiłeś(-aś), co się stało, czego się spodziewałeś(-aś). Możesz wysłać kilka "
              "wiadomości i zrzuty ekranu. Na koniec kliknij «📨 Wyślij zgłoszenie».", ticket_kb())


def ticket_kb():
    return ikb([[btn("📨 Wyślij zgłoszenie", "ticket:send"), btn("Anuluj", "ticket:cancel")]])


def ticket_collect(state, uid, msg):
    """Пока открыт черновик заявки — копим текст и фото. True — сообщение забрали в заявку."""
    w = state["wiz"].get(uid)
    if not w or w.get("step") != "ticket":
        return False
    text = (msg.get("text") or msg.get("caption") or "").strip()
    if text.startswith("/"):
        return False
    if text:
        w["texts"].append(text)
    if msg.get("photo"):
        w["photos"].append(msg["photo"][-1]["file_id"])
    save_state(state)
    send(uid, f"Dodano ({len(w['texts'])} tekst., {len(w['photos'])} zdj.). Możesz dopisać więcej albo wysłać.",
         ticket_kb())
    return True


def log_tail(n=30):
    try:
        with open(os.path.join(BASE, "bot.log"), encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-n:])
    except OSError:
        return ""


def ticket_create(state, uid):
    w = state["wiz"].pop(uid, None) or {}
    if not w.get("texts") and not w.get("photos"):
        save_state(state)
        send(uid, "Zgłoszenie jest puste, nic nie wysłałem. Kliknij «🆘 Zgłoś problem», jeśli chcesz spróbować jeszcze raz.")
        return
    tid = state.get("next_ticket", 1)
    state["next_ticket"] = tid + 1
    role = "kierownik" if uid in admin_ids(state) else "pracownik"
    name = admin_name(state, uid) if role == "kierownik" else ename(state, uid)
    month = cur_month(state)
    t = {"id": tid, "uid": uid, "name": name, "role": role, "text": "\n".join(w.get("texts", [])),
         "photos": w.get("photos", []), "at": time.strftime("%Y-%m-%d %H:%M"), "status": "open",
         "context": {"version": VERSION, "mode": state.get("mode"), "month": month["ym"] if month else None,
                     "published": bool(month and month["published"])}}
    state.setdefault("tickets", []).append(t)
    save_state(state)
    with open(TICKETS_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(t, ensure_ascii=False) + "\n")
    log(f"Zgłoszenie #{tid} od {name}: {t['text'][:80]}")
    send(uid, f"✅ Zgłoszenie #{tid} wysłane. Odpowiemy tutaj, w tym czacie.")
    ticket_to_owner(state, t)


def ticket_to_owner(state, t):
    own = owner_id(state)
    if not own:
        return
    card = (f"🆘 Zgłoszenie #{t['id']}\nOd: {t['name']} ({t['role']}, ID {t['uid']})\nCzas: {t['at']}\n"
            f"Wersja bota: {t['context']['version']}, tryb: {t['context']['mode']}, miesiąc: {t['context']['month']}\n\n"
            f"{t['text'] or '(tylko zdjęcia)'}\n\n↩️ Odpowiedz na tę wiadomość (Reply) albo kliknij «✍️ Odpowiedz».")
    try:
        res = tg("sendMessage", chat_id=own, text=card[:4000],
                 reply_markup=ikb([[btn("✍️ Odpowiedz", f"ticket:reply:{t['id']}"),
                                    btn("✅ Rozwiązane", f"ticket:done:{t['id']}")]]))
        state.setdefault("ticket_msgs", {})[str(res["result"]["message_id"])] = t["id"]
        save_state(state)
        for ph in t["photos"]:
            tg("sendPhoto", chat_id=own, photo=ph, caption=f"Zrzut do zgłoszenia #{t['id']}")
        tail = os.path.join(SCHEDULE_DIR, f"zgloszenie-{t['id']}-log.txt")
        os.makedirs(SCHEDULE_DIR, exist_ok=True)
        with open(tail, "w", encoding="utf-8") as f:
            f.write(log_tail())
        send_document(own, tail, f"bot.log (ostatnie linie) do zgłoszenia #{t['id']}", "text/plain")
        send_document(own, STATE_FILE, f"state.json w chwili zgłoszenia #{t['id']} (tylko dla Ciebie)",
                      "application/json")
    except Exception as e:  # noqa: BLE001
        log(f"Zgłoszenie #{t['id']}: nie udało się wysłać do właściciela: {e}")


def find_ticket(state, tid):
    return next((t for t in state.get("tickets", []) if t["id"] == tid), None)


def ticket_answer(state, own, t, text):
    t.setdefault("replies", []).append({"at": time.strftime("%Y-%m-%d %H:%M"), "text": text})
    save_state(state)
    send(t["uid"], f"💬 Odpowiedź na zgłoszenie #{t['id']}:\n{text}")
    send(own, f"Wysłano odpowiedź do {t['name']} (zgłoszenie #{t['id']}).")


def ticket_owner_message(state, uid, msg):
    """Сообщения владельца: reply на карточку или текст после «✍️ Odpowiedz». True — обработано."""
    if uid != owner_id(state):
        return False
    text = (msg.get("text") or msg.get("caption") or "").strip()
    w = state["wiz"].get(uid) or {}
    if w.get("step") == "ticket_reply" and text and not text.startswith("/"):
        state["wiz"].pop(uid, None)
        t = find_ticket(state, w["tid"])
        if t:
            ticket_answer(state, uid, t, text)
        return True
    tid = state.get("ticket_msgs", {}).get(str((msg.get("reply_to_message") or {}).get("message_id", "")))
    t = tid and find_ticket(state, tid)
    if t and text:
        ticket_answer(state, uid, t, text)
        return True
    return False


def ticket_list(state, uid):
    ts = state.get("tickets", [])[-15:]
    if not ts:
        send(uid, "Brak zgłoszeń.")
        return
    lines = [f"{'🟢' if t['status'] == 'open' else '✅'} #{t['id']} {t['at']} {t['name']}: {t['text'][:60]}" for t in ts]
    rows = [[btn(f"✅ Rozwiązane #{t['id']}", f"ticket:done:{t['id']}")] for t in ts if t["status"] == "open"][:8]
    send(uid, "📋 Zgłoszenia (ostatnie 15):\n" + "\n".join(lines), ikb(rows) if rows else None)


def ticket_callback(state, uid, msg, p):
    if p[1] == "new":
        ticket_start(state, uid)
    elif p[1] == "send":
        edit(uid, msg["message_id"], "Wysyłam zgłoszenie…")
        ticket_create(state, uid)
    elif p[1] == "cancel":
        state["wiz"].pop(uid, None)
        save_state(state)
        edit(uid, msg["message_id"], "Anulowano.")
    elif uid != owner_id(state):
        return
    elif p[1] == "list":
        ticket_list(state, uid)
    elif p[1] == "reply":
        state["wiz"][uid] = {"step": "ticket_reply", "tid": int(p[2])}
        save_state(state)
        send(uid, f"Napisz odpowiedź na zgłoszenie #{p[2]} (następna wiadomość pójdzie do autora).")
    elif p[1] == "done":
        t = find_ticket(state, int(p[2]))
        if t and t["status"] != "closed":
            t["status"], t["closed_at"] = "closed", time.strftime("%Y-%m-%d %H:%M")
            save_state(state)
            send(t["uid"], f"✅ Zgłoszenie #{t['id']} zostało rozwiązane. Dziękujemy za informację! "
                           "Wszystkie dane (pracownicy, grafiki, historia) są zachowane.")
            send(uid, f"✅ Zgłoszenie #{t['id']} zamknięte, autor dostał powiadomienie.")


# ---------- tryb testowy i uruchomienie ----------
# state["mode"]: "test" — есть тестовые сотрудники и сценарии; "prod" — бот в работе. «🚀 Start» удаляет
# всё тестовое (с резервной копией state.json) и переключает в prod. Директоров можно добавить ссылкой-приглашением
# или командой /kierownik <id Telegram>.

def set_mode(state, mode):
    state["mode"] = mode
    DIR_KB["keyboard"] = DIR_ROWS + ([[B_TEST], [B_LAUNCH]] if mode == "test" else [])
    refresh_roles(state)


def test_menu(state, chat_id):
    if state.get("mode") != "test":
        send(chat_id, "Bot działa już normalnie, tryb testowy jest wyłączony.", DIR_KB)
        return
    rows = [[btn("🎬 Scenariusz pokazowy", "tmenu:showcase")],
            [btn("🎲 Losowe dyspozycje (zbierz od nowa)", "tmenu:random")],
            [btn("🚨 Symulacja: ktoś nie przyszedł", "tmenu:absence")],
            [btn("👤 Demo: widok pracownika", "tmenu:demo")],
            [btn("👔 Dodaj kierownika", "tmenu:invite")]]
    send(chat_id, "🧪 Tryb testowy: 15 pracowników testowych, nikt prawdziwy nic nie dostaje.\n"
                  "🎬 Scenariusz pokazowy — dyspozycje dobrane tak, żeby było widać wszystkie funkcje.\n"
                  "🎲 Losowe dyspozycje — za każdym razem inny miesiąc.\n"
                  "👤 Demo — bot oczami pracownika.\n"
                  "👔 Dodaj kierownika — link, po którym druga osoba zostaje kierownikiem.\n\n"
                  f"Gdy wszystko sprawdzone, kliknij «{B_LAUNCH}».", ikb(rows))


def test_menu_callback(state, chat_id, msg, what):
    if state.get("mode") != "test":
        edit(chat_id, msg["message_id"], "Tryb testowy jest wyłączony.")
        return
    ym = next_ym(dt.date.today())
    if what == "showcase":
        start_showcase(state, chat_id, msg, tag(ym))
    elif what == "random":
        if not test_only(state):
            edit(chat_id, msg["message_id"], "Losowy test działa tylko z samymi pracownikami testowymi.")
            return
        edit(chat_id, msg["message_id"], f"🎲 Zbieram losowe dyspozycje na {month_title(ym)} od nowa.")
        begin_collect(state, chat_id, ym)
    elif what == "demo":
        demo_start(state, chat_id)
    elif what == "absence":
        test_absence(state, chat_id)
    elif what == "invite":
        invite_admin(state, chat_id)


def invite_admin(state, chat_id):
    """Одноразовая ссылка t.me/<бот>?start=adm_<код> (48 ч): кто откроет — станет директором."""
    code = uuid.uuid4().hex[:12]
    state.setdefault("admin_invites", {})[code] = time.time() + 48 * 3600
    save_state(state)
    name = bot_username()
    link = f"https://t.me/{name}?start=adm_{code}" if name else f"/start adm_{code}"
    send(chat_id, f"👔 Link dla kierownika (jednorazowy, ważny 48 h):\n{link}\n\nKto go otworzy i kliknie «Start», "
                  "zostanie kierownikiem: dostanie te same przyciski i «Grafik».\n"
                  "Można też dodać kierownika po ID Telegrama: /kierownik 123456789", DIR_KB)


def add_admin(state, uid, name=""):
    uid = str(uid)
    if uid in admin_ids(state):
        return False
    state["admins"].append(uid)
    if name:
        state.setdefault("admin_names", {})[uid] = name
    state["employees"].pop(uid, None)   # если успел зарегистрироваться как сотрудник
    save_state(state)
    set_menu_button(uid)
    log(f"Nowy kierownik: {name} ({uid})")
    for a in admin_ids(state):
        if a != uid:
            send(a, f"👔 Nowy kierownik: {name or 'bez imienia'} (ID Telegrama {uid}).", DIR_KB)
    return True


def admin_name(state, uid):
    return state.get("admin_names", {}).get(uid) or f"ID {uid}"


def self_employee(state, uid, msg, etat, who):
    """Директор добавляет себя сотрудником (без подтверждения): тоже шлёт диспозицию и попадает в график."""
    if etat not in ETATS:
        return
    name = state.get("admin_names", {}).get(uid) or " ".join(
        x for x in (who.get("first_name"), who.get("last_name")) if x) or "Kierownik"
    state["employees"][uid] = {"name": name, "etat": etat, "status": "active"}
    save_state(state)
    refresh_roles(state)
    edit(uid, msg["message_id"], f"✅ {name}, {ETATS[etat][0]}: jesteś też pracownikiem. Twoje przyciski "
                                 f"«{B_AVAIL}», «{B_MINE}», «{B_EXTRA}» są na dole, pod przyciskami kierownika.")
    send(uid, "Gotowe.", DIR_KB)
    month = cur_month(state)
    if month and not month["published"]:
        ask_avail(state, uid)


def remove_admin(state, chat_id, msg, uid):
    env_ids = {str(x) for x in re.findall(r"\d+", ENV.get("ADMIN_IDS", ""))}
    if uid == chat_id:
        edit(chat_id, msg["message_id"], "Nie możesz usunąć sam siebie.")
    elif uid in env_ids:
        edit(chat_id, msg["message_id"], "Ten kierownik jest wpisany w pliku .env (ADMIN_IDS), usuń go tam.")
    elif uid in state["admins"]:
        state["admins"].remove(uid)
        save_state(state)
        edit(chat_id, msg["message_id"], f"Usunięto kierownika: {admin_name(state, uid)}.")
        try:
            tg("setChatMenuButton", chat_id=uid, menu_button={"type": "default"})
        except Exception:  # noqa: BLE001
            pass


def admin_by_id(state, chat_id, text):
    m = re.match(r"^/kierownik\s+(\d{5,15})$", text.strip())
    if not m:
        send(chat_id, "Napisz: /kierownik 123456789 (ID Telegrama tej osoby; można go sprawdzić np. w @userinfobot).")
        return
    if add_admin(state, m.group(1)):
        send(m.group(1), "Jesteś kierownikiem w bocie grafików pływalni.\n\n" + HELP_DIR, DIR_KB)
        send(chat_id, f"Gotowe: {m.group(1)} jest kierownikiem. Jeśli jeszcze nie pisał(a) do bota, niech otworzy bota "
                      "i kliknie «Start».", DIR_KB)
    else:
        send(chat_id, "Ta osoba już jest kierownikiem.", DIR_KB)


def accept_invite(state, uid, code, name=""):
    exp = state.get("admin_invites", {}).pop(code, None)
    save_state(state)
    if not exp or exp < time.time():
        send(uid, "Ten link jest nieaktualny. Poproś kierownika o nowy.")
        return
    add_admin(state, uid, name)
    extra = (f"\n\nBot jest w trybie testowym: «{B_TEST}» — scenariusze pokazowe, «{B_LAUNCH}» — uruchomienie."
             if state.get("mode") == "test" else "")
    send(uid, "👔 Jesteś kierownikiem w bocie grafików pływalni.\n\n" + HELP_DIR + extra, DIR_KB)


def launch_confirm(state, chat_id):
    if state.get("mode") != "test":
        send(chat_id, "Bot już działa normalnie.", DIR_KB)
        return
    n = sum(1 for u in state["employees"] if u.startswith("test"))
    send(chat_id, f"🚀 Uruchomić bota na prawdziwą pracę?\n\n• usunę {n} pracowników testowych, testowe miesiące "
                  "(z dyspozycjami), testowe szkice i testową historię (np. październik 2026);\n"
                  "• zostaną kierownicy, ustawienia i prawdziwi pracownicy, jeśli już się zarejestrowali;\n"
                  "• wcześniej zrobię kopię zapasową (state_backup_before_start_…json w folderze bota);\n"
                  "• przyciski «🧪 Test» i «🚀 Start» znikną, działa zwykłe zbieranie i auto-dyspozycja "
                  f"{AUTO_FILL_DAY}. dnia;\n• teraz nikt nie dostanie żadnej wiadomości.\n\n"
                  "Potem wyślesz pracownikom link do bota i zaczniesz zbierać dyspozycje.",
         ikb([[btn("✅ Tak, uruchom", "launch:yes"), btn("Nie", "noop")]]))


def purge_test_history(state):
    """Убрать из истории версии, сохранённые в тесте или с тестовыми людьми (там мог быть и директор, игравший в тест).
    Импорт настоящего файла не трогаем."""
    removed = []
    for ym in list(state.get("history", {})):
        h = state["history"][ym]
        for k in ("emp", "kadry"):
            v = h.get(k)
            if v and v.get("source") != "import" and (v.get("source") == "test" or any(
                    str(u).startswith("test") for day in (v.get("sched") or {}).values() for u in day)):
                del h[k]
                removed.append(f"{ym} {k}")
        if not h.get("emp") and not h.get("kadry"):
            del state["history"][ym]
        else:
            h["names"] = {u: n for u, n in h.get("names", {}).items() if not str(u).startswith("test")}
    return removed


def launch(state, chat_id, msg):
    if state.get("mode") != "test":
        edit(chat_id, msg["message_id"], "Bot już działa normalnie.")
        return
    backup = os.path.join(BASE, f"state_backup_before_start_{time.strftime('%Y%m%d-%H%M%S')}.json")
    shutil.copy(STATE_FILE, backup)
    test = lambda u: str(u).startswith("test")
    for u in [u for u in state["employees"] if test(u)]:
        del state["employees"][u]
    admins = admin_ids(state)
    for ym in list(state["months"]):
        m = state["months"][ym]
        # месяц остаётся, только если в нём есть данные настоящих сотрудников (не директоров, игравших в тест)
        real = [u for u in list(m["avail"]) + m["done"] if not test(u) and u not in admins]
        if not real:
            del state["months"][ym]
            continue
        # месяц с настоящими людьми остаётся, но без следов тестовых
        m["avail"] = {u: a for u, a in m["avail"].items() if not test(u)}
        m["done"] = [u for u in m["done"] if not test(u)]
        for sched in (m.get("schedule"), (m.get("kadry") or {}).get("sched")):
            for day in (sched or {}).values():
                for u in [u for u in day if test(u)]:
                    del day[u]
        m["requests"] = [r for r in m.get("requests", []) if not test(r["uid"])]
        m["absences"] = [a for a in m.get("absences", []) if not test(a["uid"])]
        m["calls"] = [c for c in m.get("calls", []) if not test(c.get("absent") or "")]
        for k in ("test_silent", "test_deadline", "showcase", "asked"):
            m.pop(k, None)
    if state.get("cur") not in state["months"]:
        state["cur"] = None
    purge_test_history(state)
    for k in ("demo", "pending_import"):
        state.pop(k, None)
    DEMO_CHAT[0] = None
    state["tickets"] = [t for t in state.get("tickets", []) if not test(t["uid"])]   # настоящие заявки остаются
    set_mode(state, "prod")
    state.pop("collect_init", None)
    save_state(state)
    set_menu_all(state)
    ensure_collect(state)   # переход: ближайший несобранный месяц остаётся открытым до ручного закрытия
    log(f"Uruchomiono na produkcję, kopia: {os.path.basename(backup)}")
    edit(chat_id, msg["message_id"], "🚀 Bot uruchomiony na prawdziwą pracę.")
    name = bot_username()
    for a in admin_ids(state):
        send(a, "🚀 Bot działa naprawdę. Dane testowe usunięte (kopia: " + os.path.basename(backup) + ").\n\n"
                "Co dalej:\n1. Wyślij pracownikom link: " + (f"https://t.me/{name}" if name else "(«👥 Pracownicy»)") +
                "\n2. Każdy klika «Start», wpisuje imię i etat, a Ty przyjmujesz zgłoszenie (✅ Przyjmij).\n"
                f"3. Gdy wszyscy są, wgraj grafik dla kadr za poprzedni miesiąc (patrz niżej).\n"
                f"4. Kliknij «{B_COLLECT}».", DIR_KB)
        send(a, "📥 Ważne przed pierwszym grafikiem dla kadr: bot musi znać poprzedni miesiąc (ostatnie 3 niedziele "
                "i ostatnie dni), żeby pilnować przerw i wolnych niedziel na przełomie miesięcy. Gdy pracownicy się "
                "zarejestrują, otwórz «Grafik» → «Historia» → «📥 Wzór do importu», wpisz zmiany (wystarczą ostatnie "
                "1–2 tygodnie) i odeślij plik tutaj. Bez tego bot zapyta o to przy «Ułóż grafik dla kadr».")


# ---------- demo: widok pracownika ----------
# Директор видит бота глазами тестового сотрудника DEMO_UID: всё, что бот шлёт этому сотруднику,
# приходит директору с пометкой «🧪 DEMO», а его нажатия на кнопки сотрудника идут от имени DEMO_UID.
# Пошаговый тур — кнопкой «▶ Dalej (demo)». По «⏹ Zakończ demo» демо-сотрудник удаляется.

DEMO_STEPS = 5


def demo_start(state, chat_id):
    month = cur_month(state)
    if not month or month["published"]:
        send(chat_id, f"Demo działa w trakcie zbierania dyspozycji. Najpierw kliknij «{B_COLLECT}».", DIR_KB)
        return
    state["employees"][DEMO_UID] = {"name": DEMO_NAME, "etat": "3/4", "status": "active"}
    state["demo"] = {"chat": chat_id, "step": 0}
    DEMO_CHAT[0] = chat_id
    save_state(state)
    send(chat_id, f"🧪 Demo: zobaczysz bota oczami pracownika «{DEMO_NAME}» (3/4 etatu). Wszystko, co bot wysyła "
                  "temu pracownikowi, przyjdzie tutaj z dopiskiem «🧪 DEMO». Przyciski pracownika działają naprawdę, "
                  "ale tylko dla tego testowego pracownika; nikt inny nic nie dostanie.\n\n"
                  f"Kliknij «{B_DEMO_NEXT}», żeby przejść do kroku 1 z {DEMO_STEPS}.", DEMO_KB)


def demo_end(state, chat_id, note="Demo zakończone."):
    state.pop("demo", None)
    DEMO_CHAT[0] = None
    state["employees"].pop(DEMO_UID, None)
    for month in state["months"].values():
        month["avail"].pop(DEMO_UID, None)
        if DEMO_UID in month["done"]:
            month["done"].remove(DEMO_UID)
        month.get("asked", {}).pop(DEMO_UID, None)
        for day in (month["schedule"] or {}).values():
            day.pop(DEMO_UID, None)
    save_state(state)
    send(chat_id, f"{note} Testowy pracownik demo został usunięty.", DIR_KB)


def demo_next(state, chat_id):
    import copy
    demo = state["demo"]
    month = cur_month(state)
    if not month or month["published"]:
        demo_end(state, chat_id, "Zbieranie dyspozycji się skończyło, demo przerwane.")
        return
    step = demo["step"] + 1
    ym, title = month["ym"], month_title(month["ym"])
    if step == 1:
        send(chat_id, f"Krok 1/{DEMO_STEPS}: prośba o dyspozycję. Tak pracownik dostaje tabelę na kolejny miesiąc. "
                      "Zaznacz kilka dni (R1/R2/R3) i kliknij «✅ Gotowe». Możesz też odpisać tekstem, np. "
                      "«1-10 rano, 15 popołudnie».", DEMO_KB)
        ask_avail(state, DEMO_UID)
    elif step == 2:
        if DEMO_UID not in month["done"]:
            send(chat_id, "Najpierw wyślij dyspozycję w kroku 1 (przycisk «✅ Gotowe» pod tabelą).", DEMO_KB)
            return
        send(chat_id, f"Krok 2/{DEMO_STEPS}: prośba kierownika o dodatkowe godziny (przycisk "
                      "«📨 Poproś o dodatkowe godziny» w edytorze).", DEMO_KB)
        if web_ask(state, DEMO_UID):
            send(chat_id, "Twoja dyspozycja w demo wystarcza do etatu, więc naprawdę ta prośba by nie przyszła. "
                          "Tak wygląda, gdy brakuje godzin:", DEMO_KB)
            send(DEMO_UID, f"Kierownik prosi o uzupełnienie dyspozycji na {title}: zaznaczone dni dają maks. 64 h, "
                           f"a Twój etat to {grafik_hours(state, DEMO_UID, ym)} h. Dodaj proszę dni lub zmiany.", EMP_KB)
    elif step == 3:
        mcopy = copy.deepcopy(month)   # «публикуем» только копию: настоящий черновик не меняется
        build_schedule(state, mcopy)
        mine = {d: day[DEMO_UID] for d, day in mcopy["schedule"].items() if DEMO_UID in day}
        demo["sched"] = mine
        demo["personal"] = personal(state, mcopy, DEMO_UID)
        send(chat_id, f"Krok 3/{DEMO_STEPS}: kierownik wysłał grafik («📤 Wyślij grafik pracownikom»). "
                      "Tak pracownik go dostaje (w demo grafik jest ułożony tylko na niby).", DEMO_KB)
        send(DEMO_UID, f"📅 Grafik na {title} jest gotowy!\n\n" + demo["personal"], EMP_KB)
    elif step == 4:
        send(chat_id, f"Krok 4/{DEMO_STEPS}: kierownik zmienił coś w grafiku po wysłaniu. Pracownik dostaje "
                      "powiadomienie od razu.", DEMO_KB)
        mine = demo.get("sched") or {}
        if mine:
            d = min(mine, key=int)
            new = "R2" if mine[d] != "R2" else "R1"
            send(DEMO_UID, f"Zmiana w grafiku na {title}: {dlabel(ym, int(d))} — teraz {sh_text(new)}.", EMP_KB)
        else:
            send(DEMO_UID, f"Zmiana w grafiku na {title}: dodana zmiana {dlabel(ym, 3)}, {sh_text('R1')}.", EMP_KB)
    elif step == 5:
        send(chat_id, f"Krok 5/{DEMO_STEPS}: dodatkowe zmiany. Pracownik widzi, gdzie brakuje ludzi, i może się "
                      "zgłosić. Kliknij jedną zmianę: dostaniesz kartę kierownika do zatwierdzenia, a potem "
                      "odpowiedź jako pracownik.", DEMO_KB)
        demo_extra(state)
    else:
        demo_end(state, chat_id, "To już wszystko.")
        return
    demo["step"] = step
    save_state(state)


def demo_extra(state):
    month = cur_month(state)
    ym, mine = month["ym"], (state.get("demo") or {}).get("sched") or {}
    rows = []
    days = sorted(range(1, ndays(ym) + 1), key=lambda d: min(balance(month, d).values()))
    for d in days:
        if str(d) in mine or len(rows) >= 6:
            continue
        bal = balance(month, d)
        c = "R1" if bal["rano"] <= bal["popołudnie"] else "R2"
        n = max(1, -bal["rano" if c == "R1" else "popołudnie"])
        rows.append([btn(f"{dlabel(ym, d)} {c} {SHIFTS[c]['name']} (brakuje {n})", f"dxr:{d}:{c}")])
    send(DEMO_UID, "Tu brakuje ludzi. Kliknij, żeby zgłosić się na zmianę, kierownik zatwierdzi:", ikb(rows))


def demo_callback(state, chat_id, msg, p):
    month = cur_month(state)
    ym = month["ym"] if month else next_ym(dt.date.today())
    d, c = int(p[1]), p[2]
    what = f"{dlabel(ym, d)}, {sh_text(c)}"
    if p[0] == "dxr":
        edit(DEMO_UID, msg["message_id"], f"Prośba wysłana do kierownika: {what}. Bot napisze odpowiedź.")
        send(chat_id, f"🙋 {DEMO_NAME} zgłasza się na dodatkową zmianę: {what}. (to jest karta kierownika)",
             ikb([[btn("✅ Zatwierdź", f"dxa:{d}:{c}"), btn("❌ Odrzuć", f"dxn:{d}:{c}")]]))
    else:
        yes = p[0] == "dxa"
        edit(chat_id, msg["message_id"], f"{'✅ Zatwierdzono' if yes else '❌ Odrzucono'}: {DEMO_NAME}, {what}.")
        send(DEMO_UID, f"Kierownik {'zatwierdził' if yes else 'odrzucił'} prośbę o dodatkową zmianę: {what}.", EMP_KB)
        send(chat_id, f"To koniec demo. Kliknij «{B_DEMO_NEXT}» albo «{B_DEMO_END}».", DEMO_KB)


def demo_route(state, uid, upd):
    """Сообщения директора во время демо: кнопки сотрудника — от имени DEMO_UID. True — обработано."""
    demo = state.get("demo")
    if not demo or uid != demo["chat"]:
        return False
    msg, cb = upd.get("message"), upd.get("callback_query")
    if cb:
        p = (cb.get("data") or "").split(":")
        if p[0] in ("dt", "dd", "db", "dp", "dc", "da", "dn", "dk", "dxr"):
            if p[0] == "dxr":
                try:
                    tg("answerCallbackQuery", callback_query_id=cb["id"])
                except Exception:  # noqa: BLE001
                    pass
                demo_callback(state, uid, cb["message"], p)
            else:
                handle_callback(state, DEMO_UID, False, cb)
            return True
        if p[0] in ("dxa", "dxn"):
            try:
                tg("answerCallbackQuery", callback_query_id=cb["id"])
            except Exception:  # noqa: BLE001
                pass
            demo_callback(state, uid, cb["message"], p)
            return True
        return False
    text = ((msg or {}).get("text") or "").strip()
    if text == B_DEMO_NEXT:
        demo_next(state, uid)
    elif text == B_DEMO_END:
        demo_end(state, uid)
    elif text == B_MINE and demo.get("personal"):
        send(DEMO_UID, demo["personal"], EMP_KB)
    elif text == B_EXTRA and demo.get("step", 0) >= 5:
        demo_extra(state)
    elif text in (B_AVAIL, B_MINE, B_EXTRA, B_HELP) or (text and not text.startswith("/") and text not in (
            B_COLLECT, B_WHO, B_BUILD, B_EDIT, B_PUB, B_REQS, B_STAFF, B_WEB, B_DEMO)):
        handle_emp_text(state, DEMO_UID, text)
    else:
        return False
    return True


# ---------- обработка сообщений ----------

def handle_admin_text(state, chat_id, text):
    t = text.strip()
    actions = {B_COLLECT: start_collect, B_WHO: who_answered, B_BUILD: make_schedule, B_EDIT: start_edit,
               B_PUB: ask_publish, B_REQS: list_requests, B_STAFF: staff, B_WEB: web_link, B_DEMO: demo_start,
               "/demo": demo_start, B_TEST: test_menu, B_LAUNCH: launch_confirm, "/uruchom": launch_confirm,
               "🚀 Start: uruchom bota": launch_confirm}   # старая надпись кнопки — на случай старой клавиатуры
    is_emp = chat_id in active(state)
    if t in actions:
        actions[t](state, chat_id)
    elif t.startswith("/aktualizuj"):
        send(chat_id, "🔄 Nowe wersje bot sprawdza sam i przysyła «🔔 Jest nowa wersja» z przyciskiem «🔄 Aktualizuj». Sprawdzić teraz: /sprawdz. Można też wysłać mi plik aktualizacja-….zip (jako dokument)."
             if can_update(state, chat_id) else "Aktualizacje może instalować tylko kierownik lub właściciel bota.")
    elif t.startswith("/sprawdz"):
        if can_update(state, chat_id):
            send(chat_id, "🔎 Sprawdzam, czy jest nowa wersja…")
            update_check(state, chat_id)
        else:
            send(chat_id, "Aktualizacje może instalować tylko kierownik lub właściciel bota.")
    elif t.startswith("/aktualizacja") and can_update(state, chat_id):
        update_from_net(state, chat_id)
    elif t.startswith("/przywroc"):
        update_rollback(state, chat_id)
    elif t.startswith("/archiwum"):
        send_archive(state, chat_id)
    elif t.startswith("/powiaz"):
        hist_send_cards(state, chat_id)
    elif t.startswith("/kierownik"):
        admin_by_id(state, chat_id, t)
    elif is_emp and (t in (B_AVAIL, B_MINE, B_EXTRA, B_VAC)
                     or state["wiz"].get(chat_id, {}).get("step") in ("vac", "vacok")):
        handle_emp_text(state, chat_id, t)   # директор, который сам тоже сотрудник
    elif is_emp and not t.startswith("/") and (cur_month(state) or {}).get("published") is False:
        handle_emp_text(state, chat_id, t)   # текстовая диспозиция директора-сотрудника
    elif t in (B_HELP, "/help"):
        send(chat_id, HELP_DIR + "\n\nCoś nie działa? Kliknij «🆘 Zgłoś problem».", help_markup(state, chat_id))
    elif t.startswith("/start"):
        send(chat_id, HELP_DIR, DIR_KB)
        set_menu_button(chat_id)
        web_button(chat_id, "Wygodny edytor grafiku: przycisk poniżej albo «Grafik» obok pola wiadomości.")
    else:
        send(chat_id, "Wybierz działanie przyciskiem na dole.", DIR_KB)


def handle_emp_text(state, uid, text):
    t = text.strip()
    month = collect_month(state)
    if t == B_AVAIL:
        ask_avail(state, uid)
    elif t == B_MINE:
        my_schedule(state, uid)
    elif t == B_EXTRA:
        extra_shifts(state, uid)
    elif t in (B_VAC, "/urlop"):
        vac_start(state, uid)
    elif state["wiz"].get(uid, {}).get("step") in ("vac", "vacok"):
        vac_text(state, uid, t)
    elif t in (B_HELP, "/help"):
        send(uid, HELP_EMP + "\n\nCoś nie działa? Kliknij «🆘 Zgłoś problem».", help_markup(state, uid))
    elif t.startswith("/start"):
        send(uid, HELP_EMP, EMP_KB)
    elif can_edit_avail(state, month, uid):
        avail_from_text(state, uid, t)
    else:
        send(uid, "Teraz nie zbieramy dyspozycji. Przyciski na dole: mój grafik, dodatkowe zmiany.", EMP_KB)


def handle_callback(state, uid, is_admin, cb):
    try:
        tg("answerCallbackQuery", callback_query_id=cb["id"])
    except Exception:  # noqa: BLE001
        pass
    msg = cb["message"]
    data = cb.get("data") or ""
    p = data.split(":")
    kind = p[0]
    emp = state["employees"].get(uid)
    is_emp = bool(emp and emp["status"] == "active")
    if data == "noop":
        edit(uid, msg["message_id"], "Dobrze, anulowałem.")
    elif kind == "ticket":
        ticket_callback(state, uid, msg, p)
    elif kind in ("cally", "calln") and is_emp:
        call_answer(state, uid, msg, int(p[1]), kind == "cally")
    elif kind == "cant" and is_emp:
        cant_come(state, uid, msg, int(p[1]))
    elif kind in ("callok", "callx") and is_admin:
        call_confirm(state, uid, msg, int(p[1]), p[2], kind == "callok")
    elif kind == "callfor" and is_admin:
        call_for(state, uid, msg, int(p[1]), p[2])
    elif kind == "reg":
        reg_etat(state, uid, msg, p[1])
    elif kind in ("dt", "dd", "db", "dp", "dc", "da", "dn", "dk") and is_emp:
        if kind == "dp":
            # месяц берём из кнопки: сбор идёт на следующий месяц, а директор работает с текущим
            month = month_for_tag(state, p[1])
            if can_edit_avail(state, month, uid):
                edit(uid, msg["message_id"], avail_text(month, int(p[2]), state, uid), avail_kb(state, month, uid, int(p[2])))
            else:
                edit(uid, msg["message_id"], "Ta tabela jest już nieaktualna: zbieranie dyspozycji na ten miesiąc jest zamknięte.")
        else:
            avail_callback(state, uid, msg, data)
    elif kind == "xr" and is_emp:
        month = published_month(state)
        if not month or p[1] != tag(month["ym"]):
            edit(uid, msg["message_id"], "To jest już nieaktualne.")
        else:
            request_extra(state, uid, msg, int(p[2]), p[3])
    elif kind == "vac" and (is_emp or is_admin):
        vac_callback(state, uid, msg, p, is_admin)
    elif not is_admin:
        return
    elif kind == "showcase":
        start_showcase(state, uid, msg, p[1])
    elif kind == "closecol":
        close_collection_manual(state, uid, msg, p[1])
    elif kind == "tmenu":
        test_menu_callback(state, uid, msg, p[1])
    elif kind == "launch":
        launch(state, uid, msg)
    elif kind == "invadm":
        invite_admin(state, uid)
    elif kind == "emplink":
        emp_link(state, uid)
    elif kind == "emplinknew":
        emp_link(state, uid, new=True)
    elif kind == "acce":
        accept_with_etat(state, uid, msg, p[1])
    elif kind == "accset":
        accept_with_etat(state, uid, msg, p[1], p[2])
    elif kind == "selfemp":
        edit(uid, msg["message_id"], "Jaki masz etat?", etat_kb("selfetat"))
    elif kind == "selfetat":
        self_employee(state, uid, msg, p[1], cb.get("from", {}))
    elif kind == "rmadm":
        remove_admin(state, uid, msg, p[1])
    elif kind == "zw":
        exit_menu(state, uid, msg, p[1])
    elif kind == "zwc":
        exit_confirm(state, uid, msg, p[1], p[2])
    elif kind == "zwy":
        err = emp_exit(state, p[1], p[2], p[3] == "1")
        edit(uid, msg["message_id"], err or f"🚪 {ename(state, p[1])}: ostatni dzień {p[2][8:]}.{p[2][5:7]}.")
    elif kind == "zwr":
        err = emp_restore(state, p[1])
        edit(uid, msg["message_id"], err or f"↩️ {ename(state, p[1])} znów pracuje.")
    elif kind == "mrg":
        emp_merge(state, uid, msg, p[1], p[2])
    elif kind == "upd":
        update_install(state, uid, msg, p[1] == "ok")
    elif kind == "updnet":
        update_from_net(state, uid, msg)
    elif kind == "updlater":
        edit(uid, msg["message_id"], "Dobrze, przypomnę przy następnej wersji. Zainstalować można w każdej chwili: /sprawdz")
    elif kind == "updrb":
        update_rollback(state, uid, msg, True)
    elif kind in ("archstop", "archstopy"):
        archive_stop(state, uid, msg, kind == "archstopy")
    elif kind == "dnr":
        e = state["employees"].get(p[1])
        if e:
            set_donor(state, p[1], not e.get("donor"))
            emp_menu(state, uid, msg, p[1])
    elif kind == "etp":
        etat_pick(state, uid, msg, p[1], p[2], p[3], p[4])
    elif kind == "hl":
        hist_link_menu(state, uid, p[1])
    elif kind == "hlk":
        hist_link_pick(state, uid, msg, p[1], p[2])
    elif kind == "hll":
        hist_unlinked_list(state, uid)
    elif kind == "hlall":
        hist_send_cards(state, uid)
    elif kind == "himp":
        confirm_import(state, uid, msg, p[1] in ("ok", "emp", "use"), "kadry" if p[1] == "ok" else "emp", p[1] == "use")
    elif kind == "impsend":
        err = import_send(state, uid, p[1])
        edit(uid, msg["message_id"], err or "📤 Wysłane.")
    elif kind == "hmap":
        import_map_menu(state, uid, int(p[1]))
    elif kind == "hmapto":
        import_map_to(state, uid, msg, int(p[1]), p[2])
    elif kind == "recollect":
        restart_collect(state, uid, msg, p[1])
    elif kind in ("acc", "rej"):
        accept(state, uid, msg, p[1], kind == "acc")
    elif kind == "emp":
        emp_menu(state, uid, msg, p[1])
    elif kind == "ets":
        set_etat(state, uid, msg, p[1], p[2])
    elif kind in ("rm", "rmy"):
        remove_emp(state, uid, msg, p[1], kind == "rmy")
    elif kind in ("xa", "xn"):
        answer_request(state, uid, msg, int(p[1]), kind == "xa")
    elif kind in ("cal", "ed", "pe", "mv", "md", "mt", "rmv", "ad", "au", "ac"):
        edit_callback(state, uid, msg, data)
    elif kind in ("remind", "build", "show", "pub"):
        month = cur_month(state)
        if not month or p[1] != tag(month["ym"]):
            edit(uid, msg["message_id"], "To jest już nieaktualne.")
            return
        if kind != "show":
            edit(uid, msg["message_id"], msg.get("text", ""))
        if kind == "remind":
            remind(state, uid)
        elif kind == "build":
            do_build(state, uid)
        elif kind == "show":
            send_summary(state, uid, month, f"Grafik {month_title(month['ym'])}")
        else:
            publish(state, uid)


def handle_update(state, upd):
    msg = upd.get("message")
    cb = upd.get("callback_query")
    src = msg or cb
    if not src:
        return
    chat = (msg or cb.get("message") or {}).get("chat", {})
    if chat.get("type") != "private":
        return
    uid = str(src["from"]["id"])
    text = (msg or {}).get("text") or ""
    apply_exits(state)
    refresh_roles(state)
    if not admin_ids(state) and not state["employees"] and text.startswith("/start"):
        # первый, кто нажал /start, становится директором
        state["admins"].append(uid)
        save_state(state)
        send(uid, "Jesteś kierownikiem: dostajesz zgłoszenia pracowników i układasz grafik.\n\n" + HELP_DIR, DIR_KB)
        set_menu_button(uid)
        return
    if msg and (ticket_owner_message(state, uid, msg)
                or (text not in ALL_BUTTONS and ticket_collect(state, uid, msg))):
        return
    if text.startswith("/start adm_") and uid not in admin_ids(state):
        who = src.get("from", {})
        name = " ".join(x for x in (who.get("first_name"), who.get("last_name")) if x) or who.get("username", "")
        accept_invite(state, uid, text.split("adm_", 1)[1].strip(), name)
        return
    is_admin = uid in admin_ids(state)
    if is_admin and demo_route(state, uid, upd):
        return
    if cb:
        handle_callback(state, uid, is_admin, cb)
        return
    if is_admin and (msg or {}).get("document"):
        name = (msg["document"].get("file_name") or "").lower()
        if name.startswith("aktualizacja") and name.endswith(".zip"):
            update_received(state, uid, msg["document"])
        else:
            handle_import_doc(state, uid, msg["document"])
        return
    if not text:
        return
    if is_admin:
        handle_admin_text(state, uid, text)
        return
    emp = state["employees"].get(uid)
    code = state.get("emp_code")
    if not emp and text.startswith("/start emp_"):
        if code and text.split("emp_", 1)[1].strip() == code:
            reg_text(state, uid, "/start")
        else:
            send(uid, "Ten link do rejestracji jest nieaktualny. Poproś kierownika o nowy.")
    elif not emp and code and state["wiz"].get(uid, {}).get("step") not in ("name", "etat"):
        # po wygenerowaniu linku rejestracja tylko przez link — obcy nie dopiszą się do grafiku
        send(uid, "To bot grafików pływalni. Żeby się zarejestrować, poproś kierownika o link dla pracowników.")
    elif not emp:
        reg_text(state, uid, text)
    elif emp["status"] == "pending":
        send(uid, "Zgłoszenie czeka na zatwierdzenie kierownika. Bot napisze, gdy zostanie przyjęte.")
    elif emp["status"] == "rejected":
        send(uid, "Brak dostępu.", force=True)
    elif emp["status"] == "former" or uid not in active(state):
        send(uid, "Dziękujemy za współpracę! Dostęp do grafiku jest już zamknięty. W razie pytań skontaktuj się z kierownikiem.", force=True)
    elif state.get("mode") == "test" and not uid.startswith("test"):
        send(uid, "Jesteś zarejestrowany(-a). Bot jest jeszcze przygotowywany: tabelę dyspozycji i grafik dostaniesz, "
                  "gdy kierownik go uruchomi.", EMP_KB, force=True)
    else:
        handle_emp_text(state, uid, text)


def single_instance():
    """Не даёт запустить второй экземпляр бота (автозапуск + ручной запуск). Код выхода 3 — уже работает."""
    if os.name != "nt":
        return None
    import msvcrt
    f = open(os.path.join(BASE, "bot.lock"), "a+")
    f.seek(0)
    try:
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        log("Bot już działa, druga kopia kończy pracę")
        sys.exit(3)
    return f


HEARTBEAT = [time.time()]
WATCHDOG_SEC = 300


def watchdog():
    """Если главный цикл не отзывался 5 минут (завис после сна компьютера, DNS и т. п.),
    пишем стек в лог и выходим — run_bot.cmd перезапустит бота с новым туннелем."""
    import faulthandler
    while True:
        time.sleep(30)
        idle = time.time() - HEARTBEAT[0]
        if idle > WATCHDOG_SEC:
            log(f"Watchdog: brak odpowiedzi od {int(idle)} s, restart bota")
            faulthandler.dump_traceback(file=sys.stdout, all_threads=True)
            sys.stdout.flush()
            os._exit(1)


def main():
    if not TOKEN:
        sys.exit("Brak BOT_TOKEN w pliku .env")
    lock = single_instance()  # noqa: F841 — держим файл открытым, пока бот работает
    backup_state("start")
    state = load_state()
    if state.get("demo"):
        DEMO_CHAT[0] = state["demo"]["chat"]
    # режим: из state; MODE=TEST в .env возвращает тестовый режим (кнопки нет специально)
    mode = "test" if ENV.get("MODE", "").upper() == "TEST" else state.get("mode") or (
        "test" if any(u.startswith("test") for u in state["employees"]) else "prod")
    set_mode(state, mode)
    save_state(state)
    ensure_collect(state)
    log(f"Bot uruchomiony. Minimum: rano {NEED['rano']}, popołudnie {NEED['popołudnie']}; grafiki: {SCHEDULE_DIR}")
    start_web(state)
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Thread(target=tunnel_watch, args=(state,), daemon=True).start()
    update_after_start(state)
    threading.Thread(target=update_poll, args=(state,), daemon=True).start()
    while True:
        HEARTBEAT[0] = time.time()
        try:
            res = tg("getUpdates", offset=state["offset"], timeout=50,
                     allowed_updates=["message", "callback_query"])
        except (urllib.error.URLError, OSError, ValueError) as e:
            log(f"getUpdates: {e}")
            time.sleep(5)
            continue
        for upd in res.get("result", []):
            HEARTBEAT[0] = time.time()
            with LOCK:
                state["offset"] = upd["update_id"] + 1
                save_state(state)
                try:
                    handle_update(state, upd)
                except Exception as e:  # noqa: BLE001
                    log(f"update {upd.get('update_id')} failed: {e!r}")
        with LOCK:
            try:
                check_auto_fill(state)
            except Exception as e:  # noqa: BLE001
                log(f"auto-dyspozycja failed: {e!r}")


if __name__ == "__main__":
    main()
